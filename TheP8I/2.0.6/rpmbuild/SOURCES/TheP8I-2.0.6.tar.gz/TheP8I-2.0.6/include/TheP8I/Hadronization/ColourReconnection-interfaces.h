static Parameter<StringFragmentation,int> interfaceCR_reconnect
  ("CRreconnect",
   "  Colour Reconnection reconnet parameter.  ",
   &StringFragmentation::CR_reconnect, 0, 0, 1,
   true, false, Interface::limited);

static Parameter<StringFragmentation,int> interfaceCR_mode
  ("CRmode",
   "  Colour Reconnection mode parameter.  ",
   &StringFragmentation::CR_mode, 1, 0, 4,
   true, false, Interface::limited);

static Parameter<StringFragmentation,double> interfaceCR_m0
  ("CRm0",
   " QCD Colour Reconnection m0 parameter.  ",
   &StringFragmentation::CR_m0, 0.3, 0.1, 5.0,
   true, false, Interface::limited);

#if PYTHIA_VERSION_INTEGER >= 8315
static Parameter<StringFragmentation,double> interfaceCR_mPseudo
  ("CRmPseudo",
   " QCD Colour Reconnection mPseudo parameter.  ",
   &StringFragmentation::CR_mPseudo, 0.3, 0.1, 5.0,
   true, false, Interface::limited);
#endif

static Parameter<StringFragmentation,double> interfaceCR_junctionCorrection
  ("CRjunctionCorrection",
   " QCD Colour Reconnection junctionCorrection parameter.  ",
   &StringFragmentation::CR_junctionCorrection, 1.2, 0.01, 10.0,
   true, false, Interface::limited);

static Parameter<StringFragmentation,int> interfaceCR_nColours
  ("CRnColours",
   " QCD Colour Reconnection nColours mode.  ",
   &StringFragmentation::CR_nColours, 9, 1, 30,
   true, false, Interface::limited);

static Parameter<StringFragmentation,int> interfaceCR_sameNeighbourColours
  ("CRsameNeighbourColours",
   " QCD Colour Reconnection sameNeighbourColours flag.  ",
   &StringFragmentation::CR_sameNeighbourColours, 0, 0, 1,
   true, false, Interface::limited);

static Parameter<StringFragmentation,int> interfaceCR_allowJunctions
  ("CRallowJunctions",
   " QCD Colour Reconnection allowJunctions flag.  ",
   &StringFragmentation::CR_allowJunctions, 1, 0, 1,
   true, false, Interface::limited);

static Parameter<StringFragmentation,int> interfaceCR_lambdaForm
  ("CRlambdaForm",
   " QCD Colour Reconnection lambdaForm mode.  ",
   &StringFragmentation::CR_lambdaForm, 0, 0, 2,
   true, false, Interface::limited);

static Parameter<StringFragmentation,int> interfaceCR_allowDoubleJunRem
  ("CRallowDoubleJunRem",
   " QCD Colour Reconnection allowDoubleJunRem flag.  ",
   &StringFragmentation::CR_allowDoubleJunRem, 1, 0, 1,
   true, false, Interface::limited);

static Parameter<StringFragmentation,int> interfaceCR_timeDilationMode
  ("CRtimeDilationMode",
   " QCD Colour Reconnection timeDilationMode mode.  ",
   &StringFragmentation::CR_timeDilationMode, 2, 0, 5,
   true, false, Interface::limited);

static Parameter<StringFragmentation,double> interfaceCR_timeDilationPar
  ("CRtimeDilationPar",
   " QCD Colour Reconnection timeDilationPar parameter.  ",
   &StringFragmentation::CR_timeDilationPar, 0.18, 0.0, 100.0,
   true, false, Interface::limited);

static Parameter<StringFragmentation,double> interfaceCR_m2Lambda
  ("CRm2Lambda",
   "  Colour Reconnection m2Lambda parameter.  ",
   &StringFragmentation::CR_m2Lambda, 1.0, 0.25, 16.0,
   true, false, Interface::limited);

static Parameter<StringFragmentation,double> interfaceCR_fracGluon
  ("CRfracGluon",
   "  Colour Reconnection fracGluon parameter.  ",
   &StringFragmentation::CR_fracGluon, 1.0, 0.0, 1.0,
   true, false, Interface::limited);

static Parameter<StringFragmentation,double> interfaceCR_dLambdaCut
  ("CRdLambdaCut",
   "  Colour Reconnection dLambdaCut parameter.  ",
   &StringFragmentation::CR_dLambdaCut, 0.0, 0.0, 10.0,
   true, false, Interface::limited);

static Parameter<StringFragmentation,int> interfaceCR_flipMode
  ("CRflipMode",
   "  Colour Reconnection flipMode parameter.  ",
   &StringFragmentation::CR_flipMode, 0, 0, 4,
   true, false, Interface::limited);

static Parameter<StringFragmentation,int> interfaceCR_forceHadronLevel
  ("CRforceHadronLevel",
   "  Colour Reconnection forceHadronLevelCR parameter.  ",
   &StringFragmentation::CR_forceHadronLevel, 1, 0, 1,
   true, false, Interface::limited);

static Parameter<StringFragmentation,int> interfaceBR_remnantMode
  ("BRremnantMode",
   "  Beam Remnants remnantMode mode.  ",
   &StringFragmentation::BR_remnantMode, 0, 0, 1,
   true, false, Interface::limited);
