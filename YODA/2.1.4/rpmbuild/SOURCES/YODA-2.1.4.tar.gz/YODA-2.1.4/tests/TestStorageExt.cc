#include "YODA/Dbn.h"
#include "YODA/FillableStorage.h"
#include "YODA/Utils/MetaUtils.h"

#include <array>
#include <iostream>

using namespace std;
using namespace YODA;

/// Extension to the Dbn class
template<size_t N>
class DbnExt : public DbnBase<N> {

  public:

  using BaseT = DbnBase<N>;
  using BaseT::BaseT;
  using BaseT::operator=;

  DbnExt() { reset(); }

  template<size_t dim = N, typename = std::enable_if_t<(dim < 2)>>
  DbnExt(const double numEntries, const array<double,N+1>& sumW,
         const array<double,N+1>& sumW2, const array<double,N+1>& sumW3)
    : BaseT(numEntries, sumW, sumW2), _sumW3(sumW3) { }

  template<size_t dim = N, typename = std::enable_if_t<(dim >= 2)>>
  DbnExt(const double numEntries, const array<double,N+1>& sumW, const array<double,N+1>& sumW2,
         const array<double,N*(N-1)/2>& sumWcross, const array<double,N+1>& sumW3)
    : BaseT(numEntries, sumW, sumW2, sumWcross), _sumW3(sumW3) { }

  DbnExt(const DbnExt&) = default;

  DbnExt(DbnExt&&) = default;

  DbnExt& operator = (const DbnExt&) = default;

  DbnExt& operator = (DbnExt&&) = default;

  void fill(const std::array<double, N> vals, const double weight = 1.0, const double fraction = 1.0) {
    fill(vals, weight, fraction, std::make_index_sequence<N>{});
  }

  template<typename... Args>
  void fill(Args&&... args) {
    BaseT::fill(args...);

    std::array<double, sizeof...(args)> vals = {{args...}};
    double weight = 1.0;
    double fraction = 1.0;
    if (vals.size() > N) {
      weight = vals[N];
      if (vals.size() > N + 1)  fraction = vals[N + 1];
    }
    const double sf = fraction * weight;
    _sumW3.at(0) += sf*sqr(weight);
    for (unsigned int i = 0; i < N; ++i) {
      _sumW3.at(i + 1) += sf * sqr(vals.at(i))*vals.at(i);
    }
  }

  void set(const double numEntries, const array<double,N+1>& sumW,
                                    const array<double,N+1>& sumW2,
                                    const array<double,N*(N-1)/2>& sumWcross,
                                    const array<double,N+1>& sumW3) {
    BaseT::set(numEntries, sumW, sumW2, sumWcross);
    _sumW3 = sumW3;
  }

  void set(const DbnExt<N>& other) {
    if (this != &other)  *this = other;
  }

  void set(DbnExt<N>&& other) {
    if (this != &other)  *this = std::move(other);
  }

  void reset() {
    BaseT::reset();
    _sumW3.fill(0);
  }

  void scaleW(const double sf) {
    _sumW3.at(0) *= sqr(sf)*sf;
    for (size_t i = 0; i< N; ++i) {
      _sumW3.at(i+1) *= sf;
    }
    BaseT::scaleW(sf);
  }

  double sumW3(const size_t i) const {
    return _sumW3.at(i);
  }

  private:

  array<double, N+1> _sumW3;

  template <size_t... I>
  void fill(const std::array<double, N> vals, const double weight, const double fraction,
            std::index_sequence<I...>) {
    fill(vals[I]..., weight, fraction);
  }
};


/// Template specialisation for default fill adapter
template <size_t DbnN, template<size_t, typename, typename> class BinT, typename BinningT, size_t N>
struct defaultAdapter<DbnN, BinT<N, DbnExt<DbnN>, BinningT>> {

  using FillCoords = decltype(std::tuple_cat(std::declval<typename BinningT::EdgeTypesTuple>(),
                   dblPadding(std::make_index_sequence<DbnN-BinningT::Dimension::value>{})));

  using AdapterT = std::function<void(BinT<N, DbnExt<DbnN>, BinningT>&, FillCoords&&, double, double)>;

  AdapterT _adapter = [](auto& dbn, auto&& coords, double weight, double fraction) {
    using CoordsArrT = std::array<double, DbnN>;
    CoordsArrT dblCoords;
    size_t binIdx = dbn.index();
    auto nullifyDiscrete = [&dblCoords, &binIdx, &coords](auto I){
      using isArithmetic = typename BinningT::template is_Arithmetic<I>;
      dblCoords[I] = nullifyIfDiscCoord(std::move(std::get<I>(coords)),
                                        std::integral_constant<bool,
                                        isArithmetic::value>{}, binIdx);
    };
    MetaUtils::staticFor<BinningT::Dimension::value>(nullifyDiscrete);
    if constexpr (DbnN > BinningT::Dimension::value)
      dblCoords[N] = std::move(std::get<N>(coords));
    dbn.fill(std::move(dblCoords), weight, fraction);
  };

};


/// Custom FillableStorage using the extended Dbn class
template <size_t DbnN, typename... AxisT>
class MyStorage : public YODA::FillableStorage<DbnN, DbnExt<DbnN>, AxisT...> {

public:

  using BaseT = YODA::FillableStorage<DbnN, DbnExt<DbnN>, AxisT...>;

  MyStorage() : BaseT() { }

  MyStorage(const std::vector<AxisT>&... binsEdges) : BaseT(Axis<AxisT>(binsEdges)...) { }

};

int main() {

  MyStorage<1,double> s({0.0, 0.5, 1.0});
  s.fill(0.25, 10);
  s.fill(0.60, 10);
  s.fill(0.80, 10);

  cout << "sumW:";
  for (const auto& b : s.bins()) {
    cout << "\t" << b.sumW();
  }
  cout << endl;

  cout << "sumW2:";
  for (const auto& b : s.bins()) {
    cout << "\t" << b.sumW2();
  }
  cout << endl;

  cout << "sumW3:";
  for (const auto& b : s.bins()) {
    cout << "\t" << b.sumW3(0);
  }
  cout << endl;

  int rtn = CHECK_TEST_RES(s.bin(1).sumW() == 10     &&
                           s.bin(1).sumW2() == 100   &&
                           s.bin(1).sumW3(0) == 1000 &&
                           s.bin(2).sumW() == 20     &&
                           s.bin(2).sumW2() == 200   &&
                           s.bin(2).sumW3(0) == 2000);

  return rtn;
}

