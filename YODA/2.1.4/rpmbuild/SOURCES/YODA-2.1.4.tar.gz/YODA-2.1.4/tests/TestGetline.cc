#include "YODA/Utils/getline.h"
#include <iostream>
#include <sstream>
#include <string>

using namespace std;
using namespace YODA;

int main() {

  istringstream is("part1\npart2\r\n");
  string s;

  Utils::getline(is, s);
  if (s != "part1")  return EXIT_FAILURE;

  Utils::getline(is, s);
  if (s != "part2")  return EXIT_FAILURE;

  return EXIT_SUCCESS;
}
