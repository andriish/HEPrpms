#!/bin/sh

exec ./testreader
