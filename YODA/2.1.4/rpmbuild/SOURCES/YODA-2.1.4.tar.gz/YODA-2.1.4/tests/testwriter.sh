#!/bin/sh

exec ./testwriter
