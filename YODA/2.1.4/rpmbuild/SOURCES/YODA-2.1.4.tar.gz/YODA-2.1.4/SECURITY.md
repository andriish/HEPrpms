# Security Policy

## Reporting a vulnerability

If you believe you have found a security-relevant defect in YODA -
for example, a crash, memory-safety error, or other exploitable
behaviour arising from parsing untrusted input files - please report it
privately rather than through the public issue tracker.

Send reports to **[yoda-security@cern.ch](mailto:yoda-security@cern.ch)**.
This address reaches the core maintainers and is not publicly archived.

Alternatively, you may open a confidential issue on the GitLab tracker by
ticking "This issue is confidential" when creating it.

Please include, where possible:

- the YODA version and how it was built or installed;
- the platform and compiler;
- a minimal input file or code snippet reproducing the problem;
- any analysis of the impact you have already done.

## What to expect

We aim to acknowledge reports within 14 days. We will confirm whether we
can reproduce the problem, discuss the likely impact with you, and agree
a disclosure timeline. Where a fix is needed, it will normally be issued
in the next release, with the reporter credited unless anonymity is
preferred.

## Scope

YODA is an offline data-analysis and I/O library. It performs no network
communication, requires no elevated privileges, and handles no
credentials or personal data. The principal security-relevant surface is
the parsing of `.yoda` and legacy-format input files, which may originate
from untrusted sources.

Reports concerning YODA's dependencies should be directed to those
projects; we are glad to be informed of them, but cannot issue fixes on
their behalf.
