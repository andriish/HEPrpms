#################################################
#############       WARNING      ################
#################################################
# This file has been automatically generated.
# Any changes you make here will get overridden.
# Instead, make your changes in templates/*.dat
#################################################

# cython: embedsignature=True
# cython: c_string_type=str, c_string_encoding=utf8

## System / stdlib imports
from cython.operator cimport dereference as deref, preincrement as preinc
from cython.operator cimport address
from libcpp.string cimport string
from libcpp.vector cimport vector
from libcpp.pair cimport pair
from libcpp.map cimport map

## YODA mapping imports
cimport yoda.declarations as c
cimport yoda.util as cutil
import yoda.util as util

## Pure Python imports
from itertools import repeat
from operator import attrgetter
import sys

def version():
    "Return YODA library version as a string"
    return c.version()

def getLibPath():
    "Return the directory containing the YODA library"
    return c.getLibPath()

def getDataPath():
    "Return the directory containing the YODA data files"
    return c.getDataPath()

def getYodaDataPath():
    "Return the list of directories containing YODA data files"
    return c.getYodaDataPath()

include "include/AnalysisObject.pyx"
include "include/Axis.pyx"
include "include/Bin1D.pyx"
include "include/Bin2D.pyx"
include "include/Bin3D.pyx"
include "include/BinnedEstimate1D.pyx"
include "include/BinnedEstimate2D.pyx"
include "include/BinnedEstimate3D.pyx"
include "include/BinnedHisto1D.pyx"
include "include/BinnedHisto2D.pyx"
include "include/BinnedHisto3D.pyx"
include "include/BinnedProfile1D.pyx"
include "include/BinnedProfile2D.pyx"
include "include/Binning.pyx"
include "include/Counter.pyx"
include "include/Dbn0D.pyx"
include "include/Dbn1D.pyx"
include "include/Dbn2D.pyx"
include "include/Dbn3D.pyx"
include "include/Estimate.pyx"
include "include/Estimate0D.pyx"
include "include/Exeptions.pyx"
include "include/IO.pyx"
include "include/MathUtils.pyx"
include "include/Point.pyx"
include "include/Point1D.pyx"
include "include/Point2D.pyx"
include "include/Point3D.pyx"
include "include/Point4D.pyx"
include "include/Scatter1D.pyx"
include "include/Scatter2D.pyx"
include "include/Scatter3D.pyx"
include "include/Scatter4D.pyx"
include "include/StatsUtils.pyx"