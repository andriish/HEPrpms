template<class T> void cython_iadd(T* a, T* b) {
  *a += *b;
}

template<class T> void cython_isub(T* a, T* b) {
  *a -= *b;
}

// template<class T> void cython_imul_dbl(T* a, double b) {
//   *a *= b;
// }

// template<class T> void cython_idiv_dbl(T* a, double b) {
//   *a /= b;
// }

template<class T> T* cython_add(T* a, T* b) {
  return new T(*a + *b);
}

template<class T> T* cython_sub(T* a, T* b) {
  return new T(*a - *b);
}

template<class T> auto* cython_div(T* a, T* b) {
  return (*a / *b).newclone();
}

template<class T> auto* cython_mult(T* a, T* b) {
  return multiply(*a, *b).newclone();
}

template<class T> bool cython_eq(T* a, T* b) {
  return *a == *b;
}

template<class T> bool cython_ne(T* a, T* b) {
  return *a != *b;
}

template<class T> auto* cython_eff(T* a, T* b) {
  return efficiency(*a, *b).newclone();
}

template<class T> T* cython_add_est(T* a, T* b, std::string& pat) {
  return new T(a->add(*b, pat));
}

template<class T> T* cython_sub_est(T* a, T* b, std::string& pat) {
  return new T(a->subtract(*b, pat));
}

template<class T> auto* cython_div_est(T* a, T* b, std::string& pat) {
  return new T(divide(*a, *b, pat));
}

template<class T> auto* cython_mult_est(T* a, T* b, std::string& pat) {
  return new T(multiply(*a, *b, pat));
}

template<class T> auto* cython_eff_est(T* a, T* b, std::string& pat) {
  return new T(efficiency(*a, *b, pat));
}

// Generic converter to estimates
template<class T, typename... Args> auto* cython_est(T* a, const Args& ...args) {
  return (*a).mkEstimate(args...).newclone();
}

// Generic converter to Neff estimates
template<class T, typename... Args> auto* cython_effn(T* a, const Args& ...args) {
  return (*a).mkBinnedEffNumEntries(args...).newclone();
}

// Specialised (but still technically generic) converter for unbinned Counter -> Neff estimate
template<class T, typename... Args> auto* cython_effnC(T* a, const Args& ...args) {
  return (*a).mkEffNumEntries(args...).newclone();
}

// Generic converter to histos
template<class T, typename... Args> auto* cython_hist(T* a, const Args& ...args) {
  return (*a).mkHisto(args...).newclone();
}
