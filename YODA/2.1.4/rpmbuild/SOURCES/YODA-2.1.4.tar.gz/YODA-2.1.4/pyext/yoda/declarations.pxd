#################################################
#############       WARNING      ################
#################################################
# This file has been automatically generated.
# Any changes you make here will get overridden.
# Instead, make your changes in templates/*.dat
#################################################

from libcpp.map cimport map
from libcpp.pair cimport pair
from libcpp.vector cimport vector
from libcpp.unordered_map cimport unordered_map
from libcpp cimport bool
from libcpp.string cimport string
from cython.operator cimport dereference as deref
from cpython.exc cimport PyErr_NewException

cdef extern from "YODA/Config/YodaConfig.h" namespace "YODA":
     string version()


# Import the error handling C++ routine
cdef extern from "Python.h" nogil:
    ctypedef struct PyObject

cdef extern from "errors.hh" namespace "YODA":
    cdef PyObject* YodaExc_Exception
    cdef PyObject* YodaExc_BinningError
    cdef PyObject* YodaExc_RangeError
    cdef PyObject* YodaExc_LogicError
    cdef PyObject* YodaExc_WeightError
    cdef PyObject* YodaExc_AnnotationError
    cdef PyObject* YodaExc_ReadError
    cdef PyObject* YodaExc_WriteError
    cdef PyObject* YodaExc_UserError

    cdef void create_custom_exceptions()

    # Have a look in errors.cpp for implementation specifics
    cdef void yodaerr "YODA::translate_yoda_error" ()

ctypedef map[string, string] Annotations
ctypedef double (*dbl_dbl_fptr) (double)


# Math utils {{{
cdef extern from "YODA/Utils/MathUtils.h" namespace "YODA":
    bool isZero(double, double) except +yodaerr
    bool relFuzzyEquals(double, double, double) except +yodaerr
    bool fuzzyEquals(double, double, double) except +yodaerr
    bool fuzzyGtrEquals(double, double, double) except +yodaerr
    bool fuzzyLessEquals(double, double, double) except +yodaerr
    int index_between(double&, vector[double]& binedges) except +yodaerr
    double add(double, double, double) except +yodaerr
    double subtract(double, double, double) except +yodaerr
    double add_quad() except +yodaerr
    vector[double] logspace(size_t, double, double, bool) except +yodaerr
    vector[double] linspace(size_t, double, double, bool) except +yodaerr
# }}}


# Stats utils {{{
cdef extern from "YODA/Utils/StatsUtils.h" namespace "YODA":
    double effNumEntries(vector[double]&) except +yodaerr
    double mean(vector[double]&) except +yodaerr
    double covariance(vector[double]&, vector[double]&) except +yodaerr
    double correlation(vector[double]&, vector[double]&) except +yodaerr
    double RMS(vector[double]&, vector[double]&) except +yodaerr
    double naiveChi2reduced(vector[double]&, vector[double]&, vector[double]&, vector[double]&) except +yodaerr
    double naiveChi2(vector[double]&, vector[double]&, vector[double]&, vector[double]&) except +yodaerr
    vector[double] cdf(vector[double]) except +yodaerr
    double stdDev(vector[double]&, vector[double]&) except +yodaerr
    vector[vector[double]] weightedAverage(vector[double]&, vector[double]&, vector[double]&, vector[double]&) except +yodaerr
    double stdErr(vector[double]&, vector[double]&) except +yodaerr
    double variance(vector[double]&, vector[double]&) except +yodaerr
    double rms(vector[double]&, vector[double]&) except +yodaerr
    double pValFromKS(double, double, double, double) except +yodaerr
    double ksTest(vector[double]&, vector[double]&) except +yodaerr
# }}}


# Path utils {{{
cdef extern from "YODA/Utils/Paths.h" namespace "YODA":
    string libPath()
    string dataPath()
    string getLibPath()
    string getDataPath()
    vector[string] getYodaDataPath()

# }}}


# Dbn0D {{{
cdef extern from "YODA/Dbn.h" namespace "YODA":
    cdef cppclass Dbn0D:
        Dbn0D ()
        Dbn0D (Dbn0D)

        void fill(double weight, double fraction) except +yodaerr
        #void set(double numEntries, vector[double]& sumW, vector[double]& sumW2) except +yodaerr
        void set(double numEntries, double sumW, double sumW2) except +yodaerr

        Dbn0D operator+ (Dbn0D) except +yodaerr
        Dbn0D operator- (Dbn0D) except +yodaerr
        # TODO: += and -= operators

        double numEntries() except +yodaerr
        double effNumEntries() except +yodaerr
        size_t dim() except +yodaerr
        double errW() except +yodaerr
        string toString() except +yodaerr
        double relErrW() except +yodaerr
        double sumW2() except +yodaerr
        double sumW() except +yodaerr

#}}} Dbn0D


# Dbn1D {{{
cdef extern from "YODA/Dbn.h" namespace "YODA":
    cdef cppclass Dbn1D:
        Dbn1D ()
        Dbn1D (Dbn1D)

        void fill(double val, double weight, double fraction) except +yodaerr
        void set(double numEntries, vector[double]& sumW, vector[double]& sumW2) except +yodaerr
        Dbn1D operator+ (Dbn1D) except +yodaerr
        Dbn1D operator- (Dbn1D) except +yodaerr

        double errW() except +yodaerr
        string toString() except +yodaerr
        double sumW2() except +yodaerr
        double xVariance() except +yodaerr
        double stdErr(size_t) except +yodaerr
        double stdDev(size_t) except +yodaerr
        double effNumEntries() except +yodaerr
        double variance(size_t) except +yodaerr
        size_t dim() except +yodaerr
        double relStdErr(size_t) except +yodaerr
        double relErrW() except +yodaerr
        void scaleX(double) except +yodaerr
        double sumW() except +yodaerr
        double numEntries() except +yodaerr
        double mean(size_t) except +yodaerr
        double RMS(size_t) except +yodaerr
        double xRMS() except +yodaerr
        double sumWX() except +yodaerr
        double xStdErr() except +yodaerr
        double xMean() except +yodaerr
        double sumWX2() except +yodaerr
        double xStdDev() except +yodaerr

#}}} Dbn1D


# Dbn2D {{{
cdef extern from "YODA/Dbn.h" namespace "YODA":
    cdef cppclass Dbn2D:
        Dbn2D ()
        Dbn2D (Dbn2D)

        void fill(double x, double y, double weight, double fraction) except +yodaerr
        void set(double numEntries, vector[double]& sumW, vector[double]& sumW2, vector[double]& sumWcross) except +yodaerr

        Dbn2D operator + (Dbn2D) except +yodaerr
        Dbn2D operator - (Dbn2D) except +yodaerr
        # TODO: += and -= operators

        double yStdDev() except +yodaerr
        double errW() except +yodaerr
        string toString() except +yodaerr
        double sumW2() except +yodaerr
        double yStdErr() except +yodaerr
        double xVariance() except +yodaerr
        double stdErr(size_t) except +yodaerr
        double stdDev(size_t) except +yodaerr
        double effNumEntries() except +yodaerr
        double variance(size_t) except +yodaerr
        size_t dim() except +yodaerr
        double crossTerm(size_t, size_t) except +yodaerr
        double relStdErr(size_t) except +yodaerr
        double relErrW() except +yodaerr
        void scaleX(double) except +yodaerr
        double sumW() except +yodaerr
        void scaleXY(double, double) except +yodaerr
        double numEntries() except +yodaerr
        double sumWY2() except +yodaerr
        double mean(size_t) except +yodaerr
        double yMean() except +yodaerr
        double RMS(size_t) except +yodaerr
        double sumWY() except +yodaerr
        double xRMS() except +yodaerr
        double sumWX() except +yodaerr
        void scaleY(double) except +yodaerr
        double xStdErr() except +yodaerr
        double yVariance() except +yodaerr
        double xMean() except +yodaerr
        double sumWXY() except +yodaerr
        double sumWX2() except +yodaerr
        double yRMS() except +yodaerr
        double xStdDev() except +yodaerr

#}}} Dbn2D


# Dbn3D {{{
cdef extern from "YODA/Dbn.h" namespace "YODA":
    cdef cppclass Dbn3D:
        Dbn3D ()
        Dbn3D (Dbn3D)

        void fill(double x, double y, double z, double weight, double fraction)
        void set(double numEntries, vector[double]& sumW, vector[double]& sumW2, vector[double]& sumWcross) except +yodaerr

        Dbn3D operator + (Dbn3D) except +yodaerr
        Dbn3D operator - (Dbn3D) except +yodaerr
        # TODO: += and -= operators

        double yStdDev() except +yodaerr
        void scaleXYZ(double, double, double) except +yodaerr
        double errW() except +yodaerr
        string toString() except +yodaerr
        double zStdErr() except +yodaerr
        double sumWZ() except +yodaerr
        double sumW2() except +yodaerr
        double yStdErr() except +yodaerr
        double xVariance() except +yodaerr
        double stdErr(size_t) except +yodaerr
        double stdDev(size_t) except +yodaerr
        double effNumEntries() except +yodaerr
        double variance(size_t) except +yodaerr
        size_t dim() except +yodaerr
        double sumWXZ() except +yodaerr
        double crossTerm(size_t, size_t) except +yodaerr
        double relStdErr(size_t) except +yodaerr
        double relErrW() except +yodaerr
        void scaleX(double) except +yodaerr
        double sumW() except +yodaerr
        void scaleXY(double, double) except +yodaerr
        double zVariance() except +yodaerr
        double zStdDev() except +yodaerr
        double zRMS() except +yodaerr
        void scaleZ(double) except +yodaerr
        double sumWZ2() except +yodaerr
        double numEntries() except +yodaerr
        double sumWY2() except +yodaerr
        double mean(size_t) except +yodaerr
        double yMean() except +yodaerr
        double sumWYZ() except +yodaerr
        double RMS(size_t) except +yodaerr
        double zMean() except +yodaerr
        double sumWY() except +yodaerr
        void scaleYZ(double, double) except +yodaerr
        double xRMS() except +yodaerr
        double sumWX() except +yodaerr
        void scaleY(double) except +yodaerr
        double xStdErr() except +yodaerr
        double yVariance() except +yodaerr
        double xMean() except +yodaerr
        double sumWXY() except +yodaerr
        double sumWX2() except +yodaerr
        double yRMS() except +yodaerr
        void scaleXZ(double, double) except +yodaerr
        double xStdDev() except +yodaerr

#}}} Dbn3D


# Estimate {{{
cdef extern from "YODA/Estimate.h" namespace "YODA":
    cdef cppclass Estimate:
        Estimate () except +yodaerr
        Estimate (double val, pair[double, double]& err, string& source) except +yodaerr
        Estimate (Estimate&) except +yodaerr

        void setErr(pair[double, double]& err, string& source) except +yodaerr
        Estimate& add(Estimate&, string&) except +yodaerr
        Estimate& subtract(Estimate&, string&) except +yodaerr

        Estimate operator+ (Estimate&) except +yodaerr
        Estimate operator- (Estimate&) except +yodaerr
        # TODO: += and -= operators

        pair[double, double] quadSum(string&) except +yodaerr
        double val() except +yodaerr
        pair[double, double] err(string&) except +yodaerr
        double errNeg(string&) except +yodaerr
        double valMin(string&) except +yodaerr
        double relErrUp(string&) except +yodaerr
        size_t numErrs() except +yodaerr
        pair[double, double] errDownUp(string&) except +yodaerr
        pair[double, double] totalErr(string&) except +yodaerr
        double errAvg(string&) except +yodaerr
        void setVal(double) except +yodaerr
        bool hasSource(string&) except +yodaerr
        void rmErrs() except +yodaerr
        double totalErrPos(string&) except +yodaerr
        double quadSumPos(string&) except +yodaerr
        double errEnv(string&) except +yodaerr
        void renameSource(string&, string&) except +yodaerr
        pair[double, double] relErrDownUp(string&) except +yodaerr
        void reset() except +yodaerr
        double relErrAvg(string&) except +yodaerr
        double quadSumNeg(string&) except +yodaerr
        void deserializeSources(vector[string]&) except +yodaerr
        double totalErrEnv(string&) except +yodaerr
        double valueErr(string&) except +yodaerr
        double relTotalErrEnv(string&) except +yodaerr
        vector[string] sources() except +yodaerr
        double relTotalErrNeg(string&) except +yodaerr
        double relErrDown(string&) except +yodaerr
        vector[string] serializeSources() except +yodaerr
        void setValue(double) except +yodaerr
        double totalErrNeg(string&) except +yodaerr
        double quadSumEnv(string&) except +yodaerr
        pair[double, double] errNegPos(string) except +yodaerr
        double totalErrMin(string&) except +yodaerr
        pair[double, double] relTotalErr(string&) except +yodaerr
        void scale(double) except +yodaerr
        pair[double, double] relErr(string&) except +yodaerr
        double quadSumMin(string&) except +yodaerr
        double errUp(string&) except +yodaerr
        double quadSumAvg(string&) except +yodaerr
        double totalErrAvg(string&) except +yodaerr
        double totalErrMax(string&) except +yodaerr
        double relTotalErrPos(string&) except +yodaerr
        double errPos(string&) except +yodaerr
        double relErrEnv(string&) except +yodaerr
        double relTotalErrAvg(string&) except +yodaerr
        void rmSource(string&) except +yodaerr
        double errDown(string&) except +yodaerr
        double quadSumMax(string&) except +yodaerr
        double valMax(string&) except +yodaerr

#}}} Estimate


# Point {{{

cdef extern from "YODA/Point.h" namespace "YODA":
    cdef cppclass Point:

        void setErrs(size_t, pair[double,double]&) except +yodaerr

        double val(size_t) except +yodaerr
        double errPlus(size_t) except +yodaerr
        void scaleErr(size_t, double) except +yodaerr
        size_t dim() except +yodaerr
        void setErr(size_t, double) except +yodaerr
        void setErrMinus(size_t, double) except +yodaerr
        void setVal(size_t, double) except +yodaerr
        pair[double,double] errs(size_t) except +yodaerr
        void scale(size_t, double) except +yodaerr
        double min(size_t) except +yodaerr
        void clear() except +yodaerr
        void scaleVal(size_t, double) except +yodaerr
        double max(size_t) except +yodaerr
        double errMinus(size_t) except +yodaerr
        void setErrPlus(size_t, double) except +yodaerr
        double errAvg(size_t) except +yodaerr

#}}} Point


# Point1D {{{
cdef extern from "YODA/Point.h" namespace "YODA":
    cdef cppclass Point1D(Point):
        Point1D () except +yodaerr
        Point1D (Point1D p) except +yodaerr
        Point1D (vector[double]& vals, vector[double]& errdn, vector[double]& errup) except +yodaerr

        bool operator == (Point1D) except +yodaerr
        bool operator != (Point1D b) except +yodaerr
        bool operator < (Point1D b) except +yodaerr
        bool operator <= (Point1D b) except +yodaerr
        bool operator > (Point1D b) except +yodaerr
        bool operator >= (Point1D b) except +yodaerr

        void setX(double) except +yodaerr
        double xMin() except +yodaerr
        double xMax() except +yodaerr
        void scaleX(double) except +yodaerr
        double xErrMinus() except +yodaerr
        pair[double, double] xErrs() except +yodaerr
        double xErrPlus() except +yodaerr
        double x() except +yodaerr
        void setXErrMinus(double) except +yodaerr
        double xErrAvg() except +yodaerr
        void setXErrPlus(double) except +yodaerr

# }}} Point1D


# Point2D {{{
cdef extern from "YODA/Point.h" namespace "YODA":
    cdef cppclass Point2D(Point):
        Point2D () except +yodaerr
        Point2D (Point2D p) except +yodaerr
        Point2D (vector[double]& vals, vector[double]& errdn, vector[double]& errup) except +yodaerr

        bool operator == (Point2D) except +yodaerr
        bool operator != (Point2D b) except +yodaerr
        bool operator < (Point2D b) except +yodaerr
        bool operator <= (Point2D b) except +yodaerr
        bool operator > (Point2D b) except +yodaerr
        bool operator >= (Point2D b) except +yodaerr

        void setXY(double, double) except +yodaerr
        void setYErrPlus(double) except +yodaerr
        double xMax() except +yodaerr
        void scaleX(double) except +yodaerr
        pair[double, double] xErrs() except +yodaerr
        pair[double, double] yErrs() except +yodaerr
        double y() except +yodaerr
        double xErrPlus() except +yodaerr
        double x() except +yodaerr
        double yErrAvg() except +yodaerr
        void setX(double) except +yodaerr
        void setYErrMinus(double) except +yodaerr
        double yMin() except +yodaerr
        void setY(double) except +yodaerr
        double yMax() except +yodaerr
        double xErrMinus() except +yodaerr
        void scaleY(double) except +yodaerr
        pair[double, double] xy() except +yodaerr
        double xMin() except +yodaerr
        double yErrMinus() except +yodaerr
        double yErrPlus() except +yodaerr
        void setXErrMinus(double) except +yodaerr
        double xErrAvg() except +yodaerr
        void setXY(pair[double, double]&) except +yodaerr
        void setXErrPlus(double) except +yodaerr

# }}} Point2D


# Point3D {{{
cdef extern from "YODA/Point.h" namespace "YODA":
    cdef cppclass Point3D(Point):
        Point3D () except +yodaerr
        Point3D (Point3D& p) except +yodaerr
        Point3D (vector[double]& vals, vector[double]& errdn, vector[double]& errup) except +yodaerr

        bool operator == (Point3D b) except +yodaerr
        bool operator != (Point3D b) except +yodaerr
        bool operator < (Point3D b) except +yodaerr
        bool operator <= (Point3D b) except +yodaerr
        bool operator > (Point3D b) except +yodaerr
        bool operator >= (Point3D b) except +yodaerr

        void setZErrMinus(double) except +yodaerr
        double zMin() except +yodaerr
        double zErrAvg() except +yodaerr
        void setZErrPlus(double) except +yodaerr
        void setXY(double, double) except +yodaerr
        void setYErrPlus(double) except +yodaerr
        double xMax() except +yodaerr
        void scaleX(double) except +yodaerr
        void setZ(double) except +yodaerr
        pair[double, double] xErrs() except +yodaerr
        pair[double, double] yErrs() except +yodaerr
        double y() except +yodaerr
        double xErrPlus() except +yodaerr
        pair[double, double] zErrs() except +yodaerr
        double zMax() except +yodaerr
        double x() except +yodaerr
        void scaleZ(double) except +yodaerr
        double yErrAvg() except +yodaerr
        void setX(double) except +yodaerr
        void setYErrMinus(double) except +yodaerr
        double yMin() except +yodaerr
        void setY(double) except +yodaerr
        double yMax() except +yodaerr
        double xErrMinus() except +yodaerr
        void setXYZ(double, double, double) except +yodaerr
        double zErrPlus() except +yodaerr
        void scaleY(double) except +yodaerr
        pair[double, double] xy() except +yodaerr
        double zErrMinus() except +yodaerr
        double xMin() except +yodaerr
        double z() except +yodaerr
        double yErrMinus() except +yodaerr
        double yErrPlus() except +yodaerr
        void setXErrMinus(double) except +yodaerr
        double xErrAvg() except +yodaerr
        void setXY(pair[double, double]&) except +yodaerr
        void setXErrPlus(double) except +yodaerr

#}}} Point3D


# Point4D {{{
cdef extern from "YODA/Point.h" namespace "YODA":
    cdef cppclass Point4D(Point):
        Point4D () except +yodaerr
        Point4D (Point4D& p) except +yodaerr
        Point4D (vector[double]& vals, vector[double]& errdn, vector[double]& errup) except +yodaerr

        void scale(size_t i, double scale) except +yodaerr

        bool operator == (Point4D b) except +yodaerr
        bool operator != (Point4D b) except +yodaerr
        bool operator < (Point4D b) except +yodaerr
        bool operator <= (Point4D b) except +yodaerr
        bool operator > (Point4D b) except +yodaerr
        bool operator >= (Point4D b) except +yodaerr
#}}} Point4D



# XAxisMixin {{{
cdef extern from "YODA/Utils/BinnedUtils.h" namespace "YODA":
    cdef cppclass XAxisMixin[T]:

        vector[T] xWidths(bool) except +yodaerr
        size_t numBinsX(bool) except +yodaerr
        vector[T] xMins(bool) except +yodaerr
        vector[T] xMids(bool) except +yodaerr
        void rebinXBy(unsigned int, size_t, size_t) except +yodaerr
        T xMin() except +yodaerr
        vector[T] xMaxs(bool) except +yodaerr
        void rebinXTo(vector[double]&) except +yodaerr
        vector[T] xEdges(bool) except +yodaerr
        T xMax() except +yodaerr

#}}} XAxisMixin

# XStatsMixin {{{
cdef extern from "YODA/Utils/BinnedUtils.h" namespace "YODA":
    cdef cppclass XStatsMixin:

        double xStdDev(bool) except +yodaerr
        double xMean(bool) except +yodaerr
        double xStdErr(bool) except +yodaerr
        double xRMS(bool) except +yodaerr
        double xVariance(bool) except +yodaerr
        vector[double] xMeans(bool) except +yodaerr

#}}} XStatsMixin

# YAxisMixin {{{
cdef extern from "YODA/Utils/BinnedUtils.h" namespace "YODA":
    cdef cppclass YAxisMixin[T]:

        T yMin() except +yodaerr
        void rebinYTo(vector[double]&) except +yodaerr
        T yMax() except +yodaerr
        void rebinYBy(unsigned int, size_t, size_t) except +yodaerr
        vector[T] yEdges(bool) except +yodaerr
        size_t numBinsY(bool) except +yodaerr
        vector[T] yMids(bool) except +yodaerr
        vector[T] yMins(bool) except +yodaerr
        vector[T] yMaxs(bool) except +yodaerr
        vector[T] yWidths(bool) except +yodaerr

#}}} YAxisMixin

# YStatsMixin {{{
cdef extern from "YODA/Utils/BinnedUtils.h" namespace "YODA":
    cdef cppclass YStatsMixin:

        double yMean(bool) except +yodaerr
        double yStdDev(bool) except +yodaerr
        double yStdErr(bool) except +yodaerr
        vector[double] yMeans(bool) except +yodaerr
        double yRMS(bool) except +yodaerr
        double yVariance(bool) except +yodaerr

#}}} YStatsMixin

# ZAxisMixin {{{
cdef extern from "YODA/Utils/BinnedUtils.h" namespace "YODA":
    cdef cppclass ZAxisMixin[T]:

        vector[T] zEdges(bool) except +yodaerr
        void rebinZBy(unsigned int, size_t, size_t) except +yodaerr
        void rebinZTo(vector[double]&) except +yodaerr
        vector[T] zWidths(bool) except +yodaerr
        T zMin() except +yodaerr
        vector[T] zMids(bool) except +yodaerr
        size_t numBinsZ(bool) except +yodaerr
        vector[T] zMaxs(bool) except +yodaerr
        vector[T] zMins(bool) except +yodaerr
        T zMax() except +yodaerr

#}}} ZAxisMixin

# ZStatsMixin {{{
cdef extern from "YODA/Utils/BinnedUtils.h" namespace "YODA":
    cdef cppclass ZStatsMixin:

        double zStdDev(bool) except +yodaerr
        double zStdErr(bool) except +yodaerr
        vector[double] zMeans(bool) except +yodaerr
        double zMean(bool) except +yodaerr
        double zRMS(bool) except +yodaerr
        double zVariance(bool) except +yodaerr

#}}} ZStatsMixin


# AnalysisObject {{{
cdef extern from "YODA/AnalysisObject.h" namespace "YODA":
    cdef cppclass AnalysisObject:
        # Constructors
        AnalysisObject(string& type, string& path, string& title) except +yodaerr
        AnalysisObject(string& type, string& path, AnalysisObject& ao, string& title) except +yodaerr
        AnalysisObject()

        string _config() except +yodaerr
        void reset() except +yodaerr
        void setPath(string& path) except +yodaerr
        int dim() except +yodaerr

        ## Annotations
        vector[string] annotations() except +yodaerr
        void setAnnotation(string, string) except +yodaerr
        string annotation(string& key) except +yodaerr
        string annotation(string& key, string default) except +yodaerr

        ## (De-)Serialization
        size_t lengthContent(bool) except +yodaerr
        vector[double] serializeContent(bool) except +yodaerr
        void deserializeContent(vector[double]& data) except +yodaerr

        string type() except +yodaerr
        void clearAnnotations() except +yodaerr
        bool hasAnnotation(string&) except +yodaerr
        size_t lengthMeta(bool, bool) except +yodaerr
        string path() except +yodaerr
        void deserializeMeta(vector[string]&, bool, bool) except +yodaerr
        vector[string] serializeMeta(bool, bool) except +yodaerr
        void rmAnnotation(string&) except +yodaerr
        string title() except +yodaerr
        string name() except +yodaerr
        void setTitle(string&) except +yodaerr

# }}} AnalysisObject


# Fillable {{{
cdef extern from "YODA/Fillable.h" namespace "YODA":
    cdef cppclass Fillable:

        size_t nanCount() except +yodaerr
        void reset() except +yodaerr
        size_t fillDim() except +yodaerr
        double nanSumW() except +yodaerr
        double nanSumW2() except +yodaerr

#}}} Fillable

# Scatter {{{
cdef extern from "YODA/Scatter.h" namespace "YODA":
    cdef cppclass Scatter:

        void rmPoint(size_t) except +yodaerr
        void scale(size_t, double) except +yodaerr
        size_t numPoints() except +yodaerr
        double min(size_t) except +yodaerr
        vector[pair[double,double]] edges(size_t) except +yodaerr
        void scaleVal(size_t, double) except +yodaerr
        double max(size_t) except +yodaerr
        vector[double] maxs(size_t) except +yodaerr
        vector[double] vals(size_t) except +yodaerr
        vector[pair[double,double]] errs(size_t) except +yodaerr
        void scaleErr(size_t, double) except +yodaerr
        vector[double] errAvgs(size_t) except +yodaerr
        vector[double] mins(size_t) except +yodaerr

#}}} Scatter


# Scatter1D {{{
cdef extern from "YODA/Scatter.h" namespace "YODA":
    cdef cppclass Scatter1D(AnalysisObject,Scatter):
        Scatter1D() except +yodaerr
        Scatter1D(string&, string&) except +yodaerr
        Scatter1D(Scatter1D&, string&)

        Scatter1D clone() except +yodaerr
        Scatter1D* newclone() except +yodaerr

        Point1D& point(size_t) except +yodaerr
        vector[Point1D]& points() except +yodaerr

        void addPoint(Point1D&) except +yodaerr
        #void addPoints(vector[Point1D]&) except +yodaerr

        void rmPoints(vector[size_t]) except +yodaerr

        void combineWith(Scatter1D&) except +yodaerr
        void combineWith(vector[Scatter1D]&) except +yodaerr

        vector[double] xVals() except +yodaerr
        double xMin() except +yodaerr
        double xMax() except +yodaerr
        vector[double] xMins() except +yodaerr
        vector[double] xMaxs() except +yodaerr
        vector[double] xErrAvgs() except +yodaerr
        vector[pair[double,double]] xErrs() except +yodaerr

#}}} Scatter1D


# Scatter2D {{{
cdef extern from "YODA/Scatter.h" namespace "YODA":
    cdef cppclass Scatter2D(AnalysisObject,Scatter):
        Scatter2D() except +yodaerr
        Scatter2D(string&, string&) except +yodaerr
        Scatter2D(Scatter2D&, string&)

        Scatter2D clone() except +yodaerr
        Scatter2D* newclone() except +yodaerr

        Point2D& point(size_t) except +yodaerr
        vector[Point2D]& points() except +yodaerr

        void addPoint(Point2D&) except +yodaerr
        #void addPoints(vector[Point2D]&) except +yodaerr

        void rmPoints(vector[size_t]) except +yodaerr

        void combineWith(Scatter2D&) except +yodaerr
        void combineWith(vector[Scatter2D]&) except +yodaerr

        double yMin() except +yodaerr
        vector[double] xVals() except +yodaerr
        double xMin() except +yodaerr
        double xMax() except +yodaerr
        double yMax() except +yodaerr
        vector[double] yVals() except +yodaerr
        vector[double] yErrAvgs() except +yodaerr
        vector[pair[double,double]] yErrs() except +yodaerr
        vector[double] xMins() except +yodaerr
        vector[double] xMaxs() except +yodaerr
        vector[double] xErrAvgs() except +yodaerr
        vector[double] yMins() except +yodaerr
        vector[pair[double,double]] xErrs() except +yodaerr
        vector[double] yMaxs() except +yodaerr

    #void Scatter2D_transformX "YODA::transformX" (Scatter2D&, dbl_dbl_fptr)
    #void Scatter2D_transformY "YODA::transformY" (Scatter2D&, dbl_dbl_fptr)

#}}} Scatter2D


# Scatter3D {{{
cdef extern from "YODA/Scatter.h" namespace "YODA":
    cdef cppclass Scatter3D(AnalysisObject,Scatter):
        Scatter3D() except +yodaerr
        Scatter3D(string&, string&) except +yodaerr
        Scatter3D(Scatter3D&, string&)

        Scatter3D clone() except +yodaerr
        Scatter3D* newclone() except +yodaerr

        Point3D& point(size_t) except +yodaerr
        vector[Point3D]& points() except +yodaerr

        void addPoint(Point3D&) except +yodaerr
        #void addPoints(vector[Point3D]&) except +yodaerr

        void rmPoints(vector[size_t]) except +yodaerr

        void combineWith(Scatter3D&) except +yodaerr
        void combineWith(vector[Scatter3D]&) except +yodaerr

        double zMin() except +yodaerr
        vector[double] xErrAvgs() except +yodaerr
        vector[double] zVals() except +yodaerr
        double xMax() except +yodaerr
        vector[double] yVals() except +yodaerr
        vector[double] yErrAvgs() except +yodaerr
        vector[double] zMins() except +yodaerr
        double zMax() except +yodaerr
        vector[double] yMins() except +yodaerr
        double yMin() except +yodaerr
        vector[double] xVals() except +yodaerr
        double yMax() except +yodaerr
        vector[double] xMins() except +yodaerr
        vector[double] xMaxs() except +yodaerr
        vector[pair[double,double]] xErrs() except +yodaerr
        vector[double] zMaxs() except +yodaerr
        vector[pair[double,double]] zErrs() except +yodaerr
        vector[double] zErrAvgs() except +yodaerr
        double xMin() except +yodaerr
        vector[pair[double,double]] yErrs() except +yodaerr
        vector[double] yMaxs() except +yodaerr

    #void Scatter3D_transformX "YODA::transformX" (Scatter3D&, dbl_dbl_fptr)
    #void Scatter3D_transformY "YODA::transformY" (Scatter3D&, dbl_dbl_fptr)
    #void Scatter3D_transformZ "YODA::transformZ" (Scatter3D&, dbl_dbl_fptr)

#}}} Scatter3D


# Scatter4D {{{
cdef extern from "YODA/Scatter.h" namespace "YODA":
    cdef cppclass Scatter4D(AnalysisObject,Scatter):
        Scatter4D() except +yodaerr
        Scatter4D(string&, string&) except +yodaerr
        Scatter4D(Scatter4D&, string&)

        Scatter4D clone() except +yodaerr
        Scatter4D* newclone() except +yodaerr

        Point4D& point(size_t) except +yodaerr
        vector[Point4D]& points() except +yodaerr

        void addPoint(Point4D&) except +yodaerr
        #void addPoints(vector[Point3D]&) except +yodaerr

        void rmPoints(vector[size_t]) except +yodaerr

        void combineWith(Scatter4D&) except +yodaerr
        void combineWith(vector[Scatter4D]&) except +yodaerr

#}}} Scatter4D


# Estimate0D {{{
cdef extern from "YODA/Estimate0D.h" namespace "YODA":
    cdef cppclass Estimate0D(AnalysisObject,Estimate):
        Estimate0D(string& path, string& title) except +yodaerr
        Estimate0D (double val, pair[double, double]& err, string& source, string& path, string& title) except +yodaerr
        Estimate0D (Estimate0D&) except +yodaerr

        Estimate0D clone() except +yodaerr
        Estimate0D* newclone() except +yodaerr

        Scatter1D mkScatter(string&, string&) except +yodaerr



#}}} Estimate0D

# Counter {{{
cdef extern from "YODA/Counter.h" namespace "YODA":
    cdef cppclass Counter(AnalysisObject,Fillable):
        Counter(string& path, string& title) except +yodaerr

        Counter(Counter& c, string path)

        Counter clone() except +yodaerr
        Counter* newclone() except +yodaerr

        int fill(double weight, double fraction) except +yodaerr
        void set(double numEntries, double sumW, double sumW2) except +yodaerr
        Dbn0D& dbn() except +yodaerr

        Estimate0D mkEstimate(string&) except +yodaerr
        Scatter1D mkScatter(string&) except +yodaerr

        # operator += (Counter) except +yodaerr
        # operator -= (Counter) except +yodaerr

        double effNumEntries(False) except +yodaerr
        double numEntries(False) except +yodaerr
        void scaleW(double) except +yodaerr
        double val(False) except +yodaerr
        double err() except +yodaerr
        double sumW(False) except +yodaerr
        double sumW2(False) except +yodaerr
        double relErr() except +yodaerr

#}}} Counter

# Axis {{{
cdef extern from "YODA/BinnedAxis.h" namespace "YODA":
    cdef cppclass Axis[T]:
        Axis() except +yodaerr
        Axis(vector[T]& edges) except +yodaerr

        string type() except +yodaerr
        vector[T] maxs(bool) except +yodaerr
        T max(size_t) except +yodaerr
        T mid(size_t) except +yodaerr
        T min(size_t) except +yodaerr
        vector[T] edges() except +yodaerr
        size_t numBins(bool) except +yodaerr
        size_t index(T&) except +yodaerr
        T edge(size_t) except +yodaerr
        vector[T] mids(bool) except +yodaerr
        vector[T] mins(bool) except +yodaerr
        vector[T] widths(bool) except +yodaerr
        T width(size_t) except +yodaerr

#}}} Axis

# BinnedHisto1D {{{
cdef extern from "YODA/Histo.h" namespace "YODA":
    cdef cppclass BinnedHisto1D[A1](AnalysisObject,Fillable,XAxisMixin[A1],XStatsMixin):
        BinnedHisto1D() except +yodaerr

        BinnedHisto1D(vector[A1]& binedges,
                      string& path,
                      string& title) except +yodaerr

        BinnedHisto1D(BinnedHisto1D[A1] &h) except +yodaerr

        BinnedHisto1D[A1] clone() except +yodaerr
        BinnedHisto1D[A1]* newclone() except +yodaerr

        int fill(A1 x, double weight, double fraction) except +yodaerr

        #void mergeBins(size_t, size_t) except +yodaerr

        vector[Dbn1D]& bins()
        Dbn1D& bin(size_t ix) except +yodaerr
        Dbn1D& binAt(A1 x) except +yodaerr
        size_t indexAt(A1 x) except +yodaerr
        void set(size_t, Dbn1D&) except +yodaerr

        # Whole histo data
        #double integralTo(int, bool) except +yodaerr
        #double integralRange(int, int) except +yodaerr

        vector[size_t] _global2local(size_t) except +yodaerr
        size_t _local2global(vector[size_t]&) except +yodaerr

        operator == (BinnedHisto1D[A1]) except +yodaerr
        operator != (BinnedHisto1D[A1]) except +yodaerr

        double effNumEntries(bool) except +yodaerr
        BinnedEstimate1D[A1] mkEstimate(string&, string&, bool, double) except +yodaerr
        void scale(size_t, double) except +yodaerr
        double dVol(bool) except +yodaerr
        double mean(size_t, bool) except +yodaerr
        size_t numBinsAt(size_t, bool) except +yodaerr
        double stdDev(size_t, bool) except +yodaerr
        vector[size_t] maskedBins() except +yodaerr
        BinnedEstimate1D[A1] mkBinnedEffNumEntries(string&, string&, bool, bool, double) except +yodaerr
        size_t binDim() except +yodaerr
        void maskBin(size_t, bool) except +yodaerr
        double rms(size_t, bool) except +yodaerr
        void scaleW(double) except +yodaerr
        double densityError(bool) except +yodaerr
        Scatter2D mkScatter(string&, bool, bool, bool, bool, double) except +yodaerr
        vector[size_t] shape(bool) except +yodaerr
        double sumWA(size_t, bool) except +yodaerr
        double maxDensity(bool) except +yodaerr
        double sumWA2(size_t, bool) except +yodaerr
        size_t numBins(bool, bool) except +yodaerr
        double variance(size_t, bool) except +yodaerr
        double integralError(bool) except +yodaerr
        bool isMasked(size_t) except +yodaerr
        double numEntries(bool) except +yodaerr
        double sumW(bool) except +yodaerr
        void maskSlice(size_t, size_t, bool) except +yodaerr
        double integral(bool) except +yodaerr
        vector[double] means(size_t, bool) except +yodaerr
        double sumW2(bool) except +yodaerr
        double density(bool) except +yodaerr
        double stdErr(size_t, bool) except +yodaerr
        double integralRangeError(size_t, size_t) except +yodaerr
        void clearBins() except +yodaerr
        void normalize(double, bool) except +yodaerr
        double densitySum(bool) except +yodaerr
        double integralRange(size_t, size_t) except +yodaerr
        double integralTo(size_t) except +yodaerr
        void maskBins(vector[size_t]&, bool) except +yodaerr
        bool isVisible(size_t) except +yodaerr

#}}} BinnedHisto1D


# BinnedHisto2D {{{
cdef extern from "YODA/Histo.h" namespace "YODA":
    cdef cppclass BinnedHisto2D[A1,A2](AnalysisObject,Fillable,XAxisMixin[A1],XStatsMixin,YAxisMixin[A2],YStatsMixin):
        BinnedHisto2D() except +yodaerr

        BinnedHisto2D(vector[A1]& xedges, vector[A2]& yedges,
                      string path, string title) except +yodaerr

        BinnedHisto2D(BinnedHisto2D[A1,A2]& h)

        BinnedHisto2D[A1,A2] clone() except +yodaerr
        BinnedHisto2D[A1,A2]* newclone() except +yodaerr

        int fill(A1 x, A2 y, double weight, double fraction) except +yodaerr

        vector[Dbn2D]& bins() except +yodaerr
        Dbn2D& bin(size_t ix) except +yodaerr
        Dbn2D& binAt(A1 x, A2 y) except +yodaerr
        size_t indexAt(A1 x, A2 y) except +yodaerr
        void set(size_t, Dbn2D&) except +yodaerr

        vector[size_t] _global2local(size_t) except +yodaerr
        size_t _local2global(vector[size_t]&) except +yodaerr

        operator == (BinnedHisto2D[A1,A2]) except +yodaerr
        operator != (BinnedHisto2D[A1,A2]) except +yodaerr

        double effNumEntries(bool) except +yodaerr
        void scale(size_t, double) except +yodaerr
        double dVol(bool) except +yodaerr
        double mean(size_t, bool) except +yodaerr
        size_t numBinsAt(size_t, bool) except +yodaerr
        double stdDev(size_t, bool) except +yodaerr
        vector[size_t] maskedBins() except +yodaerr
        size_t binDim() except +yodaerr
        void maskBin(size_t, bool) except +yodaerr
        double rms(size_t, bool) except +yodaerr
        BinnedEstimate2D[A1,A2] mkEstimate(string&, string&, bool, double) except +yodaerr
        void scaleW(double) except +yodaerr
        double densityError(bool) except +yodaerr
        vector[size_t] shape(bool) except +yodaerr
        double sumWA(size_t, bool) except +yodaerr
        double maxDensity(bool) except +yodaerr
        double sumWA2(size_t, bool) except +yodaerr
        size_t numBins(bool, bool) except +yodaerr
        double variance(size_t, bool) except +yodaerr
        double integralError(bool) except +yodaerr
        bool isMasked(size_t) except +yodaerr
        double numEntries(bool) except +yodaerr
        double sumW(bool) except +yodaerr
        void maskSlice(size_t, size_t, bool) except +yodaerr
        double integral(bool) except +yodaerr
        vector[double] means(size_t, bool) except +yodaerr
        double sumW2(bool) except +yodaerr
        double density(bool) except +yodaerr
        double stdErr(size_t, bool) except +yodaerr
        Scatter3D mkScatter(string&, bool, bool, bool, bool, double) except +yodaerr
        double integralRangeError(size_t, size_t) except +yodaerr
        void clearBins() except +yodaerr
        BinnedEstimate2D[A1,A2] mkBinnedEffNumEntries(string&, string&, bool, bool, double) except +yodaerr
        void normalize(double, bool) except +yodaerr
        double densitySum(bool) except +yodaerr
        double integralRange(size_t, size_t) except +yodaerr
        double integralTo(size_t) except +yodaerr
        void maskBins(vector[size_t]&, bool) except +yodaerr
        bool isVisible(size_t) except +yodaerr

# BinnedHisto2D }}}


# BinnedHisto3D {{{
cdef extern from "YODA/Histo.h" namespace "YODA":
    cdef cppclass BinnedHisto3D[A1,A2,A3](AnalysisObject,Fillable,XAxisMixin[A1],XStatsMixin,YAxisMixin[A2],YStatsMixin,YAxisMixin[A2],ZAxisMixin[A3],ZStatsMixin):
        BinnedHisto3D() except +yodaerr

        BinnedHisto3D(vector[A1]& xedges, vector[A2]& yedges, vector[A3]& zedges,
                      string path, string title) except +yodaerr

        BinnedHisto3D(BinnedHisto3D[A1,A2,A3]& h)

        BinnedHisto3D[A1,A2,A3] clone() except +yodaerr
        BinnedHisto3D[A1,A2,A3]* newclone() except +yodaerr

        int fill(A1 x, A2 y, A3 z, double weight, double fraction) except +yodaerr

        # void mergeBins(size_t, size_t) except +yodaerr

        vector[Dbn3D]& bins() except +yodaerr
        Dbn3D& bin(size_t ix) except +yodaerr
        Dbn3D& binAt(A1 x, A2 y, A3 z) except +yodaerr
        size_t indexAt(A1 x, A2 y, A3 z) except +yodaerr
        void set(size_t, Dbn3D&) except +yodaerr

        vector[size_t] _global2local(size_t) except +yodaerr
        size_t _local2global(vector[size_t]&) except +yodaerr

        operator == (BinnedHisto3D[A1,A2,A3]) except +yodaerr
        operator != (BinnedHisto3D[A1,A2,A3]) except +yodaerr

        double effNumEntries(bool) except +yodaerr
        void scale(size_t, double) except +yodaerr
        double dVol(bool) except +yodaerr
        BinnedEstimate3D[A1,A2,A3] mkBinnedEffNumEntries(string&, string&, bool, bool, double) except +yodaerr
        double mean(size_t, bool) except +yodaerr
        size_t numBinsAt(size_t, bool) except +yodaerr
        double stdDev(size_t, bool) except +yodaerr
        vector[size_t] maskedBins() except +yodaerr
        size_t binDim() except +yodaerr
        void maskBin(size_t, bool) except +yodaerr
        double rms(size_t, bool) except +yodaerr
        void scaleW(double) except +yodaerr
        double densityError(bool) except +yodaerr
        vector[size_t] shape(bool) except +yodaerr
        double sumWA(size_t, bool) except +yodaerr
        double maxDensity(bool) except +yodaerr
        double sumWA2(size_t, bool) except +yodaerr
        size_t numBins(bool, bool) except +yodaerr
        double variance(size_t, bool) except +yodaerr
        Scatter4D mkScatter(string&, bool, bool, bool, bool, double) except +yodaerr
        double integralError(bool) except +yodaerr
        bool isMasked(size_t) except +yodaerr
        double numEntries(bool) except +yodaerr
        double sumW(bool) except +yodaerr
        void maskSlice(size_t, size_t, bool) except +yodaerr
        double integral(bool) except +yodaerr
        vector[double] means(size_t, bool) except +yodaerr
        double sumW2(bool) except +yodaerr
        double density(bool) except +yodaerr
        double stdErr(size_t, bool) except +yodaerr
        double integralRangeError(size_t, size_t) except +yodaerr
        void clearBins() except +yodaerr
        void normalize(double, bool) except +yodaerr
        double densitySum(bool) except +yodaerr
        double integralRange(size_t, size_t) except +yodaerr
        double integralTo(size_t) except +yodaerr
        BinnedEstimate3D[A1,A2,A3] mkEstimate(string&, string&, bool, double) except +yodaerr
        void maskBins(vector[size_t]&, bool) except +yodaerr
        bool isVisible(size_t) except +yodaerr

# BinnedHisto3D }}}


# BinnedProfile1D {{{
cdef extern from "YODA/Profile.h" namespace "YODA":
    cdef cppclass BinnedProfile1D[A1](AnalysisObject,Fillable,XAxisMixin[A1],XStatsMixin):
        BinnedProfile1D() except +yodaerr

        BinnedProfile1D(vector[A1]& edges, string path, string title) except +yodaerr

        BinnedProfile1D(BinnedProfile1D[A1]& p) except +yodaerr

        BinnedProfile1D[A1] clone() except +yodaerr
        BinnedProfile1D[A1]* newclone() except +yodaerr

        int fill(A1 x, double y, double weight, double fraction) except +yodaerr

        #void mergeBins(size_t, size_t) except +yodaerr

        vector[Dbn2D]& bins() except +yodaerr
        Dbn2D& bin(size_t ix) except +yodaerr
        Dbn2D& binAt(A1 x) except +yodaerr
        size_t indexAt(A1 x) except +yodaerr
        void set(size_t, Dbn2D&) except +yodaerr

        vector[size_t] _global2local(size_t) except +yodaerr
        size_t _local2global(vector[size_t]&) except +yodaerr

        operator == (BinnedProfile1D[A1]) except +yodaerr
        operator != (BinnedProfile1D[A1]) except +yodaerr

        double effNumEntries(bool) except +yodaerr
        BinnedEstimate1D[A1] mkEstimate(string&, string&, bool, double) except +yodaerr
        void scale(size_t, double) except +yodaerr
        double dVol(bool) except +yodaerr
        double mean(size_t, bool) except +yodaerr
        size_t numBinsAt(size_t, bool) except +yodaerr
        double stdDev(size_t, bool) except +yodaerr
        vector[size_t] maskedBins() except +yodaerr
        BinnedHisto1D[A1] mkHisto(string&) except +yodaerr
        BinnedEstimate1D[A1] mkBinnedEffNumEntries(string&, string&, bool, bool, double) except +yodaerr
        size_t binDim() except +yodaerr
        void maskBin(size_t, bool) except +yodaerr
        double rms(size_t, bool) except +yodaerr
        void scaleW(double) except +yodaerr
        double densityError(bool) except +yodaerr
        Scatter2D mkScatter(string&, bool, bool, bool, bool, double) except +yodaerr
        vector[size_t] shape(bool) except +yodaerr
        double sumWA(size_t, bool) except +yodaerr
        double maxDensity(bool) except +yodaerr
        double sumWA2(size_t, bool) except +yodaerr
        size_t numBins(bool, bool) except +yodaerr
        double variance(size_t, bool) except +yodaerr
        double integralError(bool) except +yodaerr
        bool isMasked(size_t) except +yodaerr
        double numEntries(bool) except +yodaerr
        double sumW(bool) except +yodaerr
        void maskSlice(size_t, size_t, bool) except +yodaerr
        double integral(bool) except +yodaerr
        vector[double] means(size_t, bool) except +yodaerr
        double sumW2(bool) except +yodaerr
        double density(bool) except +yodaerr
        double stdErr(size_t, bool) except +yodaerr
        double integralRangeError(size_t, size_t) except +yodaerr
        void clearBins() except +yodaerr
        void normalize(double, bool) except +yodaerr
        double densitySum(bool) except +yodaerr
        double integralRange(size_t, size_t) except +yodaerr
        double integralTo(size_t) except +yodaerr
        void maskBins(vector[size_t]&, bool) except +yodaerr
        bool isVisible(size_t) except +yodaerr

#}}} BinnedProfile1D



# BinnedProfile2D {{{
cdef extern from "YODA/Profile.h" namespace "YODA":
    cdef cppclass BinnedProfile2D[A1,A2](AnalysisObject,Fillable,XAxisMixin[A1],XStatsMixin,YAxisMixin[A2],YStatsMixin):
        BinnedProfile2D() except +yodaerr

        BinnedProfile2D(vector[A1]& xedges, vector[A2]& yedges,
                        string path, string title) except +yodaerr

        BinnedProfile2D(BinnedProfile2D[A1,A2]& p) except +yodaerr

        BinnedProfile2D clone() except +yodaerr
        BinnedProfile2D* newclone() except +yodaerr

        # TODO: add missing functions and enable refs + exceptions when Cython allows

        int fill(A1 x, A2 y, double z, double weight, double fraction) except +yodaerr

        # void mergeBins(size_t, size_t) except +yodaerr

        vector[Dbn3D]& bins() except +yodaerr
        Dbn3D& bin(size_t ix) except +yodaerr
        Dbn3D& binAt(A1 x, A2 y) except +yodaerr
        size_t indexAt(A1 x, A2 y) except +yodaerr
        void set(size_t, Dbn3D&) except +yodaerr

        vector[size_t] _global2local(size_t) except +yodaerr
        size_t _local2global(vector[size_t]&) except +yodaerr

        operator == (BinnedProfile2D[A1,A2]) except +yodaerr
        operator != (BinnedProfile2D[A1,A2]) except +yodaerr

        double effNumEntries(bool) except +yodaerr
        void scale(size_t, double) except +yodaerr
        double dVol(bool) except +yodaerr
        double mean(size_t, bool) except +yodaerr
        size_t numBinsAt(size_t, bool) except +yodaerr
        double stdDev(size_t, bool) except +yodaerr
        vector[size_t] maskedBins() except +yodaerr
        size_t binDim() except +yodaerr
        void maskBin(size_t, bool) except +yodaerr
        double rms(size_t, bool) except +yodaerr
        BinnedEstimate2D[A1,A2] mkEstimate(string&, string&, bool, double) except +yodaerr
        void scaleW(double) except +yodaerr
        BinnedHisto2D[A1,A2] mkHisto(string&) except +yodaerr
        double densityError(bool) except +yodaerr
        vector[size_t] shape(bool) except +yodaerr
        double sumWA(size_t, bool) except +yodaerr
        double maxDensity(bool) except +yodaerr
        double sumWA2(size_t, bool) except +yodaerr
        size_t numBins(bool, bool) except +yodaerr
        double variance(size_t, bool) except +yodaerr
        double integralError(bool) except +yodaerr
        bool isMasked(size_t) except +yodaerr
        double numEntries(bool) except +yodaerr
        double sumW(bool) except +yodaerr
        void maskSlice(size_t, size_t, bool) except +yodaerr
        double integral(bool) except +yodaerr
        vector[double] means(size_t, bool) except +yodaerr
        double sumW2(bool) except +yodaerr
        double density(bool) except +yodaerr
        double stdErr(size_t, bool) except +yodaerr
        Scatter3D mkScatter(string&, bool, bool, bool, bool, double) except +yodaerr
        double integralRangeError(size_t, size_t) except +yodaerr
        void clearBins() except +yodaerr
        BinnedEstimate2D[A1,A2] mkBinnedEffNumEntries(string&, string&, bool, bool, double) except +yodaerr
        void normalize(double, bool) except +yodaerr
        double densitySum(bool) except +yodaerr
        double integralRange(size_t, size_t) except +yodaerr
        double integralTo(size_t) except +yodaerr
        void maskBins(vector[size_t]&, bool) except +yodaerr
        bool isVisible(size_t) except +yodaerr

#}}} BinnedProfile2D


# BinnedEstimate1D {{{
cdef extern from "YODA/BinnedEstimate.h" namespace "YODA":
    cdef cppclass BinnedEstimate1D[A1](AnalysisObject, XAxisMixin[A1]):
        BinnedEstimate1D() except +yodaerr
        BinnedEstimate1D(vector[A1]& edges, string path, string title) except +yodaerr
        BinnedEstimate1D(BinnedEstimate1D[A1]& p) except +yodaerr

        BinnedEstimate1D[A1] clone() except +yodaerr
        BinnedEstimate1D[A1]* newclone() except +yodaerr

        vector[Estimate]& bins() except +yodaerr
        Estimate& bin(size_t index) except +yodaerr
        Estimate& binAt(A1 x) except +yodaerr
        size_t indexAt(A1 x) except +yodaerr
        void set(size_t, Estimate&) except +yodaerr

        vector[size_t] _global2local(size_t) except +yodaerr
        size_t _local2global(vector[size_t]&) except +yodaerr

        operator == (BinnedEstimate1D[A1]) except +yodaerr
        operator != (BinnedEstimate1D[A1]) except +yodaerr

        size_t numBinsAt(size_t, bool) except +yodaerr
        vector[size_t] maskedBins() except +yodaerr
        size_t binDim() except +yodaerr
        void maskBin(size_t, bool) except +yodaerr
        Scatter2D mkScatter(string&, string&, bool, bool) except +yodaerr
        vector[size_t] shape(bool) except +yodaerr
        vector[vector[double]] covarianceMatrix(bool, bool, bool, string&) except +yodaerr
        size_t numBins(bool, bool) except +yodaerr
        vector[vector[double]] covMat(bool, bool, bool, string&) except +yodaerr
        vector[string] sources() except +yodaerr
        bool isMasked(size_t) except +yodaerr
        vector[double] vals(bool, bool) except +yodaerr
        void maskSlice(size_t, size_t, bool) except +yodaerr
        void scale(double) except +yodaerr
        void clearBins() except +yodaerr
        double auc(bool, bool, bool) except +yodaerr
        double areaUnderCurve(bool, bool, bool) except +yodaerr
        void maskBins(vector[size_t]&, bool) except +yodaerr
        bool isVisible(size_t) except +yodaerr

#}}} BinnedEstimate1D


cdef extern from "YODA/BinnedEstimate.h" namespace "YODA":
    cdef cppclass BinnedEstimate2D[A1,A2](AnalysisObject, XAxisMixin[A1], YAxisMixin[A2]):
        BinnedEstimate2D() except +yodaerr
        BinnedEstimate2D(vector[A1]& xedges, vector[A2]& yedges, string path, string title) except +yodaerr
        BinnedEstimate2D(BinnedEstimate2D[A1,A2]& p) except +yodaerr

        BinnedEstimate2D[A1,A2] clone() except +yodaerr
        BinnedEstimate2D[A1,A2]* newclone() except +yodaerr

        # TODO: have to ignore exception handling on ref-returning methods until Cython bug is fixed
        vector[Estimate]& bins() except +yodaerr
        Estimate& bin(size_t index) except +yodaerr
        Estimate& binAt(A1 x, A2 y) except +yodaerr
        size_t indexAt(A1 x, A2 y) except +yodaerr
        void set(size_t, Estimate&) except +yodaerr

        vector[size_t] _global2local(size_t) except +yodaerr
        size_t _local2global(vector[size_t]&) except +yodaerr

        operator == (BinnedEstimate2D[A1,A2]) except +yodaerr
        operator != (BinnedEstimate2D[A1,A2]) except +yodaerr

        size_t numBinsAt(size_t, bool) except +yodaerr
        vector[size_t] maskedBins() except +yodaerr
        size_t binDim() except +yodaerr
        void maskBin(size_t, bool) except +yodaerr
        vector[size_t] shape(bool) except +yodaerr
        vector[vector[double]] covarianceMatrix(bool, bool, bool, string&) except +yodaerr
        size_t numBins(bool, bool) except +yodaerr
        vector[vector[double]] covMat(bool, bool, bool, string&) except +yodaerr
        Scatter3D mkScatter(string&, string&, bool, bool) except +yodaerr
        vector[string] sources() except +yodaerr
        bool isMasked(size_t) except +yodaerr
        vector[double] vals(bool, bool) except +yodaerr
        void maskSlice(size_t, size_t, bool) except +yodaerr
        void scale(double) except +yodaerr
        void clearBins() except +yodaerr
        double auc(bool, bool, bool) except +yodaerr
        double areaUnderCurve(bool, bool, bool) except +yodaerr
        void maskBins(vector[size_t]&, bool) except +yodaerr
        bool isVisible(size_t) except +yodaerr

#}}} BinnedEstimate2D


# BinnedEstimate3D {{{
cdef extern from "YODA/BinnedEstimate.h" namespace "YODA":
    cdef cppclass BinnedEstimate3D[A1,A2,A3](AnalysisObject, XAxisMixin[A1], YAxisMixin[A2], ZAxisMixin[A3]):
        BinnedEstimate3D() except +yodaerr
        BinnedEstimate3D(vector[A1]& xedges, vector[A2]& yedges, vector[A3]& zedges, string path, string title) except +yodaerr
        BinnedEstimate3D(BinnedEstimate3D[A1,A2,A3]& p) except +yodaerr

        BinnedEstimate3D[A1,A2,A3] clone() except +yodaerr
        BinnedEstimate3D[A1,A2,A3]* newclone() except +yodaerr

        # TODO: have to ignore exception handling on ref-returning methods until Cython bug is fixed
        vector[Estimate]& bins() except +yodaerr
        Estimate& bin(size_t index) except +yodaerr
        Estimate& binAt(A1 x, A2 y, A3 z) except +yodaerr
        size_t indexAt(A1 x, A2 y, A3 z) except +yodaerr
        void set(size_t, Estimate&) except +yodaerr

        vector[size_t] _global2local(size_t) except +yodaerr
        size_t _local2global(vector[size_t]&) except +yodaerr

        operator == (BinnedEstimate3D[A1,A2,A3]) except +yodaerr
        operator != (BinnedEstimate3D[A1,A2,A3]) except +yodaerr

        size_t numBinsAt(size_t, bool) except +yodaerr
        vector[size_t] maskedBins() except +yodaerr
        size_t binDim() except +yodaerr
        void maskBin(size_t, bool) except +yodaerr
        vector[size_t] shape(bool) except +yodaerr
        vector[vector[double]] covarianceMatrix(bool, bool, bool, string&) except +yodaerr
        size_t numBins(bool, bool) except +yodaerr
        vector[vector[double]] covMat(bool, bool, bool, string&) except +yodaerr
        vector[string] sources() except +yodaerr
        bool isMasked(size_t) except +yodaerr
        Scatter4D mkScatter(string&, string&, bool, bool) except +yodaerr
        vector[double] vals(bool, bool) except +yodaerr
        void maskSlice(size_t, size_t, bool) except +yodaerr
        void scale(double) except +yodaerr
        void clearBins() except +yodaerr
        double auc(bool, bool, bool) except +yodaerr
        double areaUnderCurve(bool, bool, bool) except +yodaerr
        void maskBins(vector[size_t]&, bool) except +yodaerr
        bool isVisible(size_t) except +yodaerr

#}}} BinnedEstimate3D


# Streams {{{

cdef extern from "<iostream>" namespace "std":
    cdef cppclass istream:
        istringstream()
        string& str(string&)

cdef extern from "<sstream>" namespace "std":
    cdef cppclass istringstream:
        istringstream()
        string& str(string&)
    cdef cppclass ostringstream:
        ostringstream()
        string& str()


cdef extern from "YODA/IO.h" namespace "YODA":
    void IO_read_from_file "YODA::read" (string&, vector[AnalysisObject*]&, string&, string&) except +yodaerr
    void IO_read_from_stream "YODA::read" (istream&, vector[AnalysisObject*]& aos, string&, string&, string&) except +yodaerr
    void IO_read_from_stringstream "YODA::read" (istringstream&, vector[AnalysisObject*]& aos, string&, string&, string&) except +yodaerr

cdef extern from "YODA/Reader.h" namespace "YODA":
    cdef cppclass Reader:
        void read(istringstream&, vector[AnalysisObject*]&, string&, string&) except +yodaerr
        void read_from_file "YODA::Reader::read" (string&, vector[AnalysisObject*]&, string&, string&) except +yodaerr
cdef extern from "YODA/ReaderH5.h" namespace "YODA":
    Reader& ReaderH5_create "YODA::ReaderH5::create" ()

cdef extern from "YODA/ReaderYODA.h" namespace "YODA":
    Reader& ReaderYODA_create "YODA::ReaderYODA::create" ()

cdef extern from "YODA/ReaderFLAT.h" namespace "YODA":
    Reader& ReaderFLAT_create "YODA::ReaderFLAT::create" ()

cdef extern from "YODA/Reader.h" namespace "YODA":
    Reader& Reader_create "YODA::mkReader" (string& filename)


cdef extern from "YODA/IO.h" namespace "YODA":
    void IO_write_to_file "YODA::write" (string&, vector[AnalysisObject*]&, int) except +yodaerr
    void IO_write_to_stream "YODA::write" (ostringstream&, vector[AnalysisObject*]&, string&, int) except +yodaerr

cdef extern from "YODA/Writer.h" namespace "YODA":
    cdef cppclass Writer:
        void write(ostringstream&, vector[AnalysisObject*]&) except +yodaerr
        void write_to_file "YODA::Writer::write" (string&, vector[AnalysisObject*]&) except +yodaerr
        void setPrecision(int precision)
        void useCompression(bool compress)
    Writer& Writer_create "YODA::mkWriter" (string& filename)
cdef extern from "YODA/WriterH5.h" namespace "YODA":
    Writer& WriterH5_create "YODA::WriterH5::create" ()

cdef extern from "YODA/WriterYODA.h" namespace "YODA":
    Writer& WriterYODA_create "YODA::WriterYODA::create" ()

cdef extern from "YODA/WriterYODA1.h" namespace "YODA":
    Writer& WriterYODA1_create "YODA::WriterYODA1::create" ()

cdef extern from "YODA/WriterFLAT.h" namespace "YODA":
    Writer& WriterFLAT_create "YODA::WriterFLAT::create" ()

# Streams }}}

cdef extern from "merge.hh":
    Estimate* Estimate_add "cython_add_est" (Estimate*, Estimate*, string&)
    Estimate* Estimate_sub "cython_sub_est" (Estimate*, Estimate*, string&)
    Estimate0D* Estimate0D_add "cython_add" (Estimate0D*, Estimate0D*)
    Estimate0D* Estimate0D_add_est "cython_add_est" (Estimate0D*, Estimate0D*, string&)
    void Estimate0D_iadd "cython_iadd" (Estimate0D*, Estimate0D*)
    Estimate0D* Estimate0D_sub "cython_sub" (Estimate0D*, Estimate0D*)
    Estimate0D* Estimate0D_sub_est "cython_sub_est" (Estimate0D*, Estimate0D*, string&)
    void Estimate0D_isub "cython_isub" (Estimate0D*, Estimate0D*)
    Estimate0D* Estimate0D_mult "cython_mult" (Estimate0D*, Estimate0D*)
    Estimate0D* Estimate0D_mult_est "cython_mult_est" (Estimate0D*, Estimate0D*, string&)
    Estimate0D* Estimate0D_div "cython_div" (Estimate0D*, Estimate0D*)
    Estimate0D* Estimate0D_div_est "cython_div_est" (Estimate0D*, Estimate0D*, string&)
    Estimate0D* Estimate0D_eff "cython_eff" (Estimate0D*, Estimate0D*)
    Estimate0D* Estimate0D_eff_est "cython_eff_est" (Estimate0D*, Estimate0D*, string&)
    Counter* Counter_add_Counter "cython_add" (Counter*, Counter*)
    void Counter_iadd_Counter "cython_iadd" (Counter*, Counter*)
    Counter* Counter_sub_Counter "cython_sub" (Counter*, Counter*)
    void Counter_isub_Counter "cython_isub" (Counter*, Counter*)
    Estimate0D* Counter_div_Counter "cython_div" (Counter*, Counter*)
    Estimate0D* Counter_mult_Counter "cython_mult" (Counter*, Counter*)
    Estimate0D* Counter_eff_Counter "cython_eff" (Counter*, Counter*)
    Estimate0D* Counter_est "cython_est" (Counter*, string&, string&)
    Estimate0D* Counter_effn "cython_effnC" (Counter*, string&, string&)
    BinnedEstimate1D[double]* BE_add_d "cython_add" (BinnedEstimate1D[double]*, BinnedEstimate1D[double]*) except +yodaerr
    void BE_iadd_d "cython_iadd" (BinnedEstimate1D[double]*, BinnedEstimate1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BE_sub_d "cython_sub" (BinnedEstimate1D[double]*, BinnedEstimate1D[double]*) except +yodaerr
    void BE_isub_d "cython_isub" (BinnedEstimate1D[double]*, BinnedEstimate1D[double]*) except +yodaerr
    bool BE_eq_d "cython_eq" (BinnedEstimate1D[double]*, BinnedEstimate1D[double]*) except +yodaerr
    bool BE_ne_d "cython_ne" (BinnedEstimate1D[double]*, BinnedEstimate1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BE_div_d "cython_div" (BinnedEstimate1D[double]*, BinnedEstimate1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BE_mult_d "cython_mult" (BinnedEstimate1D[double]*, BinnedEstimate1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BE_eff_d "cython_eff" (BinnedEstimate1D[double]*, BinnedEstimate1D[double]*) except +yodaerr
    BinnedEstimate1D[int]* BE_add_i "cython_add" (BinnedEstimate1D[int]*, BinnedEstimate1D[int]*) except +yodaerr
    void BE_iadd_i "cython_iadd" (BinnedEstimate1D[int]*, BinnedEstimate1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BE_sub_i "cython_sub" (BinnedEstimate1D[int]*, BinnedEstimate1D[int]*) except +yodaerr
    void BE_isub_i "cython_isub" (BinnedEstimate1D[int]*, BinnedEstimate1D[int]*) except +yodaerr
    bool BE_eq_i "cython_eq" (BinnedEstimate1D[int]*, BinnedEstimate1D[int]*) except +yodaerr
    bool BE_ne_i "cython_ne" (BinnedEstimate1D[int]*, BinnedEstimate1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BE_div_i "cython_div" (BinnedEstimate1D[int]*, BinnedEstimate1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BE_mult_i "cython_mult" (BinnedEstimate1D[int]*, BinnedEstimate1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BE_eff_i "cython_eff" (BinnedEstimate1D[int]*, BinnedEstimate1D[int]*) except +yodaerr
    BinnedEstimate1D[string]* BE_add_s "cython_add" (BinnedEstimate1D[string]*, BinnedEstimate1D[string]*) except +yodaerr
    void BE_iadd_s "cython_iadd" (BinnedEstimate1D[string]*, BinnedEstimate1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BE_sub_s "cython_sub" (BinnedEstimate1D[string]*, BinnedEstimate1D[string]*) except +yodaerr
    void BE_isub_s "cython_isub" (BinnedEstimate1D[string]*, BinnedEstimate1D[string]*) except +yodaerr
    bool BE_eq_s "cython_eq" (BinnedEstimate1D[string]*, BinnedEstimate1D[string]*) except +yodaerr
    bool BE_ne_s "cython_ne" (BinnedEstimate1D[string]*, BinnedEstimate1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BE_div_s "cython_div" (BinnedEstimate1D[string]*, BinnedEstimate1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BE_mult_s "cython_mult" (BinnedEstimate1D[string]*, BinnedEstimate1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BE_eff_s "cython_eff" (BinnedEstimate1D[string]*, BinnedEstimate1D[string]*) except +yodaerr
    BinnedHisto1D[double]* BH_add_d "cython_add" (BinnedHisto1D[double]*, BinnedHisto1D[double]*) except +yodaerr
    void BH_iadd_d "cython_iadd" (BinnedHisto1D[double]*, BinnedHisto1D[double]*) except +yodaerr
    BinnedHisto1D[double]* BH_sub_d "cython_sub" (BinnedHisto1D[double]*, BinnedHisto1D[double]*) except +yodaerr
    void BH_isub_d "cython_isub" (BinnedHisto1D[double]*, BinnedHisto1D[double]*) except +yodaerr
    bool BH_eq_d "cython_eq" (BinnedHisto1D[double]*, BinnedHisto1D[double]*) except +yodaerr
    bool BH_ne_d "cython_ne" (BinnedHisto1D[double]*, BinnedHisto1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BH_div_d "cython_div" (BinnedHisto1D[double]*, BinnedHisto1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BH_mult_d "cython_mult" (BinnedHisto1D[double]*, BinnedHisto1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BH_eff_d "cython_eff" (BinnedHisto1D[double]*, BinnedHisto1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BH_est_d "cython_est" (BinnedHisto1D[double]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate1D[double]* BH_binnedeffn_d "cython_effn" (BinnedHisto1D[double]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto1D[int]* BH_add_i "cython_add" (BinnedHisto1D[int]*, BinnedHisto1D[int]*) except +yodaerr
    void BH_iadd_i "cython_iadd" (BinnedHisto1D[int]*, BinnedHisto1D[int]*) except +yodaerr
    BinnedHisto1D[int]* BH_sub_i "cython_sub" (BinnedHisto1D[int]*, BinnedHisto1D[int]*) except +yodaerr
    void BH_isub_i "cython_isub" (BinnedHisto1D[int]*, BinnedHisto1D[int]*) except +yodaerr
    bool BH_eq_i "cython_eq" (BinnedHisto1D[int]*, BinnedHisto1D[int]*) except +yodaerr
    bool BH_ne_i "cython_ne" (BinnedHisto1D[int]*, BinnedHisto1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BH_div_i "cython_div" (BinnedHisto1D[int]*, BinnedHisto1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BH_mult_i "cython_mult" (BinnedHisto1D[int]*, BinnedHisto1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BH_eff_i "cython_eff" (BinnedHisto1D[int]*, BinnedHisto1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BH_est_i "cython_est" (BinnedHisto1D[int]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate1D[int]* BH_binnedeffn_i "cython_effn" (BinnedHisto1D[int]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto1D[string]* BH_add_s "cython_add" (BinnedHisto1D[string]*, BinnedHisto1D[string]*) except +yodaerr
    void BH_iadd_s "cython_iadd" (BinnedHisto1D[string]*, BinnedHisto1D[string]*) except +yodaerr
    BinnedHisto1D[string]* BH_sub_s "cython_sub" (BinnedHisto1D[string]*, BinnedHisto1D[string]*) except +yodaerr
    void BH_isub_s "cython_isub" (BinnedHisto1D[string]*, BinnedHisto1D[string]*) except +yodaerr
    bool BH_eq_s "cython_eq" (BinnedHisto1D[string]*, BinnedHisto1D[string]*) except +yodaerr
    bool BH_ne_s "cython_ne" (BinnedHisto1D[string]*, BinnedHisto1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BH_div_s "cython_div" (BinnedHisto1D[string]*, BinnedHisto1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BH_mult_s "cython_mult" (BinnedHisto1D[string]*, BinnedHisto1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BH_eff_s "cython_eff" (BinnedHisto1D[string]*, BinnedHisto1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BH_est_s "cython_est" (BinnedHisto1D[string]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate1D[string]* BH_binnedeffn_s "cython_effn" (BinnedHisto1D[string]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedProfile1D[double]* BP_add_d "cython_add" (BinnedProfile1D[double]*, BinnedProfile1D[double]*) except +yodaerr
    void BP_iadd_d "cython_iadd" (BinnedProfile1D[double]*, BinnedProfile1D[double]*) except +yodaerr
    BinnedProfile1D[double]* BP_sub_d "cython_sub" (BinnedProfile1D[double]*, BinnedProfile1D[double]*) except +yodaerr
    void BP_isub_d "cython_isub" (BinnedProfile1D[double]*, BinnedProfile1D[double]*) except +yodaerr
    bool BP_eq_d "cython_eq" (BinnedProfile1D[double]*, BinnedProfile1D[double]*) except +yodaerr
    bool BP_ne_d "cython_ne" (BinnedProfile1D[double]*, BinnedProfile1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BP_div_d "cython_div" (BinnedProfile1D[double]*, BinnedProfile1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BP_mult_d "cython_mult" (BinnedProfile1D[double]*, BinnedProfile1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BP_eff_d "cython_eff" (BinnedProfile1D[double]*, BinnedProfile1D[double]*) except +yodaerr
    BinnedEstimate1D[double]* BP_est_d "cython_est" (BinnedProfile1D[double]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate1D[double]* BP_binnedeffn_d "cython_effn" (BinnedProfile1D[double]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto1D[double]* BP_hist_d "cython_hist" (BinnedProfile1D[double]*, string&) except +yodaerr
    BinnedProfile1D[int]* BP_add_i "cython_add" (BinnedProfile1D[int]*, BinnedProfile1D[int]*) except +yodaerr
    void BP_iadd_i "cython_iadd" (BinnedProfile1D[int]*, BinnedProfile1D[int]*) except +yodaerr
    BinnedProfile1D[int]* BP_sub_i "cython_sub" (BinnedProfile1D[int]*, BinnedProfile1D[int]*) except +yodaerr
    void BP_isub_i "cython_isub" (BinnedProfile1D[int]*, BinnedProfile1D[int]*) except +yodaerr
    bool BP_eq_i "cython_eq" (BinnedProfile1D[int]*, BinnedProfile1D[int]*) except +yodaerr
    bool BP_ne_i "cython_ne" (BinnedProfile1D[int]*, BinnedProfile1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BP_div_i "cython_div" (BinnedProfile1D[int]*, BinnedProfile1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BP_mult_i "cython_mult" (BinnedProfile1D[int]*, BinnedProfile1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BP_eff_i "cython_eff" (BinnedProfile1D[int]*, BinnedProfile1D[int]*) except +yodaerr
    BinnedEstimate1D[int]* BP_est_i "cython_est" (BinnedProfile1D[int]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate1D[int]* BP_binnedeffn_i "cython_effn" (BinnedProfile1D[int]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto1D[int]* BP_hist_i "cython_hist" (BinnedProfile1D[int]*, string&) except +yodaerr
    BinnedProfile1D[string]* BP_add_s "cython_add" (BinnedProfile1D[string]*, BinnedProfile1D[string]*) except +yodaerr
    void BP_iadd_s "cython_iadd" (BinnedProfile1D[string]*, BinnedProfile1D[string]*) except +yodaerr
    BinnedProfile1D[string]* BP_sub_s "cython_sub" (BinnedProfile1D[string]*, BinnedProfile1D[string]*) except +yodaerr
    void BP_isub_s "cython_isub" (BinnedProfile1D[string]*, BinnedProfile1D[string]*) except +yodaerr
    bool BP_eq_s "cython_eq" (BinnedProfile1D[string]*, BinnedProfile1D[string]*) except +yodaerr
    bool BP_ne_s "cython_ne" (BinnedProfile1D[string]*, BinnedProfile1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BP_div_s "cython_div" (BinnedProfile1D[string]*, BinnedProfile1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BP_mult_s "cython_mult" (BinnedProfile1D[string]*, BinnedProfile1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BP_eff_s "cython_eff" (BinnedProfile1D[string]*, BinnedProfile1D[string]*) except +yodaerr
    BinnedEstimate1D[string]* BP_est_s "cython_est" (BinnedProfile1D[string]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate1D[string]* BP_binnedeffn_s "cython_effn" (BinnedProfile1D[string]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto1D[string]* BP_hist_s "cython_hist" (BinnedProfile1D[string]*, string&) except +yodaerr
    BinnedEstimate2D[double,double]* BE_add_dd "cython_add" (BinnedEstimate2D[double,double]*, BinnedEstimate2D[double,double]*) except +yodaerr
    void BE_iadd_dd "cython_iadd" (BinnedEstimate2D[double,double]*, BinnedEstimate2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BE_sub_dd "cython_sub" (BinnedEstimate2D[double,double]*, BinnedEstimate2D[double,double]*) except +yodaerr
    void BE_isub_dd "cython_isub" (BinnedEstimate2D[double,double]*, BinnedEstimate2D[double,double]*) except +yodaerr
    bool BE_eq_dd "cython_eq" (BinnedEstimate2D[double,double]*, BinnedEstimate2D[double,double]*) except +yodaerr
    bool BE_ne_dd "cython_ne" (BinnedEstimate2D[double,double]*, BinnedEstimate2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BE_div_dd "cython_div" (BinnedEstimate2D[double,double]*, BinnedEstimate2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BE_mult_dd "cython_mult" (BinnedEstimate2D[double,double]*, BinnedEstimate2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BE_eff_dd "cython_eff" (BinnedEstimate2D[double,double]*, BinnedEstimate2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,int]* BE_add_di "cython_add" (BinnedEstimate2D[double,int]*, BinnedEstimate2D[double,int]*) except +yodaerr
    void BE_iadd_di "cython_iadd" (BinnedEstimate2D[double,int]*, BinnedEstimate2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BE_sub_di "cython_sub" (BinnedEstimate2D[double,int]*, BinnedEstimate2D[double,int]*) except +yodaerr
    void BE_isub_di "cython_isub" (BinnedEstimate2D[double,int]*, BinnedEstimate2D[double,int]*) except +yodaerr
    bool BE_eq_di "cython_eq" (BinnedEstimate2D[double,int]*, BinnedEstimate2D[double,int]*) except +yodaerr
    bool BE_ne_di "cython_ne" (BinnedEstimate2D[double,int]*, BinnedEstimate2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BE_div_di "cython_div" (BinnedEstimate2D[double,int]*, BinnedEstimate2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BE_mult_di "cython_mult" (BinnedEstimate2D[double,int]*, BinnedEstimate2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BE_eff_di "cython_eff" (BinnedEstimate2D[double,int]*, BinnedEstimate2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,string]* BE_add_ds "cython_add" (BinnedEstimate2D[double,string]*, BinnedEstimate2D[double,string]*) except +yodaerr
    void BE_iadd_ds "cython_iadd" (BinnedEstimate2D[double,string]*, BinnedEstimate2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BE_sub_ds "cython_sub" (BinnedEstimate2D[double,string]*, BinnedEstimate2D[double,string]*) except +yodaerr
    void BE_isub_ds "cython_isub" (BinnedEstimate2D[double,string]*, BinnedEstimate2D[double,string]*) except +yodaerr
    bool BE_eq_ds "cython_eq" (BinnedEstimate2D[double,string]*, BinnedEstimate2D[double,string]*) except +yodaerr
    bool BE_ne_ds "cython_ne" (BinnedEstimate2D[double,string]*, BinnedEstimate2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BE_div_ds "cython_div" (BinnedEstimate2D[double,string]*, BinnedEstimate2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BE_mult_ds "cython_mult" (BinnedEstimate2D[double,string]*, BinnedEstimate2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BE_eff_ds "cython_eff" (BinnedEstimate2D[double,string]*, BinnedEstimate2D[double,string]*) except +yodaerr
    BinnedEstimate2D[int,double]* BE_add_id "cython_add" (BinnedEstimate2D[int,double]*, BinnedEstimate2D[int,double]*) except +yodaerr
    void BE_iadd_id "cython_iadd" (BinnedEstimate2D[int,double]*, BinnedEstimate2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BE_sub_id "cython_sub" (BinnedEstimate2D[int,double]*, BinnedEstimate2D[int,double]*) except +yodaerr
    void BE_isub_id "cython_isub" (BinnedEstimate2D[int,double]*, BinnedEstimate2D[int,double]*) except +yodaerr
    bool BE_eq_id "cython_eq" (BinnedEstimate2D[int,double]*, BinnedEstimate2D[int,double]*) except +yodaerr
    bool BE_ne_id "cython_ne" (BinnedEstimate2D[int,double]*, BinnedEstimate2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BE_div_id "cython_div" (BinnedEstimate2D[int,double]*, BinnedEstimate2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BE_mult_id "cython_mult" (BinnedEstimate2D[int,double]*, BinnedEstimate2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BE_eff_id "cython_eff" (BinnedEstimate2D[int,double]*, BinnedEstimate2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,int]* BE_add_ii "cython_add" (BinnedEstimate2D[int,int]*, BinnedEstimate2D[int,int]*) except +yodaerr
    void BE_iadd_ii "cython_iadd" (BinnedEstimate2D[int,int]*, BinnedEstimate2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BE_sub_ii "cython_sub" (BinnedEstimate2D[int,int]*, BinnedEstimate2D[int,int]*) except +yodaerr
    void BE_isub_ii "cython_isub" (BinnedEstimate2D[int,int]*, BinnedEstimate2D[int,int]*) except +yodaerr
    bool BE_eq_ii "cython_eq" (BinnedEstimate2D[int,int]*, BinnedEstimate2D[int,int]*) except +yodaerr
    bool BE_ne_ii "cython_ne" (BinnedEstimate2D[int,int]*, BinnedEstimate2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BE_div_ii "cython_div" (BinnedEstimate2D[int,int]*, BinnedEstimate2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BE_mult_ii "cython_mult" (BinnedEstimate2D[int,int]*, BinnedEstimate2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BE_eff_ii "cython_eff" (BinnedEstimate2D[int,int]*, BinnedEstimate2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,string]* BE_add_is "cython_add" (BinnedEstimate2D[int,string]*, BinnedEstimate2D[int,string]*) except +yodaerr
    void BE_iadd_is "cython_iadd" (BinnedEstimate2D[int,string]*, BinnedEstimate2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BE_sub_is "cython_sub" (BinnedEstimate2D[int,string]*, BinnedEstimate2D[int,string]*) except +yodaerr
    void BE_isub_is "cython_isub" (BinnedEstimate2D[int,string]*, BinnedEstimate2D[int,string]*) except +yodaerr
    bool BE_eq_is "cython_eq" (BinnedEstimate2D[int,string]*, BinnedEstimate2D[int,string]*) except +yodaerr
    bool BE_ne_is "cython_ne" (BinnedEstimate2D[int,string]*, BinnedEstimate2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BE_div_is "cython_div" (BinnedEstimate2D[int,string]*, BinnedEstimate2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BE_mult_is "cython_mult" (BinnedEstimate2D[int,string]*, BinnedEstimate2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BE_eff_is "cython_eff" (BinnedEstimate2D[int,string]*, BinnedEstimate2D[int,string]*) except +yodaerr
    BinnedEstimate2D[string,double]* BE_add_sd "cython_add" (BinnedEstimate2D[string,double]*, BinnedEstimate2D[string,double]*) except +yodaerr
    void BE_iadd_sd "cython_iadd" (BinnedEstimate2D[string,double]*, BinnedEstimate2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BE_sub_sd "cython_sub" (BinnedEstimate2D[string,double]*, BinnedEstimate2D[string,double]*) except +yodaerr
    void BE_isub_sd "cython_isub" (BinnedEstimate2D[string,double]*, BinnedEstimate2D[string,double]*) except +yodaerr
    bool BE_eq_sd "cython_eq" (BinnedEstimate2D[string,double]*, BinnedEstimate2D[string,double]*) except +yodaerr
    bool BE_ne_sd "cython_ne" (BinnedEstimate2D[string,double]*, BinnedEstimate2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BE_div_sd "cython_div" (BinnedEstimate2D[string,double]*, BinnedEstimate2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BE_mult_sd "cython_mult" (BinnedEstimate2D[string,double]*, BinnedEstimate2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BE_eff_sd "cython_eff" (BinnedEstimate2D[string,double]*, BinnedEstimate2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,int]* BE_add_si "cython_add" (BinnedEstimate2D[string,int]*, BinnedEstimate2D[string,int]*) except +yodaerr
    void BE_iadd_si "cython_iadd" (BinnedEstimate2D[string,int]*, BinnedEstimate2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BE_sub_si "cython_sub" (BinnedEstimate2D[string,int]*, BinnedEstimate2D[string,int]*) except +yodaerr
    void BE_isub_si "cython_isub" (BinnedEstimate2D[string,int]*, BinnedEstimate2D[string,int]*) except +yodaerr
    bool BE_eq_si "cython_eq" (BinnedEstimate2D[string,int]*, BinnedEstimate2D[string,int]*) except +yodaerr
    bool BE_ne_si "cython_ne" (BinnedEstimate2D[string,int]*, BinnedEstimate2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BE_div_si "cython_div" (BinnedEstimate2D[string,int]*, BinnedEstimate2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BE_mult_si "cython_mult" (BinnedEstimate2D[string,int]*, BinnedEstimate2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BE_eff_si "cython_eff" (BinnedEstimate2D[string,int]*, BinnedEstimate2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,string]* BE_add_ss "cython_add" (BinnedEstimate2D[string,string]*, BinnedEstimate2D[string,string]*) except +yodaerr
    void BE_iadd_ss "cython_iadd" (BinnedEstimate2D[string,string]*, BinnedEstimate2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BE_sub_ss "cython_sub" (BinnedEstimate2D[string,string]*, BinnedEstimate2D[string,string]*) except +yodaerr
    void BE_isub_ss "cython_isub" (BinnedEstimate2D[string,string]*, BinnedEstimate2D[string,string]*) except +yodaerr
    bool BE_eq_ss "cython_eq" (BinnedEstimate2D[string,string]*, BinnedEstimate2D[string,string]*) except +yodaerr
    bool BE_ne_ss "cython_ne" (BinnedEstimate2D[string,string]*, BinnedEstimate2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BE_div_ss "cython_div" (BinnedEstimate2D[string,string]*, BinnedEstimate2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BE_mult_ss "cython_mult" (BinnedEstimate2D[string,string]*, BinnedEstimate2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BE_eff_ss "cython_eff" (BinnedEstimate2D[string,string]*, BinnedEstimate2D[string,string]*) except +yodaerr
    BinnedHisto2D[double,double]* BH_add_dd "cython_add" (BinnedHisto2D[double,double]*, BinnedHisto2D[double,double]*) except +yodaerr
    void BH_iadd_dd "cython_iadd" (BinnedHisto2D[double,double]*, BinnedHisto2D[double,double]*) except +yodaerr
    BinnedHisto2D[double,double]* BH_sub_dd "cython_sub" (BinnedHisto2D[double,double]*, BinnedHisto2D[double,double]*) except +yodaerr
    void BH_isub_dd "cython_isub" (BinnedHisto2D[double,double]*, BinnedHisto2D[double,double]*) except +yodaerr
    bool BH_eq_dd "cython_eq" (BinnedHisto2D[double,double]*, BinnedHisto2D[double,double]*) except +yodaerr
    bool BH_ne_dd "cython_ne" (BinnedHisto2D[double,double]*, BinnedHisto2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BH_div_dd "cython_div" (BinnedHisto2D[double,double]*, BinnedHisto2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BH_mult_dd "cython_mult" (BinnedHisto2D[double,double]*, BinnedHisto2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BH_eff_dd "cython_eff" (BinnedHisto2D[double,double]*, BinnedHisto2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BH_est_dd "cython_est" (BinnedHisto2D[double,double]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[double,double]* BH_binnedeffn_dd "cython_effn" (BinnedHisto2D[double,double]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[double,int]* BH_add_di "cython_add" (BinnedHisto2D[double,int]*, BinnedHisto2D[double,int]*) except +yodaerr
    void BH_iadd_di "cython_iadd" (BinnedHisto2D[double,int]*, BinnedHisto2D[double,int]*) except +yodaerr
    BinnedHisto2D[double,int]* BH_sub_di "cython_sub" (BinnedHisto2D[double,int]*, BinnedHisto2D[double,int]*) except +yodaerr
    void BH_isub_di "cython_isub" (BinnedHisto2D[double,int]*, BinnedHisto2D[double,int]*) except +yodaerr
    bool BH_eq_di "cython_eq" (BinnedHisto2D[double,int]*, BinnedHisto2D[double,int]*) except +yodaerr
    bool BH_ne_di "cython_ne" (BinnedHisto2D[double,int]*, BinnedHisto2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BH_div_di "cython_div" (BinnedHisto2D[double,int]*, BinnedHisto2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BH_mult_di "cython_mult" (BinnedHisto2D[double,int]*, BinnedHisto2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BH_eff_di "cython_eff" (BinnedHisto2D[double,int]*, BinnedHisto2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BH_est_di "cython_est" (BinnedHisto2D[double,int]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[double,int]* BH_binnedeffn_di "cython_effn" (BinnedHisto2D[double,int]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[double,string]* BH_add_ds "cython_add" (BinnedHisto2D[double,string]*, BinnedHisto2D[double,string]*) except +yodaerr
    void BH_iadd_ds "cython_iadd" (BinnedHisto2D[double,string]*, BinnedHisto2D[double,string]*) except +yodaerr
    BinnedHisto2D[double,string]* BH_sub_ds "cython_sub" (BinnedHisto2D[double,string]*, BinnedHisto2D[double,string]*) except +yodaerr
    void BH_isub_ds "cython_isub" (BinnedHisto2D[double,string]*, BinnedHisto2D[double,string]*) except +yodaerr
    bool BH_eq_ds "cython_eq" (BinnedHisto2D[double,string]*, BinnedHisto2D[double,string]*) except +yodaerr
    bool BH_ne_ds "cython_ne" (BinnedHisto2D[double,string]*, BinnedHisto2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BH_div_ds "cython_div" (BinnedHisto2D[double,string]*, BinnedHisto2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BH_mult_ds "cython_mult" (BinnedHisto2D[double,string]*, BinnedHisto2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BH_eff_ds "cython_eff" (BinnedHisto2D[double,string]*, BinnedHisto2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BH_est_ds "cython_est" (BinnedHisto2D[double,string]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[double,string]* BH_binnedeffn_ds "cython_effn" (BinnedHisto2D[double,string]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[int,double]* BH_add_id "cython_add" (BinnedHisto2D[int,double]*, BinnedHisto2D[int,double]*) except +yodaerr
    void BH_iadd_id "cython_iadd" (BinnedHisto2D[int,double]*, BinnedHisto2D[int,double]*) except +yodaerr
    BinnedHisto2D[int,double]* BH_sub_id "cython_sub" (BinnedHisto2D[int,double]*, BinnedHisto2D[int,double]*) except +yodaerr
    void BH_isub_id "cython_isub" (BinnedHisto2D[int,double]*, BinnedHisto2D[int,double]*) except +yodaerr
    bool BH_eq_id "cython_eq" (BinnedHisto2D[int,double]*, BinnedHisto2D[int,double]*) except +yodaerr
    bool BH_ne_id "cython_ne" (BinnedHisto2D[int,double]*, BinnedHisto2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BH_div_id "cython_div" (BinnedHisto2D[int,double]*, BinnedHisto2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BH_mult_id "cython_mult" (BinnedHisto2D[int,double]*, BinnedHisto2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BH_eff_id "cython_eff" (BinnedHisto2D[int,double]*, BinnedHisto2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BH_est_id "cython_est" (BinnedHisto2D[int,double]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[int,double]* BH_binnedeffn_id "cython_effn" (BinnedHisto2D[int,double]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[int,int]* BH_add_ii "cython_add" (BinnedHisto2D[int,int]*, BinnedHisto2D[int,int]*) except +yodaerr
    void BH_iadd_ii "cython_iadd" (BinnedHisto2D[int,int]*, BinnedHisto2D[int,int]*) except +yodaerr
    BinnedHisto2D[int,int]* BH_sub_ii "cython_sub" (BinnedHisto2D[int,int]*, BinnedHisto2D[int,int]*) except +yodaerr
    void BH_isub_ii "cython_isub" (BinnedHisto2D[int,int]*, BinnedHisto2D[int,int]*) except +yodaerr
    bool BH_eq_ii "cython_eq" (BinnedHisto2D[int,int]*, BinnedHisto2D[int,int]*) except +yodaerr
    bool BH_ne_ii "cython_ne" (BinnedHisto2D[int,int]*, BinnedHisto2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BH_div_ii "cython_div" (BinnedHisto2D[int,int]*, BinnedHisto2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BH_mult_ii "cython_mult" (BinnedHisto2D[int,int]*, BinnedHisto2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BH_eff_ii "cython_eff" (BinnedHisto2D[int,int]*, BinnedHisto2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BH_est_ii "cython_est" (BinnedHisto2D[int,int]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[int,int]* BH_binnedeffn_ii "cython_effn" (BinnedHisto2D[int,int]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[int,string]* BH_add_is "cython_add" (BinnedHisto2D[int,string]*, BinnedHisto2D[int,string]*) except +yodaerr
    void BH_iadd_is "cython_iadd" (BinnedHisto2D[int,string]*, BinnedHisto2D[int,string]*) except +yodaerr
    BinnedHisto2D[int,string]* BH_sub_is "cython_sub" (BinnedHisto2D[int,string]*, BinnedHisto2D[int,string]*) except +yodaerr
    void BH_isub_is "cython_isub" (BinnedHisto2D[int,string]*, BinnedHisto2D[int,string]*) except +yodaerr
    bool BH_eq_is "cython_eq" (BinnedHisto2D[int,string]*, BinnedHisto2D[int,string]*) except +yodaerr
    bool BH_ne_is "cython_ne" (BinnedHisto2D[int,string]*, BinnedHisto2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BH_div_is "cython_div" (BinnedHisto2D[int,string]*, BinnedHisto2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BH_mult_is "cython_mult" (BinnedHisto2D[int,string]*, BinnedHisto2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BH_eff_is "cython_eff" (BinnedHisto2D[int,string]*, BinnedHisto2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BH_est_is "cython_est" (BinnedHisto2D[int,string]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[int,string]* BH_binnedeffn_is "cython_effn" (BinnedHisto2D[int,string]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[string,double]* BH_add_sd "cython_add" (BinnedHisto2D[string,double]*, BinnedHisto2D[string,double]*) except +yodaerr
    void BH_iadd_sd "cython_iadd" (BinnedHisto2D[string,double]*, BinnedHisto2D[string,double]*) except +yodaerr
    BinnedHisto2D[string,double]* BH_sub_sd "cython_sub" (BinnedHisto2D[string,double]*, BinnedHisto2D[string,double]*) except +yodaerr
    void BH_isub_sd "cython_isub" (BinnedHisto2D[string,double]*, BinnedHisto2D[string,double]*) except +yodaerr
    bool BH_eq_sd "cython_eq" (BinnedHisto2D[string,double]*, BinnedHisto2D[string,double]*) except +yodaerr
    bool BH_ne_sd "cython_ne" (BinnedHisto2D[string,double]*, BinnedHisto2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BH_div_sd "cython_div" (BinnedHisto2D[string,double]*, BinnedHisto2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BH_mult_sd "cython_mult" (BinnedHisto2D[string,double]*, BinnedHisto2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BH_eff_sd "cython_eff" (BinnedHisto2D[string,double]*, BinnedHisto2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BH_est_sd "cython_est" (BinnedHisto2D[string,double]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[string,double]* BH_binnedeffn_sd "cython_effn" (BinnedHisto2D[string,double]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[string,int]* BH_add_si "cython_add" (BinnedHisto2D[string,int]*, BinnedHisto2D[string,int]*) except +yodaerr
    void BH_iadd_si "cython_iadd" (BinnedHisto2D[string,int]*, BinnedHisto2D[string,int]*) except +yodaerr
    BinnedHisto2D[string,int]* BH_sub_si "cython_sub" (BinnedHisto2D[string,int]*, BinnedHisto2D[string,int]*) except +yodaerr
    void BH_isub_si "cython_isub" (BinnedHisto2D[string,int]*, BinnedHisto2D[string,int]*) except +yodaerr
    bool BH_eq_si "cython_eq" (BinnedHisto2D[string,int]*, BinnedHisto2D[string,int]*) except +yodaerr
    bool BH_ne_si "cython_ne" (BinnedHisto2D[string,int]*, BinnedHisto2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BH_div_si "cython_div" (BinnedHisto2D[string,int]*, BinnedHisto2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BH_mult_si "cython_mult" (BinnedHisto2D[string,int]*, BinnedHisto2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BH_eff_si "cython_eff" (BinnedHisto2D[string,int]*, BinnedHisto2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BH_est_si "cython_est" (BinnedHisto2D[string,int]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[string,int]* BH_binnedeffn_si "cython_effn" (BinnedHisto2D[string,int]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[string,string]* BH_add_ss "cython_add" (BinnedHisto2D[string,string]*, BinnedHisto2D[string,string]*) except +yodaerr
    void BH_iadd_ss "cython_iadd" (BinnedHisto2D[string,string]*, BinnedHisto2D[string,string]*) except +yodaerr
    BinnedHisto2D[string,string]* BH_sub_ss "cython_sub" (BinnedHisto2D[string,string]*, BinnedHisto2D[string,string]*) except +yodaerr
    void BH_isub_ss "cython_isub" (BinnedHisto2D[string,string]*, BinnedHisto2D[string,string]*) except +yodaerr
    bool BH_eq_ss "cython_eq" (BinnedHisto2D[string,string]*, BinnedHisto2D[string,string]*) except +yodaerr
    bool BH_ne_ss "cython_ne" (BinnedHisto2D[string,string]*, BinnedHisto2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BH_div_ss "cython_div" (BinnedHisto2D[string,string]*, BinnedHisto2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BH_mult_ss "cython_mult" (BinnedHisto2D[string,string]*, BinnedHisto2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BH_eff_ss "cython_eff" (BinnedHisto2D[string,string]*, BinnedHisto2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BH_est_ss "cython_est" (BinnedHisto2D[string,string]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[string,string]* BH_binnedeffn_ss "cython_effn" (BinnedHisto2D[string,string]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedProfile2D[double,double]* BP_add_dd "cython_add" (BinnedProfile2D[double,double]*, BinnedProfile2D[double,double]*) except +yodaerr
    void BP_iadd_dd "cython_iadd" (BinnedProfile2D[double,double]*, BinnedProfile2D[double,double]*) except +yodaerr
    BinnedProfile2D[double,double]* BP_sub_dd "cython_sub" (BinnedProfile2D[double,double]*, BinnedProfile2D[double,double]*) except +yodaerr
    void BP_isub_dd "cython_isub" (BinnedProfile2D[double,double]*, BinnedProfile2D[double,double]*) except +yodaerr
    bool BP_eq_dd "cython_eq" (BinnedProfile2D[double,double]*, BinnedProfile2D[double,double]*) except +yodaerr
    bool BP_ne_dd "cython_ne" (BinnedProfile2D[double,double]*, BinnedProfile2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BP_div_dd "cython_div" (BinnedProfile2D[double,double]*, BinnedProfile2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BP_mult_dd "cython_mult" (BinnedProfile2D[double,double]*, BinnedProfile2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BP_eff_dd "cython_eff" (BinnedProfile2D[double,double]*, BinnedProfile2D[double,double]*) except +yodaerr
    BinnedEstimate2D[double,double]* BP_est_dd "cython_est" (BinnedProfile2D[double,double]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[double,double]* BP_binnedeffn_dd "cython_effn" (BinnedProfile2D[double,double]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[double,double]* BP_hist_dd "cython_hist" (BinnedProfile2D[double,double]*, string&) except +yodaerr
    BinnedProfile2D[double,int]* BP_add_di "cython_add" (BinnedProfile2D[double,int]*, BinnedProfile2D[double,int]*) except +yodaerr
    void BP_iadd_di "cython_iadd" (BinnedProfile2D[double,int]*, BinnedProfile2D[double,int]*) except +yodaerr
    BinnedProfile2D[double,int]* BP_sub_di "cython_sub" (BinnedProfile2D[double,int]*, BinnedProfile2D[double,int]*) except +yodaerr
    void BP_isub_di "cython_isub" (BinnedProfile2D[double,int]*, BinnedProfile2D[double,int]*) except +yodaerr
    bool BP_eq_di "cython_eq" (BinnedProfile2D[double,int]*, BinnedProfile2D[double,int]*) except +yodaerr
    bool BP_ne_di "cython_ne" (BinnedProfile2D[double,int]*, BinnedProfile2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BP_div_di "cython_div" (BinnedProfile2D[double,int]*, BinnedProfile2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BP_mult_di "cython_mult" (BinnedProfile2D[double,int]*, BinnedProfile2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BP_eff_di "cython_eff" (BinnedProfile2D[double,int]*, BinnedProfile2D[double,int]*) except +yodaerr
    BinnedEstimate2D[double,int]* BP_est_di "cython_est" (BinnedProfile2D[double,int]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[double,int]* BP_binnedeffn_di "cython_effn" (BinnedProfile2D[double,int]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[double,int]* BP_hist_di "cython_hist" (BinnedProfile2D[double,int]*, string&) except +yodaerr
    BinnedProfile2D[double,string]* BP_add_ds "cython_add" (BinnedProfile2D[double,string]*, BinnedProfile2D[double,string]*) except +yodaerr
    void BP_iadd_ds "cython_iadd" (BinnedProfile2D[double,string]*, BinnedProfile2D[double,string]*) except +yodaerr
    BinnedProfile2D[double,string]* BP_sub_ds "cython_sub" (BinnedProfile2D[double,string]*, BinnedProfile2D[double,string]*) except +yodaerr
    void BP_isub_ds "cython_isub" (BinnedProfile2D[double,string]*, BinnedProfile2D[double,string]*) except +yodaerr
    bool BP_eq_ds "cython_eq" (BinnedProfile2D[double,string]*, BinnedProfile2D[double,string]*) except +yodaerr
    bool BP_ne_ds "cython_ne" (BinnedProfile2D[double,string]*, BinnedProfile2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BP_div_ds "cython_div" (BinnedProfile2D[double,string]*, BinnedProfile2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BP_mult_ds "cython_mult" (BinnedProfile2D[double,string]*, BinnedProfile2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BP_eff_ds "cython_eff" (BinnedProfile2D[double,string]*, BinnedProfile2D[double,string]*) except +yodaerr
    BinnedEstimate2D[double,string]* BP_est_ds "cython_est" (BinnedProfile2D[double,string]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[double,string]* BP_binnedeffn_ds "cython_effn" (BinnedProfile2D[double,string]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[double,string]* BP_hist_ds "cython_hist" (BinnedProfile2D[double,string]*, string&) except +yodaerr
    BinnedProfile2D[int,double]* BP_add_id "cython_add" (BinnedProfile2D[int,double]*, BinnedProfile2D[int,double]*) except +yodaerr
    void BP_iadd_id "cython_iadd" (BinnedProfile2D[int,double]*, BinnedProfile2D[int,double]*) except +yodaerr
    BinnedProfile2D[int,double]* BP_sub_id "cython_sub" (BinnedProfile2D[int,double]*, BinnedProfile2D[int,double]*) except +yodaerr
    void BP_isub_id "cython_isub" (BinnedProfile2D[int,double]*, BinnedProfile2D[int,double]*) except +yodaerr
    bool BP_eq_id "cython_eq" (BinnedProfile2D[int,double]*, BinnedProfile2D[int,double]*) except +yodaerr
    bool BP_ne_id "cython_ne" (BinnedProfile2D[int,double]*, BinnedProfile2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BP_div_id "cython_div" (BinnedProfile2D[int,double]*, BinnedProfile2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BP_mult_id "cython_mult" (BinnedProfile2D[int,double]*, BinnedProfile2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BP_eff_id "cython_eff" (BinnedProfile2D[int,double]*, BinnedProfile2D[int,double]*) except +yodaerr
    BinnedEstimate2D[int,double]* BP_est_id "cython_est" (BinnedProfile2D[int,double]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[int,double]* BP_binnedeffn_id "cython_effn" (BinnedProfile2D[int,double]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[int,double]* BP_hist_id "cython_hist" (BinnedProfile2D[int,double]*, string&) except +yodaerr
    BinnedProfile2D[int,int]* BP_add_ii "cython_add" (BinnedProfile2D[int,int]*, BinnedProfile2D[int,int]*) except +yodaerr
    void BP_iadd_ii "cython_iadd" (BinnedProfile2D[int,int]*, BinnedProfile2D[int,int]*) except +yodaerr
    BinnedProfile2D[int,int]* BP_sub_ii "cython_sub" (BinnedProfile2D[int,int]*, BinnedProfile2D[int,int]*) except +yodaerr
    void BP_isub_ii "cython_isub" (BinnedProfile2D[int,int]*, BinnedProfile2D[int,int]*) except +yodaerr
    bool BP_eq_ii "cython_eq" (BinnedProfile2D[int,int]*, BinnedProfile2D[int,int]*) except +yodaerr
    bool BP_ne_ii "cython_ne" (BinnedProfile2D[int,int]*, BinnedProfile2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BP_div_ii "cython_div" (BinnedProfile2D[int,int]*, BinnedProfile2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BP_mult_ii "cython_mult" (BinnedProfile2D[int,int]*, BinnedProfile2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BP_eff_ii "cython_eff" (BinnedProfile2D[int,int]*, BinnedProfile2D[int,int]*) except +yodaerr
    BinnedEstimate2D[int,int]* BP_est_ii "cython_est" (BinnedProfile2D[int,int]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[int,int]* BP_binnedeffn_ii "cython_effn" (BinnedProfile2D[int,int]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[int,int]* BP_hist_ii "cython_hist" (BinnedProfile2D[int,int]*, string&) except +yodaerr
    BinnedProfile2D[int,string]* BP_add_is "cython_add" (BinnedProfile2D[int,string]*, BinnedProfile2D[int,string]*) except +yodaerr
    void BP_iadd_is "cython_iadd" (BinnedProfile2D[int,string]*, BinnedProfile2D[int,string]*) except +yodaerr
    BinnedProfile2D[int,string]* BP_sub_is "cython_sub" (BinnedProfile2D[int,string]*, BinnedProfile2D[int,string]*) except +yodaerr
    void BP_isub_is "cython_isub" (BinnedProfile2D[int,string]*, BinnedProfile2D[int,string]*) except +yodaerr
    bool BP_eq_is "cython_eq" (BinnedProfile2D[int,string]*, BinnedProfile2D[int,string]*) except +yodaerr
    bool BP_ne_is "cython_ne" (BinnedProfile2D[int,string]*, BinnedProfile2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BP_div_is "cython_div" (BinnedProfile2D[int,string]*, BinnedProfile2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BP_mult_is "cython_mult" (BinnedProfile2D[int,string]*, BinnedProfile2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BP_eff_is "cython_eff" (BinnedProfile2D[int,string]*, BinnedProfile2D[int,string]*) except +yodaerr
    BinnedEstimate2D[int,string]* BP_est_is "cython_est" (BinnedProfile2D[int,string]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[int,string]* BP_binnedeffn_is "cython_effn" (BinnedProfile2D[int,string]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[int,string]* BP_hist_is "cython_hist" (BinnedProfile2D[int,string]*, string&) except +yodaerr
    BinnedProfile2D[string,double]* BP_add_sd "cython_add" (BinnedProfile2D[string,double]*, BinnedProfile2D[string,double]*) except +yodaerr
    void BP_iadd_sd "cython_iadd" (BinnedProfile2D[string,double]*, BinnedProfile2D[string,double]*) except +yodaerr
    BinnedProfile2D[string,double]* BP_sub_sd "cython_sub" (BinnedProfile2D[string,double]*, BinnedProfile2D[string,double]*) except +yodaerr
    void BP_isub_sd "cython_isub" (BinnedProfile2D[string,double]*, BinnedProfile2D[string,double]*) except +yodaerr
    bool BP_eq_sd "cython_eq" (BinnedProfile2D[string,double]*, BinnedProfile2D[string,double]*) except +yodaerr
    bool BP_ne_sd "cython_ne" (BinnedProfile2D[string,double]*, BinnedProfile2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BP_div_sd "cython_div" (BinnedProfile2D[string,double]*, BinnedProfile2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BP_mult_sd "cython_mult" (BinnedProfile2D[string,double]*, BinnedProfile2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BP_eff_sd "cython_eff" (BinnedProfile2D[string,double]*, BinnedProfile2D[string,double]*) except +yodaerr
    BinnedEstimate2D[string,double]* BP_est_sd "cython_est" (BinnedProfile2D[string,double]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[string,double]* BP_binnedeffn_sd "cython_effn" (BinnedProfile2D[string,double]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[string,double]* BP_hist_sd "cython_hist" (BinnedProfile2D[string,double]*, string&) except +yodaerr
    BinnedProfile2D[string,int]* BP_add_si "cython_add" (BinnedProfile2D[string,int]*, BinnedProfile2D[string,int]*) except +yodaerr
    void BP_iadd_si "cython_iadd" (BinnedProfile2D[string,int]*, BinnedProfile2D[string,int]*) except +yodaerr
    BinnedProfile2D[string,int]* BP_sub_si "cython_sub" (BinnedProfile2D[string,int]*, BinnedProfile2D[string,int]*) except +yodaerr
    void BP_isub_si "cython_isub" (BinnedProfile2D[string,int]*, BinnedProfile2D[string,int]*) except +yodaerr
    bool BP_eq_si "cython_eq" (BinnedProfile2D[string,int]*, BinnedProfile2D[string,int]*) except +yodaerr
    bool BP_ne_si "cython_ne" (BinnedProfile2D[string,int]*, BinnedProfile2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BP_div_si "cython_div" (BinnedProfile2D[string,int]*, BinnedProfile2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BP_mult_si "cython_mult" (BinnedProfile2D[string,int]*, BinnedProfile2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BP_eff_si "cython_eff" (BinnedProfile2D[string,int]*, BinnedProfile2D[string,int]*) except +yodaerr
    BinnedEstimate2D[string,int]* BP_est_si "cython_est" (BinnedProfile2D[string,int]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[string,int]* BP_binnedeffn_si "cython_effn" (BinnedProfile2D[string,int]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[string,int]* BP_hist_si "cython_hist" (BinnedProfile2D[string,int]*, string&) except +yodaerr
    BinnedProfile2D[string,string]* BP_add_ss "cython_add" (BinnedProfile2D[string,string]*, BinnedProfile2D[string,string]*) except +yodaerr
    void BP_iadd_ss "cython_iadd" (BinnedProfile2D[string,string]*, BinnedProfile2D[string,string]*) except +yodaerr
    BinnedProfile2D[string,string]* BP_sub_ss "cython_sub" (BinnedProfile2D[string,string]*, BinnedProfile2D[string,string]*) except +yodaerr
    void BP_isub_ss "cython_isub" (BinnedProfile2D[string,string]*, BinnedProfile2D[string,string]*) except +yodaerr
    bool BP_eq_ss "cython_eq" (BinnedProfile2D[string,string]*, BinnedProfile2D[string,string]*) except +yodaerr
    bool BP_ne_ss "cython_ne" (BinnedProfile2D[string,string]*, BinnedProfile2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BP_div_ss "cython_div" (BinnedProfile2D[string,string]*, BinnedProfile2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BP_mult_ss "cython_mult" (BinnedProfile2D[string,string]*, BinnedProfile2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BP_eff_ss "cython_eff" (BinnedProfile2D[string,string]*, BinnedProfile2D[string,string]*) except +yodaerr
    BinnedEstimate2D[string,string]* BP_est_ss "cython_est" (BinnedProfile2D[string,string]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate2D[string,string]* BP_binnedeffn_ss "cython_effn" (BinnedProfile2D[string,string]*, string&, string&, bool, bool, double) except +yodaerr
    BinnedHisto2D[string,string]* BP_hist_ss "cython_hist" (BinnedProfile2D[string,string]*, string&) except +yodaerr
    BinnedEstimate3D[double,double,double]* BE_add_ddd "cython_add" (BinnedEstimate3D[double,double,double]*, BinnedEstimate3D[double,double,double]*) except +yodaerr
    void BE_iadd_ddd "cython_iadd" (BinnedEstimate3D[double,double,double]*, BinnedEstimate3D[double,double,double]*) except +yodaerr
    BinnedEstimate3D[double,double,double]* BE_sub_ddd "cython_sub" (BinnedEstimate3D[double,double,double]*, BinnedEstimate3D[double,double,double]*) except +yodaerr
    void BE_isub_ddd "cython_isub" (BinnedEstimate3D[double,double,double]*, BinnedEstimate3D[double,double,double]*) except +yodaerr
    bool BE_eq_ddd "cython_eq" (BinnedEstimate3D[double,double,double]*, BinnedEstimate3D[double,double,double]*) except +yodaerr
    bool BE_ne_ddd "cython_ne" (BinnedEstimate3D[double,double,double]*, BinnedEstimate3D[double,double,double]*) except +yodaerr
    BinnedEstimate3D[double,double,double]* BE_div_ddd "cython_div" (BinnedEstimate3D[double,double,double]*, BinnedEstimate3D[double,double,double]*) except +yodaerr
    BinnedEstimate3D[double,double,double]* BE_mult_ddd "cython_mult" (BinnedEstimate3D[double,double,double]*, BinnedEstimate3D[double,double,double]*) except +yodaerr
    BinnedEstimate3D[double,double,double]* BE_eff_ddd "cython_eff" (BinnedEstimate3D[double,double,double]*, BinnedEstimate3D[double,double,double]*) except +yodaerr
    BinnedEstimate3D[double,double,int]* BE_add_ddi "cython_add" (BinnedEstimate3D[double,double,int]*, BinnedEstimate3D[double,double,int]*) except +yodaerr
    void BE_iadd_ddi "cython_iadd" (BinnedEstimate3D[double,double,int]*, BinnedEstimate3D[double,double,int]*) except +yodaerr
    BinnedEstimate3D[double,double,int]* BE_sub_ddi "cython_sub" (BinnedEstimate3D[double,double,int]*, BinnedEstimate3D[double,double,int]*) except +yodaerr
    void BE_isub_ddi "cython_isub" (BinnedEstimate3D[double,double,int]*, BinnedEstimate3D[double,double,int]*) except +yodaerr
    bool BE_eq_ddi "cython_eq" (BinnedEstimate3D[double,double,int]*, BinnedEstimate3D[double,double,int]*) except +yodaerr
    bool BE_ne_ddi "cython_ne" (BinnedEstimate3D[double,double,int]*, BinnedEstimate3D[double,double,int]*) except +yodaerr
    BinnedEstimate3D[double,double,int]* BE_div_ddi "cython_div" (BinnedEstimate3D[double,double,int]*, BinnedEstimate3D[double,double,int]*) except +yodaerr
    BinnedEstimate3D[double,double,int]* BE_mult_ddi "cython_mult" (BinnedEstimate3D[double,double,int]*, BinnedEstimate3D[double,double,int]*) except +yodaerr
    BinnedEstimate3D[double,double,int]* BE_eff_ddi "cython_eff" (BinnedEstimate3D[double,double,int]*, BinnedEstimate3D[double,double,int]*) except +yodaerr
    BinnedEstimate3D[double,double,string]* BE_add_dds "cython_add" (BinnedEstimate3D[double,double,string]*, BinnedEstimate3D[double,double,string]*) except +yodaerr
    void BE_iadd_dds "cython_iadd" (BinnedEstimate3D[double,double,string]*, BinnedEstimate3D[double,double,string]*) except +yodaerr
    BinnedEstimate3D[double,double,string]* BE_sub_dds "cython_sub" (BinnedEstimate3D[double,double,string]*, BinnedEstimate3D[double,double,string]*) except +yodaerr
    void BE_isub_dds "cython_isub" (BinnedEstimate3D[double,double,string]*, BinnedEstimate3D[double,double,string]*) except +yodaerr
    bool BE_eq_dds "cython_eq" (BinnedEstimate3D[double,double,string]*, BinnedEstimate3D[double,double,string]*) except +yodaerr
    bool BE_ne_dds "cython_ne" (BinnedEstimate3D[double,double,string]*, BinnedEstimate3D[double,double,string]*) except +yodaerr
    BinnedEstimate3D[double,double,string]* BE_div_dds "cython_div" (BinnedEstimate3D[double,double,string]*, BinnedEstimate3D[double,double,string]*) except +yodaerr
    BinnedEstimate3D[double,double,string]* BE_mult_dds "cython_mult" (BinnedEstimate3D[double,double,string]*, BinnedEstimate3D[double,double,string]*) except +yodaerr
    BinnedEstimate3D[double,double,string]* BE_eff_dds "cython_eff" (BinnedEstimate3D[double,double,string]*, BinnedEstimate3D[double,double,string]*) except +yodaerr
    BinnedEstimate3D[double,int,double]* BE_add_did "cython_add" (BinnedEstimate3D[double,int,double]*, BinnedEstimate3D[double,int,double]*) except +yodaerr
    void BE_iadd_did "cython_iadd" (BinnedEstimate3D[double,int,double]*, BinnedEstimate3D[double,int,double]*) except +yodaerr
    BinnedEstimate3D[double,int,double]* BE_sub_did "cython_sub" (BinnedEstimate3D[double,int,double]*, BinnedEstimate3D[double,int,double]*) except +yodaerr
    void BE_isub_did "cython_isub" (BinnedEstimate3D[double,int,double]*, BinnedEstimate3D[double,int,double]*) except +yodaerr
    bool BE_eq_did "cython_eq" (BinnedEstimate3D[double,int,double]*, BinnedEstimate3D[double,int,double]*) except +yodaerr
    bool BE_ne_did "cython_ne" (BinnedEstimate3D[double,int,double]*, BinnedEstimate3D[double,int,double]*) except +yodaerr
    BinnedEstimate3D[double,int,double]* BE_div_did "cython_div" (BinnedEstimate3D[double,int,double]*, BinnedEstimate3D[double,int,double]*) except +yodaerr
    BinnedEstimate3D[double,int,double]* BE_mult_did "cython_mult" (BinnedEstimate3D[double,int,double]*, BinnedEstimate3D[double,int,double]*) except +yodaerr
    BinnedEstimate3D[double,int,double]* BE_eff_did "cython_eff" (BinnedEstimate3D[double,int,double]*, BinnedEstimate3D[double,int,double]*) except +yodaerr
    BinnedEstimate3D[double,int,int]* BE_add_dii "cython_add" (BinnedEstimate3D[double,int,int]*, BinnedEstimate3D[double,int,int]*) except +yodaerr
    void BE_iadd_dii "cython_iadd" (BinnedEstimate3D[double,int,int]*, BinnedEstimate3D[double,int,int]*) except +yodaerr
    BinnedEstimate3D[double,int,int]* BE_sub_dii "cython_sub" (BinnedEstimate3D[double,int,int]*, BinnedEstimate3D[double,int,int]*) except +yodaerr
    void BE_isub_dii "cython_isub" (BinnedEstimate3D[double,int,int]*, BinnedEstimate3D[double,int,int]*) except +yodaerr
    bool BE_eq_dii "cython_eq" (BinnedEstimate3D[double,int,int]*, BinnedEstimate3D[double,int,int]*) except +yodaerr
    bool BE_ne_dii "cython_ne" (BinnedEstimate3D[double,int,int]*, BinnedEstimate3D[double,int,int]*) except +yodaerr
    BinnedEstimate3D[double,int,int]* BE_div_dii "cython_div" (BinnedEstimate3D[double,int,int]*, BinnedEstimate3D[double,int,int]*) except +yodaerr
    BinnedEstimate3D[double,int,int]* BE_mult_dii "cython_mult" (BinnedEstimate3D[double,int,int]*, BinnedEstimate3D[double,int,int]*) except +yodaerr
    BinnedEstimate3D[double,int,int]* BE_eff_dii "cython_eff" (BinnedEstimate3D[double,int,int]*, BinnedEstimate3D[double,int,int]*) except +yodaerr
    BinnedEstimate3D[double,int,string]* BE_add_dis "cython_add" (BinnedEstimate3D[double,int,string]*, BinnedEstimate3D[double,int,string]*) except +yodaerr
    void BE_iadd_dis "cython_iadd" (BinnedEstimate3D[double,int,string]*, BinnedEstimate3D[double,int,string]*) except +yodaerr
    BinnedEstimate3D[double,int,string]* BE_sub_dis "cython_sub" (BinnedEstimate3D[double,int,string]*, BinnedEstimate3D[double,int,string]*) except +yodaerr
    void BE_isub_dis "cython_isub" (BinnedEstimate3D[double,int,string]*, BinnedEstimate3D[double,int,string]*) except +yodaerr
    bool BE_eq_dis "cython_eq" (BinnedEstimate3D[double,int,string]*, BinnedEstimate3D[double,int,string]*) except +yodaerr
    bool BE_ne_dis "cython_ne" (BinnedEstimate3D[double,int,string]*, BinnedEstimate3D[double,int,string]*) except +yodaerr
    BinnedEstimate3D[double,int,string]* BE_div_dis "cython_div" (BinnedEstimate3D[double,int,string]*, BinnedEstimate3D[double,int,string]*) except +yodaerr
    BinnedEstimate3D[double,int,string]* BE_mult_dis "cython_mult" (BinnedEstimate3D[double,int,string]*, BinnedEstimate3D[double,int,string]*) except +yodaerr
    BinnedEstimate3D[double,int,string]* BE_eff_dis "cython_eff" (BinnedEstimate3D[double,int,string]*, BinnedEstimate3D[double,int,string]*) except +yodaerr
    BinnedEstimate3D[double,string,double]* BE_add_dsd "cython_add" (BinnedEstimate3D[double,string,double]*, BinnedEstimate3D[double,string,double]*) except +yodaerr
    void BE_iadd_dsd "cython_iadd" (BinnedEstimate3D[double,string,double]*, BinnedEstimate3D[double,string,double]*) except +yodaerr
    BinnedEstimate3D[double,string,double]* BE_sub_dsd "cython_sub" (BinnedEstimate3D[double,string,double]*, BinnedEstimate3D[double,string,double]*) except +yodaerr
    void BE_isub_dsd "cython_isub" (BinnedEstimate3D[double,string,double]*, BinnedEstimate3D[double,string,double]*) except +yodaerr
    bool BE_eq_dsd "cython_eq" (BinnedEstimate3D[double,string,double]*, BinnedEstimate3D[double,string,double]*) except +yodaerr
    bool BE_ne_dsd "cython_ne" (BinnedEstimate3D[double,string,double]*, BinnedEstimate3D[double,string,double]*) except +yodaerr
    BinnedEstimate3D[double,string,double]* BE_div_dsd "cython_div" (BinnedEstimate3D[double,string,double]*, BinnedEstimate3D[double,string,double]*) except +yodaerr
    BinnedEstimate3D[double,string,double]* BE_mult_dsd "cython_mult" (BinnedEstimate3D[double,string,double]*, BinnedEstimate3D[double,string,double]*) except +yodaerr
    BinnedEstimate3D[double,string,double]* BE_eff_dsd "cython_eff" (BinnedEstimate3D[double,string,double]*, BinnedEstimate3D[double,string,double]*) except +yodaerr
    BinnedEstimate3D[double,string,int]* BE_add_dsi "cython_add" (BinnedEstimate3D[double,string,int]*, BinnedEstimate3D[double,string,int]*) except +yodaerr
    void BE_iadd_dsi "cython_iadd" (BinnedEstimate3D[double,string,int]*, BinnedEstimate3D[double,string,int]*) except +yodaerr
    BinnedEstimate3D[double,string,int]* BE_sub_dsi "cython_sub" (BinnedEstimate3D[double,string,int]*, BinnedEstimate3D[double,string,int]*) except +yodaerr
    void BE_isub_dsi "cython_isub" (BinnedEstimate3D[double,string,int]*, BinnedEstimate3D[double,string,int]*) except +yodaerr
    bool BE_eq_dsi "cython_eq" (BinnedEstimate3D[double,string,int]*, BinnedEstimate3D[double,string,int]*) except +yodaerr
    bool BE_ne_dsi "cython_ne" (BinnedEstimate3D[double,string,int]*, BinnedEstimate3D[double,string,int]*) except +yodaerr
    BinnedEstimate3D[double,string,int]* BE_div_dsi "cython_div" (BinnedEstimate3D[double,string,int]*, BinnedEstimate3D[double,string,int]*) except +yodaerr
    BinnedEstimate3D[double,string,int]* BE_mult_dsi "cython_mult" (BinnedEstimate3D[double,string,int]*, BinnedEstimate3D[double,string,int]*) except +yodaerr
    BinnedEstimate3D[double,string,int]* BE_eff_dsi "cython_eff" (BinnedEstimate3D[double,string,int]*, BinnedEstimate3D[double,string,int]*) except +yodaerr
    BinnedEstimate3D[double,string,string]* BE_add_dss "cython_add" (BinnedEstimate3D[double,string,string]*, BinnedEstimate3D[double,string,string]*) except +yodaerr
    void BE_iadd_dss "cython_iadd" (BinnedEstimate3D[double,string,string]*, BinnedEstimate3D[double,string,string]*) except +yodaerr
    BinnedEstimate3D[double,string,string]* BE_sub_dss "cython_sub" (BinnedEstimate3D[double,string,string]*, BinnedEstimate3D[double,string,string]*) except +yodaerr
    void BE_isub_dss "cython_isub" (BinnedEstimate3D[double,string,string]*, BinnedEstimate3D[double,string,string]*) except +yodaerr
    bool BE_eq_dss "cython_eq" (BinnedEstimate3D[double,string,string]*, BinnedEstimate3D[double,string,string]*) except +yodaerr
    bool BE_ne_dss "cython_ne" (BinnedEstimate3D[double,string,string]*, BinnedEstimate3D[double,string,string]*) except +yodaerr
    BinnedEstimate3D[double,string,string]* BE_div_dss "cython_div" (BinnedEstimate3D[double,string,string]*, BinnedEstimate3D[double,string,string]*) except +yodaerr
    BinnedEstimate3D[double,string,string]* BE_mult_dss "cython_mult" (BinnedEstimate3D[double,string,string]*, BinnedEstimate3D[double,string,string]*) except +yodaerr
    BinnedEstimate3D[double,string,string]* BE_eff_dss "cython_eff" (BinnedEstimate3D[double,string,string]*, BinnedEstimate3D[double,string,string]*) except +yodaerr
    BinnedEstimate3D[int,double,double]* BE_add_idd "cython_add" (BinnedEstimate3D[int,double,double]*, BinnedEstimate3D[int,double,double]*) except +yodaerr
    void BE_iadd_idd "cython_iadd" (BinnedEstimate3D[int,double,double]*, BinnedEstimate3D[int,double,double]*) except +yodaerr
    BinnedEstimate3D[int,double,double]* BE_sub_idd "cython_sub" (BinnedEstimate3D[int,double,double]*, BinnedEstimate3D[int,double,double]*) except +yodaerr
    void BE_isub_idd "cython_isub" (BinnedEstimate3D[int,double,double]*, BinnedEstimate3D[int,double,double]*) except +yodaerr
    bool BE_eq_idd "cython_eq" (BinnedEstimate3D[int,double,double]*, BinnedEstimate3D[int,double,double]*) except +yodaerr
    bool BE_ne_idd "cython_ne" (BinnedEstimate3D[int,double,double]*, BinnedEstimate3D[int,double,double]*) except +yodaerr
    BinnedEstimate3D[int,double,double]* BE_div_idd "cython_div" (BinnedEstimate3D[int,double,double]*, BinnedEstimate3D[int,double,double]*) except +yodaerr
    BinnedEstimate3D[int,double,double]* BE_mult_idd "cython_mult" (BinnedEstimate3D[int,double,double]*, BinnedEstimate3D[int,double,double]*) except +yodaerr
    BinnedEstimate3D[int,double,double]* BE_eff_idd "cython_eff" (BinnedEstimate3D[int,double,double]*, BinnedEstimate3D[int,double,double]*) except +yodaerr
    BinnedEstimate3D[int,double,int]* BE_add_idi "cython_add" (BinnedEstimate3D[int,double,int]*, BinnedEstimate3D[int,double,int]*) except +yodaerr
    void BE_iadd_idi "cython_iadd" (BinnedEstimate3D[int,double,int]*, BinnedEstimate3D[int,double,int]*) except +yodaerr
    BinnedEstimate3D[int,double,int]* BE_sub_idi "cython_sub" (BinnedEstimate3D[int,double,int]*, BinnedEstimate3D[int,double,int]*) except +yodaerr
    void BE_isub_idi "cython_isub" (BinnedEstimate3D[int,double,int]*, BinnedEstimate3D[int,double,int]*) except +yodaerr
    bool BE_eq_idi "cython_eq" (BinnedEstimate3D[int,double,int]*, BinnedEstimate3D[int,double,int]*) except +yodaerr
    bool BE_ne_idi "cython_ne" (BinnedEstimate3D[int,double,int]*, BinnedEstimate3D[int,double,int]*) except +yodaerr
    BinnedEstimate3D[int,double,int]* BE_div_idi "cython_div" (BinnedEstimate3D[int,double,int]*, BinnedEstimate3D[int,double,int]*) except +yodaerr
    BinnedEstimate3D[int,double,int]* BE_mult_idi "cython_mult" (BinnedEstimate3D[int,double,int]*, BinnedEstimate3D[int,double,int]*) except +yodaerr
    BinnedEstimate3D[int,double,int]* BE_eff_idi "cython_eff" (BinnedEstimate3D[int,double,int]*, BinnedEstimate3D[int,double,int]*) except +yodaerr
    BinnedEstimate3D[int,double,string]* BE_add_ids "cython_add" (BinnedEstimate3D[int,double,string]*, BinnedEstimate3D[int,double,string]*) except +yodaerr
    void BE_iadd_ids "cython_iadd" (BinnedEstimate3D[int,double,string]*, BinnedEstimate3D[int,double,string]*) except +yodaerr
    BinnedEstimate3D[int,double,string]* BE_sub_ids "cython_sub" (BinnedEstimate3D[int,double,string]*, BinnedEstimate3D[int,double,string]*) except +yodaerr
    void BE_isub_ids "cython_isub" (BinnedEstimate3D[int,double,string]*, BinnedEstimate3D[int,double,string]*) except +yodaerr
    bool BE_eq_ids "cython_eq" (BinnedEstimate3D[int,double,string]*, BinnedEstimate3D[int,double,string]*) except +yodaerr
    bool BE_ne_ids "cython_ne" (BinnedEstimate3D[int,double,string]*, BinnedEstimate3D[int,double,string]*) except +yodaerr
    BinnedEstimate3D[int,double,string]* BE_div_ids "cython_div" (BinnedEstimate3D[int,double,string]*, BinnedEstimate3D[int,double,string]*) except +yodaerr
    BinnedEstimate3D[int,double,string]* BE_mult_ids "cython_mult" (BinnedEstimate3D[int,double,string]*, BinnedEstimate3D[int,double,string]*) except +yodaerr
    BinnedEstimate3D[int,double,string]* BE_eff_ids "cython_eff" (BinnedEstimate3D[int,double,string]*, BinnedEstimate3D[int,double,string]*) except +yodaerr
    BinnedEstimate3D[int,int,double]* BE_add_iid "cython_add" (BinnedEstimate3D[int,int,double]*, BinnedEstimate3D[int,int,double]*) except +yodaerr
    void BE_iadd_iid "cython_iadd" (BinnedEstimate3D[int,int,double]*, BinnedEstimate3D[int,int,double]*) except +yodaerr
    BinnedEstimate3D[int,int,double]* BE_sub_iid "cython_sub" (BinnedEstimate3D[int,int,double]*, BinnedEstimate3D[int,int,double]*) except +yodaerr
    void BE_isub_iid "cython_isub" (BinnedEstimate3D[int,int,double]*, BinnedEstimate3D[int,int,double]*) except +yodaerr
    bool BE_eq_iid "cython_eq" (BinnedEstimate3D[int,int,double]*, BinnedEstimate3D[int,int,double]*) except +yodaerr
    bool BE_ne_iid "cython_ne" (BinnedEstimate3D[int,int,double]*, BinnedEstimate3D[int,int,double]*) except +yodaerr
    BinnedEstimate3D[int,int,double]* BE_div_iid "cython_div" (BinnedEstimate3D[int,int,double]*, BinnedEstimate3D[int,int,double]*) except +yodaerr
    BinnedEstimate3D[int,int,double]* BE_mult_iid "cython_mult" (BinnedEstimate3D[int,int,double]*, BinnedEstimate3D[int,int,double]*) except +yodaerr
    BinnedEstimate3D[int,int,double]* BE_eff_iid "cython_eff" (BinnedEstimate3D[int,int,double]*, BinnedEstimate3D[int,int,double]*) except +yodaerr
    BinnedEstimate3D[int,int,int]* BE_add_iii "cython_add" (BinnedEstimate3D[int,int,int]*, BinnedEstimate3D[int,int,int]*) except +yodaerr
    void BE_iadd_iii "cython_iadd" (BinnedEstimate3D[int,int,int]*, BinnedEstimate3D[int,int,int]*) except +yodaerr
    BinnedEstimate3D[int,int,int]* BE_sub_iii "cython_sub" (BinnedEstimate3D[int,int,int]*, BinnedEstimate3D[int,int,int]*) except +yodaerr
    void BE_isub_iii "cython_isub" (BinnedEstimate3D[int,int,int]*, BinnedEstimate3D[int,int,int]*) except +yodaerr
    bool BE_eq_iii "cython_eq" (BinnedEstimate3D[int,int,int]*, BinnedEstimate3D[int,int,int]*) except +yodaerr
    bool BE_ne_iii "cython_ne" (BinnedEstimate3D[int,int,int]*, BinnedEstimate3D[int,int,int]*) except +yodaerr
    BinnedEstimate3D[int,int,int]* BE_div_iii "cython_div" (BinnedEstimate3D[int,int,int]*, BinnedEstimate3D[int,int,int]*) except +yodaerr
    BinnedEstimate3D[int,int,int]* BE_mult_iii "cython_mult" (BinnedEstimate3D[int,int,int]*, BinnedEstimate3D[int,int,int]*) except +yodaerr
    BinnedEstimate3D[int,int,int]* BE_eff_iii "cython_eff" (BinnedEstimate3D[int,int,int]*, BinnedEstimate3D[int,int,int]*) except +yodaerr
    BinnedEstimate3D[int,int,string]* BE_add_iis "cython_add" (BinnedEstimate3D[int,int,string]*, BinnedEstimate3D[int,int,string]*) except +yodaerr
    void BE_iadd_iis "cython_iadd" (BinnedEstimate3D[int,int,string]*, BinnedEstimate3D[int,int,string]*) except +yodaerr
    BinnedEstimate3D[int,int,string]* BE_sub_iis "cython_sub" (BinnedEstimate3D[int,int,string]*, BinnedEstimate3D[int,int,string]*) except +yodaerr
    void BE_isub_iis "cython_isub" (BinnedEstimate3D[int,int,string]*, BinnedEstimate3D[int,int,string]*) except +yodaerr
    bool BE_eq_iis "cython_eq" (BinnedEstimate3D[int,int,string]*, BinnedEstimate3D[int,int,string]*) except +yodaerr
    bool BE_ne_iis "cython_ne" (BinnedEstimate3D[int,int,string]*, BinnedEstimate3D[int,int,string]*) except +yodaerr
    BinnedEstimate3D[int,int,string]* BE_div_iis "cython_div" (BinnedEstimate3D[int,int,string]*, BinnedEstimate3D[int,int,string]*) except +yodaerr
    BinnedEstimate3D[int,int,string]* BE_mult_iis "cython_mult" (BinnedEstimate3D[int,int,string]*, BinnedEstimate3D[int,int,string]*) except +yodaerr
    BinnedEstimate3D[int,int,string]* BE_eff_iis "cython_eff" (BinnedEstimate3D[int,int,string]*, BinnedEstimate3D[int,int,string]*) except +yodaerr
    BinnedEstimate3D[int,string,double]* BE_add_isd "cython_add" (BinnedEstimate3D[int,string,double]*, BinnedEstimate3D[int,string,double]*) except +yodaerr
    void BE_iadd_isd "cython_iadd" (BinnedEstimate3D[int,string,double]*, BinnedEstimate3D[int,string,double]*) except +yodaerr
    BinnedEstimate3D[int,string,double]* BE_sub_isd "cython_sub" (BinnedEstimate3D[int,string,double]*, BinnedEstimate3D[int,string,double]*) except +yodaerr
    void BE_isub_isd "cython_isub" (BinnedEstimate3D[int,string,double]*, BinnedEstimate3D[int,string,double]*) except +yodaerr
    bool BE_eq_isd "cython_eq" (BinnedEstimate3D[int,string,double]*, BinnedEstimate3D[int,string,double]*) except +yodaerr
    bool BE_ne_isd "cython_ne" (BinnedEstimate3D[int,string,double]*, BinnedEstimate3D[int,string,double]*) except +yodaerr
    BinnedEstimate3D[int,string,double]* BE_div_isd "cython_div" (BinnedEstimate3D[int,string,double]*, BinnedEstimate3D[int,string,double]*) except +yodaerr
    BinnedEstimate3D[int,string,double]* BE_mult_isd "cython_mult" (BinnedEstimate3D[int,string,double]*, BinnedEstimate3D[int,string,double]*) except +yodaerr
    BinnedEstimate3D[int,string,double]* BE_eff_isd "cython_eff" (BinnedEstimate3D[int,string,double]*, BinnedEstimate3D[int,string,double]*) except +yodaerr
    BinnedEstimate3D[int,string,int]* BE_add_isi "cython_add" (BinnedEstimate3D[int,string,int]*, BinnedEstimate3D[int,string,int]*) except +yodaerr
    void BE_iadd_isi "cython_iadd" (BinnedEstimate3D[int,string,int]*, BinnedEstimate3D[int,string,int]*) except +yodaerr
    BinnedEstimate3D[int,string,int]* BE_sub_isi "cython_sub" (BinnedEstimate3D[int,string,int]*, BinnedEstimate3D[int,string,int]*) except +yodaerr
    void BE_isub_isi "cython_isub" (BinnedEstimate3D[int,string,int]*, BinnedEstimate3D[int,string,int]*) except +yodaerr
    bool BE_eq_isi "cython_eq" (BinnedEstimate3D[int,string,int]*, BinnedEstimate3D[int,string,int]*) except +yodaerr
    bool BE_ne_isi "cython_ne" (BinnedEstimate3D[int,string,int]*, BinnedEstimate3D[int,string,int]*) except +yodaerr
    BinnedEstimate3D[int,string,int]* BE_div_isi "cython_div" (BinnedEstimate3D[int,string,int]*, BinnedEstimate3D[int,string,int]*) except +yodaerr
    BinnedEstimate3D[int,string,int]* BE_mult_isi "cython_mult" (BinnedEstimate3D[int,string,int]*, BinnedEstimate3D[int,string,int]*) except +yodaerr
    BinnedEstimate3D[int,string,int]* BE_eff_isi "cython_eff" (BinnedEstimate3D[int,string,int]*, BinnedEstimate3D[int,string,int]*) except +yodaerr
    BinnedEstimate3D[int,string,string]* BE_add_iss "cython_add" (BinnedEstimate3D[int,string,string]*, BinnedEstimate3D[int,string,string]*) except +yodaerr
    void BE_iadd_iss "cython_iadd" (BinnedEstimate3D[int,string,string]*, BinnedEstimate3D[int,string,string]*) except +yodaerr
    BinnedEstimate3D[int,string,string]* BE_sub_iss "cython_sub" (BinnedEstimate3D[int,string,string]*, BinnedEstimate3D[int,string,string]*) except +yodaerr
    void BE_isub_iss "cython_isub" (BinnedEstimate3D[int,string,string]*, BinnedEstimate3D[int,string,string]*) except +yodaerr
    bool BE_eq_iss "cython_eq" (BinnedEstimate3D[int,string,string]*, BinnedEstimate3D[int,string,string]*) except +yodaerr
    bool BE_ne_iss "cython_ne" (BinnedEstimate3D[int,string,string]*, BinnedEstimate3D[int,string,string]*) except +yodaerr
    BinnedEstimate3D[int,string,string]* BE_div_iss "cython_div" (BinnedEstimate3D[int,string,string]*, BinnedEstimate3D[int,string,string]*) except +yodaerr
    BinnedEstimate3D[int,string,string]* BE_mult_iss "cython_mult" (BinnedEstimate3D[int,string,string]*, BinnedEstimate3D[int,string,string]*) except +yodaerr
    BinnedEstimate3D[int,string,string]* BE_eff_iss "cython_eff" (BinnedEstimate3D[int,string,string]*, BinnedEstimate3D[int,string,string]*) except +yodaerr
    BinnedEstimate3D[string,double,double]* BE_add_sdd "cython_add" (BinnedEstimate3D[string,double,double]*, BinnedEstimate3D[string,double,double]*) except +yodaerr
    void BE_iadd_sdd "cython_iadd" (BinnedEstimate3D[string,double,double]*, BinnedEstimate3D[string,double,double]*) except +yodaerr
    BinnedEstimate3D[string,double,double]* BE_sub_sdd "cython_sub" (BinnedEstimate3D[string,double,double]*, BinnedEstimate3D[string,double,double]*) except +yodaerr
    void BE_isub_sdd "cython_isub" (BinnedEstimate3D[string,double,double]*, BinnedEstimate3D[string,double,double]*) except +yodaerr
    bool BE_eq_sdd "cython_eq" (BinnedEstimate3D[string,double,double]*, BinnedEstimate3D[string,double,double]*) except +yodaerr
    bool BE_ne_sdd "cython_ne" (BinnedEstimate3D[string,double,double]*, BinnedEstimate3D[string,double,double]*) except +yodaerr
    BinnedEstimate3D[string,double,double]* BE_div_sdd "cython_div" (BinnedEstimate3D[string,double,double]*, BinnedEstimate3D[string,double,double]*) except +yodaerr
    BinnedEstimate3D[string,double,double]* BE_mult_sdd "cython_mult" (BinnedEstimate3D[string,double,double]*, BinnedEstimate3D[string,double,double]*) except +yodaerr
    BinnedEstimate3D[string,double,double]* BE_eff_sdd "cython_eff" (BinnedEstimate3D[string,double,double]*, BinnedEstimate3D[string,double,double]*) except +yodaerr
    BinnedEstimate3D[string,double,int]* BE_add_sdi "cython_add" (BinnedEstimate3D[string,double,int]*, BinnedEstimate3D[string,double,int]*) except +yodaerr
    void BE_iadd_sdi "cython_iadd" (BinnedEstimate3D[string,double,int]*, BinnedEstimate3D[string,double,int]*) except +yodaerr
    BinnedEstimate3D[string,double,int]* BE_sub_sdi "cython_sub" (BinnedEstimate3D[string,double,int]*, BinnedEstimate3D[string,double,int]*) except +yodaerr
    void BE_isub_sdi "cython_isub" (BinnedEstimate3D[string,double,int]*, BinnedEstimate3D[string,double,int]*) except +yodaerr
    bool BE_eq_sdi "cython_eq" (BinnedEstimate3D[string,double,int]*, BinnedEstimate3D[string,double,int]*) except +yodaerr
    bool BE_ne_sdi "cython_ne" (BinnedEstimate3D[string,double,int]*, BinnedEstimate3D[string,double,int]*) except +yodaerr
    BinnedEstimate3D[string,double,int]* BE_div_sdi "cython_div" (BinnedEstimate3D[string,double,int]*, BinnedEstimate3D[string,double,int]*) except +yodaerr
    BinnedEstimate3D[string,double,int]* BE_mult_sdi "cython_mult" (BinnedEstimate3D[string,double,int]*, BinnedEstimate3D[string,double,int]*) except +yodaerr
    BinnedEstimate3D[string,double,int]* BE_eff_sdi "cython_eff" (BinnedEstimate3D[string,double,int]*, BinnedEstimate3D[string,double,int]*) except +yodaerr
    BinnedEstimate3D[string,double,string]* BE_add_sds "cython_add" (BinnedEstimate3D[string,double,string]*, BinnedEstimate3D[string,double,string]*) except +yodaerr
    void BE_iadd_sds "cython_iadd" (BinnedEstimate3D[string,double,string]*, BinnedEstimate3D[string,double,string]*) except +yodaerr
    BinnedEstimate3D[string,double,string]* BE_sub_sds "cython_sub" (BinnedEstimate3D[string,double,string]*, BinnedEstimate3D[string,double,string]*) except +yodaerr
    void BE_isub_sds "cython_isub" (BinnedEstimate3D[string,double,string]*, BinnedEstimate3D[string,double,string]*) except +yodaerr
    bool BE_eq_sds "cython_eq" (BinnedEstimate3D[string,double,string]*, BinnedEstimate3D[string,double,string]*) except +yodaerr
    bool BE_ne_sds "cython_ne" (BinnedEstimate3D[string,double,string]*, BinnedEstimate3D[string,double,string]*) except +yodaerr
    BinnedEstimate3D[string,double,string]* BE_div_sds "cython_div" (BinnedEstimate3D[string,double,string]*, BinnedEstimate3D[string,double,string]*) except +yodaerr
    BinnedEstimate3D[string,double,string]* BE_mult_sds "cython_mult" (BinnedEstimate3D[string,double,string]*, BinnedEstimate3D[string,double,string]*) except +yodaerr
    BinnedEstimate3D[string,double,string]* BE_eff_sds "cython_eff" (BinnedEstimate3D[string,double,string]*, BinnedEstimate3D[string,double,string]*) except +yodaerr
    BinnedEstimate3D[string,int,double]* BE_add_sid "cython_add" (BinnedEstimate3D[string,int,double]*, BinnedEstimate3D[string,int,double]*) except +yodaerr
    void BE_iadd_sid "cython_iadd" (BinnedEstimate3D[string,int,double]*, BinnedEstimate3D[string,int,double]*) except +yodaerr
    BinnedEstimate3D[string,int,double]* BE_sub_sid "cython_sub" (BinnedEstimate3D[string,int,double]*, BinnedEstimate3D[string,int,double]*) except +yodaerr
    void BE_isub_sid "cython_isub" (BinnedEstimate3D[string,int,double]*, BinnedEstimate3D[string,int,double]*) except +yodaerr
    bool BE_eq_sid "cython_eq" (BinnedEstimate3D[string,int,double]*, BinnedEstimate3D[string,int,double]*) except +yodaerr
    bool BE_ne_sid "cython_ne" (BinnedEstimate3D[string,int,double]*, BinnedEstimate3D[string,int,double]*) except +yodaerr
    BinnedEstimate3D[string,int,double]* BE_div_sid "cython_div" (BinnedEstimate3D[string,int,double]*, BinnedEstimate3D[string,int,double]*) except +yodaerr
    BinnedEstimate3D[string,int,double]* BE_mult_sid "cython_mult" (BinnedEstimate3D[string,int,double]*, BinnedEstimate3D[string,int,double]*) except +yodaerr
    BinnedEstimate3D[string,int,double]* BE_eff_sid "cython_eff" (BinnedEstimate3D[string,int,double]*, BinnedEstimate3D[string,int,double]*) except +yodaerr
    BinnedEstimate3D[string,int,int]* BE_add_sii "cython_add" (BinnedEstimate3D[string,int,int]*, BinnedEstimate3D[string,int,int]*) except +yodaerr
    void BE_iadd_sii "cython_iadd" (BinnedEstimate3D[string,int,int]*, BinnedEstimate3D[string,int,int]*) except +yodaerr
    BinnedEstimate3D[string,int,int]* BE_sub_sii "cython_sub" (BinnedEstimate3D[string,int,int]*, BinnedEstimate3D[string,int,int]*) except +yodaerr
    void BE_isub_sii "cython_isub" (BinnedEstimate3D[string,int,int]*, BinnedEstimate3D[string,int,int]*) except +yodaerr
    bool BE_eq_sii "cython_eq" (BinnedEstimate3D[string,int,int]*, BinnedEstimate3D[string,int,int]*) except +yodaerr
    bool BE_ne_sii "cython_ne" (BinnedEstimate3D[string,int,int]*, BinnedEstimate3D[string,int,int]*) except +yodaerr
    BinnedEstimate3D[string,int,int]* BE_div_sii "cython_div" (BinnedEstimate3D[string,int,int]*, BinnedEstimate3D[string,int,int]*) except +yodaerr
    BinnedEstimate3D[string,int,int]* BE_mult_sii "cython_mult" (BinnedEstimate3D[string,int,int]*, BinnedEstimate3D[string,int,int]*) except +yodaerr
    BinnedEstimate3D[string,int,int]* BE_eff_sii "cython_eff" (BinnedEstimate3D[string,int,int]*, BinnedEstimate3D[string,int,int]*) except +yodaerr
    BinnedEstimate3D[string,int,string]* BE_add_sis "cython_add" (BinnedEstimate3D[string,int,string]*, BinnedEstimate3D[string,int,string]*) except +yodaerr
    void BE_iadd_sis "cython_iadd" (BinnedEstimate3D[string,int,string]*, BinnedEstimate3D[string,int,string]*) except +yodaerr
    BinnedEstimate3D[string,int,string]* BE_sub_sis "cython_sub" (BinnedEstimate3D[string,int,string]*, BinnedEstimate3D[string,int,string]*) except +yodaerr
    void BE_isub_sis "cython_isub" (BinnedEstimate3D[string,int,string]*, BinnedEstimate3D[string,int,string]*) except +yodaerr
    bool BE_eq_sis "cython_eq" (BinnedEstimate3D[string,int,string]*, BinnedEstimate3D[string,int,string]*) except +yodaerr
    bool BE_ne_sis "cython_ne" (BinnedEstimate3D[string,int,string]*, BinnedEstimate3D[string,int,string]*) except +yodaerr
    BinnedEstimate3D[string,int,string]* BE_div_sis "cython_div" (BinnedEstimate3D[string,int,string]*, BinnedEstimate3D[string,int,string]*) except +yodaerr
    BinnedEstimate3D[string,int,string]* BE_mult_sis "cython_mult" (BinnedEstimate3D[string,int,string]*, BinnedEstimate3D[string,int,string]*) except +yodaerr
    BinnedEstimate3D[string,int,string]* BE_eff_sis "cython_eff" (BinnedEstimate3D[string,int,string]*, BinnedEstimate3D[string,int,string]*) except +yodaerr
    BinnedEstimate3D[string,string,double]* BE_add_ssd "cython_add" (BinnedEstimate3D[string,string,double]*, BinnedEstimate3D[string,string,double]*) except +yodaerr
    void BE_iadd_ssd "cython_iadd" (BinnedEstimate3D[string,string,double]*, BinnedEstimate3D[string,string,double]*) except +yodaerr
    BinnedEstimate3D[string,string,double]* BE_sub_ssd "cython_sub" (BinnedEstimate3D[string,string,double]*, BinnedEstimate3D[string,string,double]*) except +yodaerr
    void BE_isub_ssd "cython_isub" (BinnedEstimate3D[string,string,double]*, BinnedEstimate3D[string,string,double]*) except +yodaerr
    bool BE_eq_ssd "cython_eq" (BinnedEstimate3D[string,string,double]*, BinnedEstimate3D[string,string,double]*) except +yodaerr
    bool BE_ne_ssd "cython_ne" (BinnedEstimate3D[string,string,double]*, BinnedEstimate3D[string,string,double]*) except +yodaerr
    BinnedEstimate3D[string,string,double]* BE_div_ssd "cython_div" (BinnedEstimate3D[string,string,double]*, BinnedEstimate3D[string,string,double]*) except +yodaerr
    BinnedEstimate3D[string,string,double]* BE_mult_ssd "cython_mult" (BinnedEstimate3D[string,string,double]*, BinnedEstimate3D[string,string,double]*) except +yodaerr
    BinnedEstimate3D[string,string,double]* BE_eff_ssd "cython_eff" (BinnedEstimate3D[string,string,double]*, BinnedEstimate3D[string,string,double]*) except +yodaerr
    BinnedEstimate3D[string,string,int]* BE_add_ssi "cython_add" (BinnedEstimate3D[string,string,int]*, BinnedEstimate3D[string,string,int]*) except +yodaerr
    void BE_iadd_ssi "cython_iadd" (BinnedEstimate3D[string,string,int]*, BinnedEstimate3D[string,string,int]*) except +yodaerr
    BinnedEstimate3D[string,string,int]* BE_sub_ssi "cython_sub" (BinnedEstimate3D[string,string,int]*, BinnedEstimate3D[string,string,int]*) except +yodaerr
    void BE_isub_ssi "cython_isub" (BinnedEstimate3D[string,string,int]*, BinnedEstimate3D[string,string,int]*) except +yodaerr
    bool BE_eq_ssi "cython_eq" (BinnedEstimate3D[string,string,int]*, BinnedEstimate3D[string,string,int]*) except +yodaerr
    bool BE_ne_ssi "cython_ne" (BinnedEstimate3D[string,string,int]*, BinnedEstimate3D[string,string,int]*) except +yodaerr
    BinnedEstimate3D[string,string,int]* BE_div_ssi "cython_div" (BinnedEstimate3D[string,string,int]*, BinnedEstimate3D[string,string,int]*) except +yodaerr
    BinnedEstimate3D[string,string,int]* BE_mult_ssi "cython_mult" (BinnedEstimate3D[string,string,int]*, BinnedEstimate3D[string,string,int]*) except +yodaerr
    BinnedEstimate3D[string,string,int]* BE_eff_ssi "cython_eff" (BinnedEstimate3D[string,string,int]*, BinnedEstimate3D[string,string,int]*) except +yodaerr
    BinnedEstimate3D[string,string,string]* BE_add_sss "cython_add" (BinnedEstimate3D[string,string,string]*, BinnedEstimate3D[string,string,string]*) except +yodaerr
    void BE_iadd_sss "cython_iadd" (BinnedEstimate3D[string,string,string]*, BinnedEstimate3D[string,string,string]*) except +yodaerr
    BinnedEstimate3D[string,string,string]* BE_sub_sss "cython_sub" (BinnedEstimate3D[string,string,string]*, BinnedEstimate3D[string,string,string]*) except +yodaerr
    void BE_isub_sss "cython_isub" (BinnedEstimate3D[string,string,string]*, BinnedEstimate3D[string,string,string]*) except +yodaerr
    bool BE_eq_sss "cython_eq" (BinnedEstimate3D[string,string,string]*, BinnedEstimate3D[string,string,string]*) except +yodaerr
    bool BE_ne_sss "cython_ne" (BinnedEstimate3D[string,string,string]*, BinnedEstimate3D[string,string,string]*) except +yodaerr
    BinnedEstimate3D[string,string,string]* BE_div_sss "cython_div" (BinnedEstimate3D[string,string,string]*, BinnedEstimate3D[string,string,string]*) except +yodaerr
    BinnedEstimate3D[string,string,string]* BE_mult_sss "cython_mult" (BinnedEstimate3D[string,string,string]*, BinnedEstimate3D[string,string,string]*) except +yodaerr
    BinnedEstimate3D[string,string,string]* BE_eff_sss "cython_eff" (BinnedEstimate3D[string,string,string]*, BinnedEstimate3D[string,string,string]*) except +yodaerr
    BinnedHisto3D[double,double,double]* BH_add_ddd "cython_add" (BinnedHisto3D[double,double,double]*, BinnedHisto3D[double,double,double]*) except +yodaerr
    void BH_iadd_ddd "cython_iadd" (BinnedHisto3D[double,double,double]*, BinnedHisto3D[double,double,double]*) except +yodaerr
    BinnedHisto3D[double,double,double]* BH_sub_ddd "cython_sub" (BinnedHisto3D[double,double,double]*, BinnedHisto3D[double,double,double]*) except +yodaerr
    void BH_isub_ddd "cython_isub" (BinnedHisto3D[double,double,double]*, BinnedHisto3D[double,double,double]*) except +yodaerr
    bool BH_eq_ddd "cython_eq" (BinnedHisto3D[double,double,double]*, BinnedHisto3D[double,double,double]*) except +yodaerr
    bool BH_ne_ddd "cython_ne" (BinnedHisto3D[double,double,double]*, BinnedHisto3D[double,double,double]*) except +yodaerr
    BinnedEstimate3D[double,double,double]* BH_div_ddd "cython_div" (BinnedHisto3D[double,double,double]*, BinnedHisto3D[double,double,double]*) except +yodaerr
    BinnedEstimate3D[double,double,double]* BH_mult_ddd "cython_mult" (BinnedHisto3D[double,double,double]*, BinnedHisto3D[double,double,double]*) except +yodaerr
    BinnedEstimate3D[double,double,double]* BH_eff_ddd "cython_eff" (BinnedHisto3D[double,double,double]*, BinnedHisto3D[double,double,double]*) except +yodaerr
    BinnedEstimate3D[double,double,double]* BH_est_ddd "cython_est" (BinnedHisto3D[double,double,double]*, string&, string&, bool, double) except +yodaerr
    BinnedEstimate3D[double,double,double]* BH_binnedeffn_ddd "cython_effn" (BinnedHisto3D[double,double,double]*, string&, string&, bool, bool, double) except +yodaerr

