# ChangeLog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).



## [Unreleased 2.1.x]

### Added

### Fixed


## [2.1.4] - 2026-09-10

### Added

- Plotting: reinstate tick-mark toggles.
- Plotting: added support for positioning legends
  with respect to ratio-panel coordindates

### Fixed

- `numeric_limits::min` -> `numeric_limits::lowest`, thanks to Tomasz Procter.
- Add missing `std::` prefix to `vector` tests. Thanks to Alex Puck Neuwirth.
- Fix issue in the legacy YODA1 reader where the binning of YODA1-style Histo2D
  objects may not have been correctly reconstructed


## [2.1.3] - 2026-05-22

### Added

- `xEdges()`, `yEdges()` and `zEdges()` are now propagated from C++ to the Python API for discrete axes, so discrete-axis bin edges can be queried directly from Python.
- Binned objects now provide a `shape()` method returning a tuple of the bin counts, with an optional Boolean to include or exclude overflows.
- A multiplication operator is now defined for binned objects and `Counter`s.
- API arrays are now returned as NumPy arrays when NumPy is available.
- `RatioYMax`/`RatioYMin` now also work in deviation mode.
- `yodadiff` now works for objects with more than three dimensions.

### Fixed

- Fixed a bug whereby rebinning analysis objects via the Python API could leave the Python and C++ representations of the internal binning out of sync.
- Fixed a small bug affecting 2D histograms in the `yoda2root` script.
- $y$-axis maximum/minimum values are no longer affected by `NaN`s representing empty bins.

### Changed

- Reinstate auto-numpy-wrapping for Python API.
- Adapt `read_symmetric` to interpret error as signed for `Estimates`.
- `BinnedDbn`s now use global Neff, rather than per-bin variant. Thanks to Jonas Hahnfeld for the report!
- `effNumEntries` for binned histograms and profiles is now calculated from the total $\sum w$ and $\sum w^2$ rather than the per-bin values.
- NumPy warnings about all-`NaN` arrays (which can arise from empty histograms) are now silenced.


## [2.1.2] - 2025-10-24

### Added

- Regex substitutions now also apply to custom text boxes, with support for square brackets `[]`.
- Text labels now support mixed single and double quotes.
- Python-based `yoda.write()` can now be redirected to `stdout`.

### Fixed

- Large NumPy arrays in plotting scripts are no longer truncated.
- Fixed an issue affecting analyses with multiple ratio panels and analysis options.
- Corrected asymmetric error-bar ordering in Matplotlib.
- Fixed a bug in handling single-value opacity settings.


## [2.1.1] - 2025-08-05

### Added

- Add an implementation of the Kolmogorov–Smirnov test statistic.
- Add utility function `mkEffNumEntries()`.
- Add support for YODA-to-HEPData YAML conversion.
- Add `--enable-h5-rpath` build option to allow use of `RPATH` for locating the HDF5 library.
- Support plotting underflow and overflow bins, and auxiliary vertical/horizontal lines.
- Support inconsistent binning in ratio panels, and line-opacity options.
- Regex-substitution support extended to extract components from option strings for use in legend labels.
- Cythonise YODA exceptions.

### Fixed

- `yodaenvelope` now correctly handles `Estimate` objects.
- Fix bug where `Estimate`s were incorrectly stacked instead of averaged in `yodamerge`.
- Heatmap-plotting transposition issues have been resolved

### Changed

- Enhanced support for histogram normalisation in yodascale, with new options for `--norm-to-area`/`--norm-to-integral`, and `--norm-to-sum`.
- Histogram axes using string labels now accept `Total` as a valid edge label, and a new helper method has been added to extract visible indices from binned objects.
- Harmonise `yoda-config` and `pkg-config` outputs for greater consistency; see `--help` for details on the updated behaviour.
- Skip objects with inconsistent binning in `yodamerge` and `yodastack`.


## [2.1.0] - 2025-03-07

### Added

- Add support for regex-based capture of AO path/name components with optional string-substitution map.
- HDF5 support for HPC applications (optional) – a new output format using HDF5 + HighFive, optimised for high-performance computing.
- Users can now choose between bundled yaml-cpp and HighFive dependencies or provide external installtions.
- Overflow bin visualisation: overflow bins can now be displayed in plots.
- Regex-based titles and labels: regex support allows extracting components from histogram names to automatically format titles and labels.


## [2.0.3] - 2025-02-09

### Added

- Add exception handling and `Scatter1D` conversion to YODA-to-ROOT conversion.
- Add `CXXFLAGS` and `LDFLAGS` propagation to the Python-extension build script (thanks to Alexander Puck Neuwirth for the suggestion).
- Add binreloc-based `libPath()` and `dataPath()` functions, including in Python.

### Fixed

- Fix typo and path-setting in `yodaenvelope`. Thanks to Alan Price for the patch.
- Fix Python path-detection again, cf. GAMBIT Mac CI. Thanks to Chris Chang.
- Fix bug in `yodamerge` to handle files with inconsistent AOs Thanks to Alexander Puck Neuwirth for the report!

### Changed

- Convert all scripts to use explicit `python3` as interpreter, and remove defunct uses of `from __future__ import` except in `configure.ac` where compatibility is needed to detect and reject Python2.
- Restore case-sensitivity for Python dictionary in `annotationsDict()` call.
- Change Python build to use `PY_LDFLAGS` rather than `LINKFORSHARED` variable.
- Enable `-Wextra` warnings upon recommendation from CMS, and address resulting issues.


## [2.0.0] - 2025-??-??

## Changed

- Completely redesigned backend, based on GSoc work done by Nick Rozinsky. Introduces a redesigned backend new set of AnalysisObjects	generalised to arbitrary dimensions	Requires C++17 flag. More detailed write-up in progress.
- Introducing matplotlib based plotting: standalone Python scripts are generated that contain the logic to produce a plot. These script do not depend on YODA and should hence be sharable with people that have no YODA. Python3 and matplotlib are required. The numerical data	associated with individual curves is outsourced to a `{name}__data.py` script to aid legibility.
- Enable Cython auto-conversion of all C++ strings to Python native `str` for v2 and v3, removing extensive `encode()`/`decode()` calls.


## [1.9.7] - 2022-09-27

### Added

- Add `Stat` and `Uncor` to labels flagged as uncorrelated.

### Changed

- Update yaml-cpp version for C++17 compatibility.
- Replace `distutils` with `sysconfig` and manual calls to the compiler.


## [1.9.6] - 2022-07-15

### Added

- Add a covariance/off-diag test to `test-s2d.py`

### Changed

- Pass `ignoreOffDiagonalTerms` correctly when retrieving covariance matrix from a `Scatter2D`.
- Force Cython rebuilds on all `.pyx` files, if possible (helps with Python ABI compat).


## [1.9.5] - 2022-05-13

### Added

- Add per-AO double-precision writing if the `WriterDoublePrecision` annotation is set.

### Changed

- Ensure that default variation +- errors are both positive, for all `Scatter` types.  Original patch by Jon Butterworth.
- Protect against `NaNs` arising from the YAML parser in error-breakdown calcs.


## [1.9.4] - 2021-12-02

### Fixed

- Fix `Scatter.variations` keys to be `str` instead of `bytes` in Python 3.


## [1.9.3] - 2021-11-24

### Fixed

- Fix `Point.errMap()` keys to be `str` instead of `bytes` in Python 3.
- Fix ambiguity/bugginess in the `yoda.mkScatter()` unbound helper function.

### Changed

- `yoda2root`, `root2yoda`: use ROOT in the batch mode
- Restructure tests to use autotools standard naming and trigger on extensions, and to ensure `testwriter` runs before `testreader`.
- Catch low-stats errors in computing errors in `H1` and `H2` conversion to scatters.


## [1.9.2] - 2021-11-05

### Added

- Introduce `rmVariations()` for `Points` and `Scatters`
- Add precision arguments to unbound write functions, and Python mapping of `setPrecision()` and `useCompression()` methods of `Writer` classes.
- Add `updateTotalUncertainty` method which allows the user to automatically set the total error to the sum in quad of the error components for each point.
- Add `adoptPoint(s)` methods to the `Scatter*D` classes, which allows to add a previously-instantiated point while modifying its parentage so that it points back to that `Scatter`. This is then substituted into the Python binding for `addPoint` so that the user does not need to manually set the parentage of a point.
- Add some missing functionality which used to only be available to `Scatter2D` to also cover `Scatter{1,3}D`.
- Add many additional tests to cover the `ErrorBreakdown` functionality in existing `pytest` scripts

### Removed

- Remove rogue `s.variations()` call, causing `rivet-merge` to crash
- Remove `adoptPoint`, make `addPoint(Point)` argument non-const since one should always want to update the parent of the point.

### Fixed

- Fix `ao.path` setting to use `ao.setPath()` in `root2yoda`. Thanks to Julia Yarba for the report.
- Fix IO failure modes to actually report exceptions, and with correct types and error messages.
- Fix broken reading gzipped files in Python (was a regression in 1.9.0)
- Fix `yAvgErr` -> `yErrAvg` typo in `Scatter2D.yErrAvgs`.
- Fix a bug with reading files while running with non-US locales.

### Changed

- Provide more options to specify the Cython command to be used. Thanks to Christian Holm Christensen.
- `yodascale`: improved handling of `.yoda.gz` extensions, and adding `--output`.
- Change the `Axis2D` edge-uniqueness test to be based on the smallest bin width rather than the median. (Smarter could be to comparer with the smallest of the surrounding bin widths. Or drop entirely, as 1D doesn't *seem* to have real problems with numerical near-matches.)
- Modify the `Scatter*D` copy constructor so that the parentage of the relevant points is correctly set, to avoid set faults after a `Scatter*D` is `clone()`'d.
- `Bin2D`: use `fuzzyEquals` for bin-edge comparisons. Required for correct `rivet-merge` behaviour with 2D histograms.
- Provide `x,yWidths()` functions on `Histos` and `Profiles`.


## [1.9.0] - 2021-03-31

### Added

- Add missing inline declarations to free IO functions.
- Add `fillDim()` methods to the `Bin`, `Bin1D` and `Bin2D` classes.
- Add `Scatter` base class to the `Scatter` classes, with `rmPoints()` implemented there.
- Add `Binned` and `Fillable` base classes, the former introducing the `fillDim()` method and `rmBin()`, and use them as ABCs for the counter, histo and profile types.
- Add `rmPoint()` and `rmPoints()` methods on all `Scatter` types.
- Add `<limits>` header include to `AnalysisObject.h` to support GCC11 (cf. http://gcc.gnu.org/gcc-11/porting_to.html)

### Removed

- Remove ROOT5 compatibility, and handle 6.22 change in PyROOT.

### Fixed

- Fix out-of-source builds re. bash completions.

### Changed

- Rename the Point `getParentAO` etc. to `getParent`, using the new `Scatter` base, and improve the accessor methods.
- Allow YODA's Python interface to read from `StringIO` and `FileIO` objects.
- Change `scaleDim()` to `scale()` for points and scatters
- Fixes to the `Profile1D` Python interface.
- Restructure `yodamerge` to use pairwise merges, avoiding simultaneous loading of all the input files and greatly speeding up processing. Simultaneous simplification by replacement of `yodamerge` stacking functionality with `yodastack`.


## [1.8.5] - 2020-11-25

### Added

- Add `relErrs()` functions to the `H1D` and `H2D` Python interfaces.
- Add an explicit configure test and override variable for the `cython` executable.

### Fixed

- Fix typo from `xAvgErr` -> `xErrAvg` in `Scatter2D.xErrAvgs()` Python function.


## [1.8.4] - 2020-11-05

### Fixed

- Fix `Point1D.setXErrs()` function to handle sources and asymm errors correctly.
- Fix missing call-parentheses in Python-mapped `Bin` classes, including in the `__repr__` functions, which was making `print(bin)` crash.

### Changed

- Don't suppress cross-section-normalised empty histograms in `yodamerge`
- Use ROOT's `ROOT_VERSION_CODE` and `ROOT_VERSION` macros to handle the changing `TPython` API.
- Do not apply bin-width scaling by default between YODA and ROOT binned objects.
- Improve ROOT conversion utilities to support a fuller set of width-scaling and focus-mapping options.
- Map scatter `reset()` functions into Python.
- Create bash completion dir in `$prefix/etc` if it doesn't exist.


## [1.8.3] - 2020-07-02

### Added

- Add `asgrid` optional arguments to value-related Python methods for `Histo2D` and `Profile2D`
- Add computation of Python versions and passing them to Cython as command-line flags.

### Fixed

- Fix `Histo2D.volumes()` Python mapping, and add `sumWs()` functions to all histo types.

### Changed

- The Python method `Histo2D.addBins` was reimplemented using `Histo2D::addBins()` C++ method instead of `Histo2D::addBin()` for better performance.
- Make the low stats error for variances strictly require Neff > 1, rather than a fuzzy comparison that can cause trouble downstream.
- Make `xyMids,Foci,Errs,Mins,Maxs` etc. runtime configurable with `unique` and `asgrid` optional params.
- Convert geometric axis-property array functions on `Histo2D` and `Profile2D` to return the unique edges, mins, maxes, mids, etc. rather than the heavily repeated versions for all the bins.


## [1.8.2] - 2020-05-08

### Added

- Add `numBinsX()` methods to the 1D histogram and profile classes.

### Fixed

- Fix off-by-one error in `Axis2D.numBinsX/Y()` return values, fixing `Histo2D` and `Profile2D`.
- Fix call to `Histo1D.annotationsDict`
- Py3 compatibility fix


## [1.8.1] - 2020-04-03

### Added

- Added `zerrs` to `Scatter3D` headers.
- Added `xErrs`, `yErrs`, `zErrs` to `Scatter3D.pyx`
- Add underflow and overflow reporting to the verbose `yodals` printout.
- Add a `pdfspace()` function in C++ and a Python equivalent -- recoded rather than mapped, due to the technical implications of passing Python callables as `std::function`s -- for custom binning from a density function.

### Removed

- Removed unwanted space at end of headers.

### Fixed

- Fix list-return read YODA-format function.
- Fix YODA 1.7 style call to `AO.dim`.

### Changed

- Set correct dimension when calling `setErrs`.
- Re-instate `title()` and fix bug in z-error storage for `Scatter3D`s.
- Python3 compatibility tweaks
- Update `yodamerge` `ao_out.point(i).setVal(dim, val_i)`
- `IO.pyx`: missing Python3 compatibility
- Sort dicts on IO `write()`, and return ordered dicts in read mode if possible.


## [1.8.0] - 2019-12-20

### Added

- Add extra optional bool arguments to the `mkScatter` converter functions for `Histo1D` and `Histo2D` types.
- Add `x/yErrs` and `x/yErrAvgs` functions to `Scatter2D` Python.

### Removed

- Remove ALL uses of `@property` in the Python interfaces: all methods must have call-parentheses now.

### Changed

- Force rebuild of the Python interface if a sufficient Cython is found, even if the generated `.cpp` file is present at configure-time.
- Final conversion to use `ast` module not just in autotype but as first choice in `AO.annotation`.
- Improve Python annotation parsing to preferentially use `ast` rather than `yaml`.


## [1.7.7] - 2019-06-21

### Fixed

- Fix printing of YAML annotations.
- Fix Python 3 / Unicode compatibility for `Point.pyx`.


## [1.7.6] - 2019-06-07

### Added

- Add `xEdges` and `yEdges` methods to the 2D `Histo` and `Profile` classes, in C++ and Python.

### Removed

- Remove `@property` attributes from Python `xEdges` methods. More of that to come.

### Fixed

- Fix Python3/`argparse` attribute access bug in `yodamerge`.


## [1.7.5] - 2019-05-09

### Added

- Add `-m/-M` filtering to `yodadiff`.

### Fixed

- Fix `Histo1D::integralRange` to include the second-argument bin content as described in the docstring.
- Fix Python3 `StringIO` import compatibility -- thanks to Tom Neep for the patch!
- Fix `HistoBin2D` printing in Python interface.

### Changed

- Convert `bin/*` scripts to use Python3-compatible `argparse` rather than old `optparse`.
- Protect `yodamerge` against zero-valued (?!) `ScaledBy` attributes.


## [1.7.4] - 2018-12-10

### Added

- Add `sameBinning` methods for `Histo1D` and `Histo2D`.
- Add `--ignore-missing` and `--ignore-new` flags to `yodadiff`.

### Removed

- Remove debug `cout`s from single-AO `Writer::write()` function.

### Fixed

- Fix additional weighting in `yodamerge`

### Changed

- Roll out `sameBinning` methods for `Profile1D` and `Profile2D`.
- Tidy up point-comparison output of `yodadiff`.


## [1.7.3] - 2018-09-24

### Added

- Add array accessors of `x,y,zMins/Mids/Maxs/Vals/Errs`, etc. to Python `Histo2D` and `Profile2D`.

### Fixed

- Fix bug in multi-err point reader which was not parsing Variations correctly, and a minor typo where the err- was duplicated for the additional columns.
- Fix missing y and z components of `Point2D` and `Point3D` equality testing.

### Changed

- Update embedded yaml-cpp to v0.6.0.
- Convert `xyzMin/Max` properties to functions in the Python interfaces.
- Return numpy arrays if possible in Python interface array methods.


## [1.7.2] - 2018-08-23

### Added

- Add missing `bin(i)` method to Python Profile1D interface.

### Changed

- Avoid `const`-overloading clash for `binAt` functions.
- Merge Graeme Watt's modifications to `yodadiff`.


## [1.7.1] - 2018-08-14

### Added

- Add `-` = `stdin/stdout` recognition to C++ IO functions.

### Fixed

- Fix missing `lock=false` flag initialisation in `Histo2D` constructor from a `Bins` vector.

### Changed

- `yodadiff` now supports quiet (`-q`) and list (`-l`) modes.
- `Point1,2,3D` now support multiple error sources for the highest dimension.
- `Scatter1,2,3D` now read in/out with additional columns for the extra error sources, with a `variations()` method to check with sources are available
- `StringUtils.h`: Replace `std::ptr_fun` (removed in C++17) with a lambda function. Thanks to Stefan Richter.
- Convert remaining Python read/write methods to use the C++ IO functions.
- Convert Python read/write methods with filename arguments to use the gzip-aware IO functions.
- Improve axis-locking error messages.


## [1.7.0] - 2017-12-21

### Added

- Add Nentries printout to `yodals -v`
- Add YODA format version annotation, at version 2, and update YODA reader to use version info and multiline YAML EOF marker.
- Add `HistoBin2D::area()`, and provide a default `normto=1.0` argument on the Python `Histo2D.normalize()` method.
- Add an `UNSCALE` spec option to `yodascale`, to undo `ScaledBy` effects.
- Add optional zlib support via zstr -- massive thanks to Dmitry Kalinkin for the lovely patch!
- Add `annotationsDict` to the Python AO interface.
- Add AO as an alias for `AnalysisObject`.
- Add parallel/compatibility `yoda1` package to aid eventual transition to YODA v2.
- Add `x,y,zMins` and `Maxs` to all 1D data types and scatters (and `x,yMin/Max` to the scatters) -- Python interface only.
- Add convenience aliases `H1D`, `H2D`, `P1D`, `P2D`, and `S1D`, `S2D`, `S3D` for the `HistoXD`, `ProfileXD`, and `ScatterXD` classes respectively.
- Add `xyVals/Errs` and other 'bin array property' accessors to the Python `Histo1D` and `Profile1D` types: important for connection to matplotlib.

### Removed

- Remove `UNUSED` macro in favour of anonymous args.

### Fixed

- Fix `setVal(i, x)` numbered-axis methods on `Point2D` and `Point3D`: `switch` `break` statements were missing.

### Changed

- Patches for ROOT conversion from Robert Hatcher -- thanks!
- Write YODA annotations in YAML with a `---` YAML break-line.
- Enable compressed writing from Python.
- Enable zipped writing... but only works from C++ so far.
- Change license explicitly to GPLv3, cf. MCnet3 agreement.
- Parse YODA format AO headers as YAML (restriction to single-line dict entries for now).
- Use a slightly enhanced fast numeric parser in `ReaderYODA` (taken from LHAPDF, originally inspired by Gavin Salam).
- Explicitly load all ROOT objects as a list rather than generator. Patch from Dmitry Kalinkin.
- Improvements to `yodaplot`, including two operating modes: the default `CMP` mode is suitable for plotting histos by path, from raw `.yoda` files.
- Update `yoda.plotting` functions to treat plot-keys as args and AO annotations via case-insensitive keys.
- Rework some of the yoda.plotting tools, making it a bit more compatible with user-scripted matplotlib.
- Use Python `natsort` library to sort `yodals` output if available.


## [1.6.7] - 2017-06-18

### Added

- Add static Reader methods to match the Writer ones.

### Fixed

- Fix `Histo2D` and `Profile2D` total distribution reading from YODA format.

### Changed

- `pyext/yoda/rootcompat.pyx`: Fix ordering of `TH1` vs. `TProfile` conversion -- `TProfile` *is* a `TH1`, so we have to test for the more specific type-match first. Thanks to Dmitry Kalinkin for the patch.
- Convert `TH1F` to `TH1D` in `root2flat`. Much simpler than duplicating the `TH1D` stuff in `pyext`.


## [1.6.6] - 2016-12-13

### Fixed

- Fixed warning messages about the obsoleteness of AIDA so that the scripts actually still work.

### Changed

- Bugfixes in Cython bins accessors for `Histo2D`.


## [1.6.5] - 2016-09-28

### Fixed

- Fix handling of `--enable/disable-root` configure options.

### Changed

- Improvements to Cython version testing.


## [1.6.4] - 2016-09-25

### Removed

- Remove aliases for `@property` functions. They were scheduled for removal anyway, and don't work with Cython >= 24.

### Changed

- Update `configure` scripts to use newer (Py3-safe) Python testing macros.


## [1.6.3] - 2016-08-09

### Added

- Add 'add' modes for scatter combination to `yodamerge`.
- Add `--type-mismatch-mode` flag and fallback logic to `yodamerge`.
- Add a convenience `yoda2yoda` script.

### Removed

- Remove accidentally remaining reference to Boost flags in `yoda-config`.

### Fixed

- Fix `yodamerge` scatter averaging to use the first AO.
- Fix `yodamerge` logic to handle cases where an AO only appears once.

### Changed

- Deprecate `flat2yoda` script and add warning output to it and the AIDA conversion scripts.
- Try to build PyROOT interface by default, if `root-config` is found.


## [1.6.2] - 2016-07-06

### Changed

- Pass the `toNewScatter3D()` `scalebyarea` flag to the called `toScatter3D()` functions.
- Re-enable the disabled-for-some-reason `Scatter1D` `combineWith` Python mappings.


## [1.6.1] - 2016-04-28

### Added

- Add a unit test for annotation handling correctness.

### Fixed

- Fix numerical precision of string storage of floating-point attributes.
- Fix a bug in use of the replacement for `lexical_cast`.


## [1.6.0] - 2016-04-20

### Added

- Add a few consts to the arguments in `Scatter` error-setting via pairs.
- Add a `--guess-prefix` flag to `yoda-config`, cf. `fastjet-config`.

### Removed

- Remove Boost dependency and require C++11 compilation.

### Fixed

- Fix double-writing of minus errors in `WriterYODA` for `Scatter1D` and `Scatter3D`. Thanks to Graeme Watt for the report and fix.

### Changed

- Extend SFINAE craziness to allow writing of any object (e.g. smart pointer) that can be dereferenced to something that has AnalysisObject as its base class... and also to any container of them! Amazing what you can do with C++11!
- Change AO uncomputable division and `mkScatter` operations to return/set `NaN` rather than `0` -- behaviour change requires new major version series 1.6.


## [1.5.9] - 2016-03-09

### Added

- Add `abs` function to `eq` calculation in `yodadiff`.
- Add a `--add` option to `yodamerge`, for simple histo stacking. Thanks to Chris Gutschow for the patch, although my spidey sense is tingling...

### Removed

- Remove blocking of builds against ROOT6 -- it works fine.


## [1.5.8] - 2015-12-21

### Added

- Add a rebinning unit test, `pytest-rebin`.
- Add optional range arguments to rebinBy methods, allowing block rebinnings to be applied only within a range of (original) bin indices.
- Add missing `root.py` submodule file. Oops!
- Add `xEdges()` methods to `Axis1D` and the `Histo1D` and `Profile1D` that use it. The returned edge lists are finite only, i.e. they do not contain the `+-inf` values on the ends of the internal `BinSearcher` edges.

### Changed

- Convert `linspace` to use multiplication rather than repeated addition to construct edge values, reducing precision errors. Thanks to Holger Schulz for the suggestion.


## [1.5.7] - 2015-12-13

### Added

- Add a `match_aos` function to Python, for filtering AO `list`s/`dict`s on path patterns and anti-patterns.
- Add a flag to `yoda2root` to change whether the conversion is to 'proper' types or to (more robustly) `TGraphAsymmErrors` objects.
- Add a `rebinTo()` method on `Axis1D`, allowing rebinning to a new given set of bin edges. Add an explicitly named `rebinBy()`, and overloaded `rebin()` aliases for both, and pass through to `Histo1D` and `Profile1D` APIs. Plus other internal tweaks to binning functionality... anticipating/fuelling the fundamental rewrite.
- Add missing `addBins()` operators (only in C++ so far) to `Histo` and `Profile` classes.
- Add `yoda.HAS_ROOT_SUPPORT` flag, for API user convenience.

### Fixed

- Fix accidental use of `S2D_MODE` flag where `S1D_MODE` should have been used, in `yodamerge`. Thanks again to Radek Podskubka.
- Fix `Counter::numEntries` to return an `unsigned long` rather than `double`. Thanks to Radek Podskubka for the bug discovery and detective work.

### Changed

- Extend batch-adding in `ReaderYODA` to include `Scatter` types.
- Allow new `rebinTo()` merging to restrict to a subset of the bin range, merging the outside bins into the overflow distributions.
- Improve `ReaderYODA` to use temporary bin containers, to minimise calling `sort` when adding bins to histos. A quick test suggests this has sped up big file reading by a factor of 30 or so!!!
- Improve `sortedvector` to insert new elements into the sorted position, rather than resorting the whole vector. This should be a bit more efficient, but I think the asymptotic complexity is the same. Might help a bit with reading big data files.


## [1.5.6] - 2015-11-22

### Added

- Add `root2yoda` conversion script.
- Add `Point` base class with generic accessors to `Point*D` properties via an integer axis ID argument.

### Fixed

- Fix double-dealloc in new `Point` class hierarchy Python mapping.

### Changed

- Make AO path setting and retrieval prepend a leading slash if it is missing (unless the path is completely empty).
- Deprecating `yoda.to_root()` in favour of `yoda.root` module, which contains `to_root` and `to_yoda` functions, as well as a ROOT file-walking function.
- Map ROOT-to-YODA (as scatter) functions to Python. Phew.
- Map new to-ROOT functions, including `TGraph` ones, to Python.
- `ROOTCnv.h`: Add `toScatter3D` ROOT->YODA, and `toNew*` YODA->ROOT conversion routines.
- `ROOTCnv.h`: Fix bug in `toTH2D(const Histo2D& h)` as used with ROOT6. Thanks to Tim Martin.
- Make the `version()` function inline, and the numerical constants static.
- Change the default plotting backend to MPL rather than the much slower PGF.
- Reinstate `__getitem__`  special methods for `Scatter`s in Python.
- Provide `dim()` methods/attributes for the `Point` and `Bin` base classes.
- Rename `set*Err` to `set*Errs` for the asymmetric variants. Plural aliases are also provided for the symm case.
- Pass `std::pair`s by reference in `Point*D` error-setting functions.


## [1.5.5] - 2015-10-07

### Changed

- `Counter.pyx`: Typo fix in `sumW` mapping.
- `yodamerge`: Re-add checking for non-emptiness before merging, in case the empty ones are missing a `ScaledBy` attribute. Won't normally apply to `Profile`s, since they don't usually get normalised, but we might as well include them in the vetoing since empty histos don't contribute to the merging. Added a command-line option to disable this heuristic since in very strange situations a null `sumW` does not mean no fills.


## [1.5.4] - 2015-10-06

### Added

- Add a `YODA::version()` function, mapped into Python and used to set the `yoda.__version__` variable.

### Fixed

- Fix `yodals` to work with `Counter`s.

### Changed

- `ReaderYODA`: Typo fixes in `Counter` filling of `sumW` and `Scatter3D` reader state flag.
- `yodamerge`: add merging heuristics for `Scatter1D` and `Scatter3D` (needs unification)
- `yodamerge`: add a fix for empty-in-all-runs histo merging; thanks to Daniel Rauch.
- Adding `dim()` function and corresponding Python attribute to `AnalysisObject`.
- Map `Counter` arithmetic operations into Python.
- Map `Counter` `mkScatter()` into Python (as bound method).
- Expose the `yoda.plot()` Python function in a way that doesn't automatically induce a dependence on matplotlib.


## [1.5.3] - 2015-09-23

### Changed

- Update Boost version requirement to 1.48, due to use of `type_traits`/`has_dereference`, and add a check for that feature's header.
- Further improvements to handling leading _multiple_ `#` marks on YODA format `BEGIN` lines.


## [1.5.2] - 2015-09-11

### Fixed

- Fix shadowed variables that made `ReaderYODA` unhappy.

### Changed

- Tolerate leading `#` symbols without separating whitespace on `BEGIN` lines in YODA format parsing.
- Further improvements to handling `LowStatsErrors` in YODA format writing.


## [1.5.1] - 2015-09-03

### Fixed

- Fix bugs in Python wrapper for `Point3D`.

### Changed

- Catch `LowStatsError` when writing multiple histograms so only the histogram with the problem is not written


## [1.5.0] - 2015-08-28

### Added

- Add some protection against calling matplotlib's `legend()` method if there are no valid labels to display, to suppress an MPL warning message when using `yoda.plot()`.
- Add methods for `Counter`, `Axis` and `Histo1D` internal state access/setting, mainly for new persistency.
- Add SFINAE trait magic to restrict `write(RANGE)` functions to accepting iterables. Also generalising to allow either container-of-objects or container-of-pointers args by providing a `writeBody(AO*)` function to complement `writeBody(AO&)`. Based on a patch from Lukas Heinrich.
- Add configuration of output streams to throw exceptions on bad/fail state (based on patch from Lukas Heinrich).

### Removed

- Remove `#` markers from YODA format BEGIN/END output. The parser will continue to accept them.

### Fixed

- Fix cut & paste typo, and add `LowStatsError` catching in `Profile` division.

### Changed

- Improve protection of efficiency calculation against the weird world of general weighted events.
- Replace old Spirit-based `ReaderYODA` with the new hand-rolled one.
- Adding filling of `Histo1D`, `Profile1D`, `Histo2D` and `Profile2D` in new `ReaderYODA`. More hacking of `Axis` and `Histo`/`Profile` interfaces... needs clean-up, and infinite binning implementation.
- Convert the `ReaderFLAT` parser to also use a simple hand-written parser rather than Spirit.


## [1.4.0] - 2015-07-01

### Added

- Add Python mappings of all the methods below.
- Add full set of `{x,y}{Mean,Variance,StdDev,StdErr,RMS}` to 1D and 2D binned distributions.
- Add optional `includeoverflows=True` argument to all binned AO `numEntries` and `effNumEntries`.
- Add `binAt(x,y)` and `binIndexAt(iglobal)` Python methods for 2D histos. Still want a way to get and pass a pair of bin indices, I think.
- Add a regex pattern-match optional argument to the `IO.read()` Python functions, for pre-emptive filtering.
- Adding workaround versions of `binAt` to all the Python histo types -- for some reason the direct mapping that works for `bin(i)` produces a compile error for `binAt(x)` :-/
- Adding an `AnalysisObject::name()` method, to return the last part of the path. Mapped into a Python property.
- Adding an optional `usestddev` argument to `mkScatter` for profile types, so the error bars can represent distribution width rather than uncertainty on the mean. Mapped to Python.
- Adding unpatterns arguments to Python `read` functions, and auto-conversion from single strings and `re.compile()`d strs.
- Adding `includeoverflows` optional args for `Histo1D` `(eff)numEntries`.
- Adding missing `binAt` and `binIndexAt` methods to `Histo1D` and `Profile1D`, plus other minor Python mapping tweaks.

### Fixed

- Fix type of `numEntries` to always be `unsigned long`.
- Fix typos in `Point3D` Python mapping (accidentally trying to get the ptr via `_Point2D` rather than `_Point3D`).
- Fix a harmless possibility to raise an FPE exception in the `BinSearcher`. Thanks to Leif Lonnblad for the discovery, debug and patch!

### Changed

- More tweaks to `yodamerge`: adding control of `S2D` merging strategy, and now performing weighted normalized histo merges without reference to an absolute normalization.
- Change `yodamerge` norm-detection heuristic to just look for a `ScaledBy` attribute rather than fuzzily compare norms.
- Removing add, subtract, and divide functions and operators on `Scatter` types, and re-implementing `Histo` and `Profile` divide functions explicitly rather than via `mkScatter`. Also removed from the Python interface. The `combine()` methods remain.
- Renaming, tidying, completing, etc. the Python-mapped methods on `Bin1D` and `Bin2D`.
- Rename Python `Histo2D` mean, variance, etc. pair-returning methods to `xyMean`, `xyVariance`, etc., to distinguish from `Profile2D` `mean`, `variance`, etc.
- Rename `Histo1D` `integral()` methods as `integral()`, `integralRange()`, and `integralTo()`, and mapping to Python.


## [1.3.1] - 2015-03-19

### Added

- Add a `-i`/`--in-place` option pair on `yodascale`.
- Add convenience `YODA/YODA.h` header.
- Add match/unmatch args to all conversion scripts, via a new Python `yoda.script_helpers` function.
- Add a `yoda.plotting` sub-module, based on matplotlib.
- Add `std::` prefix to `isinf()` calls in `BinSearcher.h`.
- Adding `usefocus` optional argument to some `mkScatter` functions, plus the Python bindings.
- Adding matching options and verbose option to `yodals`.
- Adding `yoda.matcher` Python sub-package with `PointMatcher` functionality. To be used in Professor 2.0 and in yodascale.
- Adding `scat2` type to `yodahist`.

### Fixed

- Fix formatting and error handling in Python `Bin` and `Dbn` `__repr__` methods.

### Changed

- Cleaning up some Python mappings of 2D histogram bin classes.
- Removing mappings of bin-level fill and scale operations in Python.
- Convert script matching options to use `re` `search` rather than `match`.
- Improvements and additions to `ROOTCnv.h` routines, particularly to `TProfile` creation: thanks to Roman Lysak for advice.
- `yodascale` now uses `PointMatcher` and can normalize or multiply to abs values or ref histos/bin ranges.
- Script updates, improved docstrings, and improved tab completion.
- Small build improvements: cleaning `test1.root` from the `yoda2root` test, and adding a make target and flag file for `mktemplates` in `pyext/yoda` to make sure that it only gets run once.
- Handle overflow filling in binned types without invoking an exception.
- Change `inRange` to have non-fuzzy comparison behaviour.
- Improving/adding `__div__` functions in Python for all binned types.


## [1.3.0] - 2014-09-30

### Added

- Add an efficiency method for 2D histos.
- Adding `setX/Y/Z(val, err)` methods to `Point3D`.

### Changed

- Use `numEntries()` rather than `effNumEntries()` when checking consistency of inputs to `efficiency()` calculations -- the `effNumEntries` of a set can be smaller than that of a strict subset, surprisingly!
- Small improvements to `yodahist` and `yodaplot` behaviours/UIs.
- Hide `fill` and `fillBin` methods from Python mappings of bin types.


## [1.2.1] - 2014-09-01

### Added

- Add protection against `/` characters in histo names in `yoda2root` (thanks to Will Bell for the report and suggested patch).
- Add `+=`, `-=`, `*-`, `/=`, `++` and `--` operators to `Counter`, along with an (implicit) constructor from a double -- all for user convenience so `Counter` can be used in lieu of a simple number.

### Fixed

- Bug in `BinSearcher` fixed by Peter Richardson: constructor arguments were passed in the wrong order when constructing a `LinEstimator` in cases where log binning wouldn't be allowed.

### Changed

- Hide non-const access to bin objects from histogram users: avoids potential for inconsistency between total dbns and in-range bins.


## [1.2.0] - 2014-08-15

### Added

- Add unit tests for `Counter`, `Scatter1D`, and `Scatter2D`, including persistency.
- Add ROOT version checking to configure. Thanks to Michael Grosse for the report/request.
- Add `scaleX,Y,Z` and `scaleXYZ` to `Point` and `Scatter` classes, and deprecate less explicit/consistent `Scatter2D/3D.scale` method.
- Add first version of a `yodascale` script, based on code from Simone Amoroso.
- Add unit test checks for 1D and 2D `mkScatter` functions.
- Add `Scatter3D` Python mapping.
- Add auto-parsing of `yes/no/on/off/true/false` as bools in the Python `ao.annotation()` function.
- Add parsing of `yodaplot` styles from command line args and analysis object annotations.
- Add `yodaplot` script for basic plotting, using pgfplots as a backend.
- Add `mkScatter(Scatter2D)` and `mkScatter(Scatter3D)` functions and Python mappings: this allows all AOs to be used as args to `mkScatter(...)` without needing to check if they already are scatters.
- Add exception translation to the `mkScatter` functions.
- Add `-m`/`-M` match/unmatch options to yodacnv -- useful for filtering histogram file contents in a YODA->YODA conversion.

### Removed

- Remove all methods not specific about the axis to which they refer, e.g. `Histo1D::mean -> xMean`. Also remove all related aliases (a nightmare to maintain) and `low/highEdge` and `midpoint` functions: use the proper `xMin/Max/Mid` from now on. This is a significant compatibility breaking API change (and the decision was not taken lightly) so will require a 2nd digit version change.
- Remove `return *this` from `Scatter2D/3D` `add` and `combine` methods.

### Fixed

- Fix to `logspace`: make sure that start and end values are exact, not the result of `exp(log(x))`.
- Fix `Axis2D::reset`, which was resetting the total dbn and outflows, but not the bins!!! Thanks to Ewen Gillies for the report.
- Fix infinite recursions in Python wrappers for `Point2D` and `Point3D`, and make the Python `Point3D` interface more standard.
- Fix use of the install command for bash completion installation on Macs.

### Changed

- Permit `+-inf` values to be filled into histograms; `NaN` fills will still explicitly throw an exception.
- Adding `YODA` and `FLAT` format I/O for `Scatter1D` and `Counter` (as far as currently possible -- `FLAT` `Counter` can't be read due to a `#item` ambiguity, just like the one between the YODA format `Point3D` and `ProfileBin1D`). To be continued...
- Python mappings for `Dbn0D` and `Counter`, and other improvements.
- Adding `val()` and `err()` methods to `Counter`, and `errW()` and `relErrW()` to all `DbnXD` types.
- Adding `Scatter1D` and `Point1D` types, with conversion from `Counter` supported. Both `Counter` and `Scatter1D` still need to be supported by YODA persistency.
- Lots of adding `xMin/Max` etc. functions to C++ and Python bin/histo classes.
- Compiler pickiness fixes in `BinSearcher`.
- Improvement to `linspace`, avoiding `fuzzyEquals` and again making sure that the end value is exact.
- Clean-up, minor improvements, and adding a test for `BinSearcher` and friends.
- Various consistency improvements and minor bugfixes to Python mapping utils and `Dbn` and `Bin` objects.
- `yodascale` now writes out rescaled histograms and profiles rather than scatters.
- A few more improvements on `Point2D/3D`, adding `x,y,zMin/Max` function mappings.
- More `Scatter` and 2D histo interface improvement.
- Improve `Scatter2D/3D` C++ and Python interfaces.
- Set y value and/or error to `0` in `mkScatter(Histo1D)` if an exception is thrown when calculating the appropriate values. Need an optional param to control this error handling behaviour between set-zero and skip-bin?
- Don't complain about merge assumptions if there is only one object with that path name to be 'merged'
- Adding explicit `int` cast in Python wrapping of `numEntries` functions.
- Adding `yodals` script to list data file contents.
- `pyext/yoda/Makefile.am`: `make distcheck` and out-of-source builds should work now.


## [1.1.0] - 2014-06-06

### Fixed

- Fix silly typos in `yodamerge` which somehow made it past `make check` testing :-(

### Changed

- Adding unit tests against ref data for `yodamerge` in `make check`.


## [1.0.7] - 2014-06-02

### Added

- Add a single-file at a time `yodacnv` multi-format converter script (thanks to Andrii Verbytskyi for the suggestion).
- Add the `AnalysisObject::type()` method back in Python (even though `type(ao)` is more Pythonic, this may be useful)
- Add `Profile2D` YODA format writing, note need for `Scatter` format change, add `sumXY` storage to both 2D histo types.
- Add special case handling for 2-arg use of `x2y` scripts where the second arg is `-`, for `stdin`. This will be treated as writing out to `stdout`, not converting two files one of which is stdin.

### Changed

- Removing `foreach` macro definition and using raw `BOOST_FOREACH` instead until C++11 is allowed.
- Adding `pytest-p1d` and `pytest-p2d` tests, and `FLAT` writing/reading in `pytests`.
- Tweaking `WriterFLAT` and adding `ReaderFLAT` functionality for 2D histos and profiles.
- Some basic (`FLAT`) write-out capability for 2D histos
- Improvements to the `yodahist` script, including support for 2D histograms and input files.
- Adding bin edges constructors for all 1D and 2D histos in Python.
- Improvements to `Profile2D` and `Point2D` interfaces in Python.
- Typo fixes in `Profile2D` YODA-format parsing: 2D histo tests now pass!
- Adding Python tests for `Histo2D` and `Profile2D`.
- Adding a `YODA/Predicates.h` header and using it in `Axis2D` bin-edge construction.
- Enabling `Profile2D` writing in various `Writer`s, and a bit of IO code tidying.
- Disable writing out of `Histo2D` and `Profile2D` outflows for now, while they are redesigned, and get 2D I/O working for the in-range part.
- Mapping the divide and efficiency functions into the Python interface as class methods, including the `__div__` special function.
- Adding YODA reader functionality for `Histo2D` and `Profile2D`, but without outflows support yet.
- Adding simple command-line `yodahist` script for quick 1D histogramming from plain text files, with weight support. More development to come!
- Mapping `linspace`, `logspace` and a few stat functions into Python.
- Fixes, script installation, and detailed numerical comparisons in `yodadiff`.
- Change `AnalysisObject::annotations` to return the list of annotation keys rather than the map, since the previous behaviour mapped very badly into Python.
- Adding a more portable version of `getline` to be used in the YODA file-parsing to avoid falling over on DOS-produced input files.
- Adding the namespace protection workaround for Boost described at http://www.boost.org/doc/libs/1_55_0/doc/html/foreach.html
- Adding an assumed-equal-run-size, ratio-like merging heuristic for `Scatter2D`s to `yodamerge`, and renaming the `--normalize-all` flag to `--assume-normalized`.
- Adding and installing a `pkg-config` data file for YODA.
- Rationalising (and fixing?) the `yodamerge` logic re. user & normalization scalings, and making way for a `Scatter2D` merging heuristic.


## [1.0.6] - 2014-03-10

### Fixed

- Fix race condition with `mktemplates`.
- Fix bug in `mktemplates` code (thanks to Christian Johnson for the bug report).

### Changed

- Improvements to `AnalysisObject` annotation handling in Python.
- Adding rescaling arguments to `yodamerge` (and `scale` function to Python `Scatter2D`).
- Better documentation and consistency of `Histo` and `Profile` Python wrappers, and removing some inappropriate attributes.
- Adding `clone()` and `newclone()` functions to all analysis object classes.
- Cython mapping improvements, esp. adding `numPoints`/`numBins` functions and better `Scatter2D` `__repr__`.
- Adding mapping of the `mkScatter` functions into Python (as methods on `Histo1D` and `Profile1D` rather than the original free functions, at least for now: some Python type-identifying boilerplate is needed to make a single mkScatter function work in Python)
- Minor modifications to `BinSearcher` to avoid `NaN`s. The `NaN`s were treated correctly before, but better to avoid them all together.
- Adding the generated `pyext/yoda/rootcompat.cpp` to the tarball and sorting out the ROOT/Cython interface conditionals a bit more sanely. Thanks to Oldrich Kepka for the bug report.
- Protecting `yodamerge` against input histograms with zero integrals (thanks to Christian Bierlich for the bug report).
- Adding explicit include/generated dir creation to Python extension build (thanks to Christian Johnson for the bug report).


## [1.0.5] - 2014-02-06

### Fixed

- Fixed `yodamerge` default output file name treatment.
- Fix to build the Cython rootcompt extension `.cpp` on request.

### Changed

- Adding patches to `ReaderFLAT` and `ReaderYODA` use of Boost Spirit which reduce the Boost version requirement from 1.47 -> 1.41. Thanks to Andrii Verbytskyi for the patch.
- Protect against invalid prefix value if the `--prefix` configure option is unused.
- Adding copy assignment operators where missing, based on an implementation in `AnalysisObject` which only copies rvalue paths and titles if they are non-null.
- Improving (i.e. increasing) bin edge overlap tolerance: `1e-10` relative was too tight.
- Adding `x/yMid` etc. methods on Bin1D and 2D, and more related Python API improvements.
- Adding missing `fillBin` methods to 1D and 2D `Histo`/`Profile` Python classes.
- Avoid computing an unrecoverable error in `Histo1D.__repr__`
- Clean-ups and API improvements in Python IO functions.
- Adding more `sumW,W2` and `(eff)NumEntries` attrs to Python objects.
- Improved argument handling for `x2y` scripts.
- Adding flags for the C++11 or C++0x standard if supported, cf. Rivet.


## [1.0.4] - 2013-10-24

### Removed

- Remove `Scatter`s from being handled by `yodamerge` by blocking the `__add__` method fallback.

### Changed

- Supporting zsh completion via bash completion compatibility.
- Removing unused internal iterator typedefs from `Writer` functions.
- Adding a `yodaenv.sh` sourceable script to help with environment setup.
- Improvements to `yoda-config` and command-line completion, for the Rivet 2.0.0 release.


## [1.0.3] - 2013-10-09

### Added

- Add the `-avoid-version` flag to libtool.

### Changed

- Cython mapping improvements.
- Adding some improved heuristics and a `--normalize-all` option to yodamerge. Frank S is now happy again ;-)
- Adding operator `+`, `-`, `+=`, `-=` Python mappings wherever possible for `Histo1/2D`, `Profile1/2D`, and `Scatter2D`.
- Cython is no longer needed by tarball users.
- Unset path of returned histogram if those of the args to `add()` and `subtract()` are difference.
- Python mapping improvements.
- Adding more add and subtract special methods in Python.
- `mkScatter` changed to use histo midpoints rather than focuses by default for the point x value.


## [1.0.2] - 2013-08-14

### Changed

- Some exception message improvements and improving the protection of cosmetic mean calculations in `WriterYODA`.
- Adding ROOT detection in `configure` and otherwise updating Dave's `rootcompat` module so that it'll compile. There might be an inconvenient ROOT version dependency in the signature of one of the PyROOT API functions that is used as a shim :-(
- Adding `yoda.m4` from James Robinson.
- Improve `==` operator in `Axis1D` and `Axis2D`.
- Adding `fillBin()` methods to all 1D and 2D histos, and noting that Bin types need a back-link to their axis to maintain consistency.


## [1.0.1] - 2013-06-06

### Changed

- Change the `divide(Scatter, Scatter)` behaviours to use the midpoint of the num/denom bins rather than mean of foci for the output point position (and hence errors, too).
- Adding a `toIntegralEfficiencyHisto` function.
- Adding another `Histo1D::integral()` function, this time from 0 -> i, maybe including the underflow.
- Updating the Cython version requirement to 0.18
- Adding `relErr` functions to 1D and 2D histo and profile bins, and being careful about div by zero.
- Improvements in error treatment in division (better handling of zeros).
- Renaming `merge-histos` to `yodamerge` and installing it (and improving the usage string a bit).
- Adding the `Counter` type, and ability to output it from the YODA writer.
- Adding `numEntries` and `effNumEntries` methods to 1D and 2D `Histo` and `Profile` classes.
- Adding `Dbn0D` and using it to implement `Dbn1D`.
- Fixing several nasty errors in argument ordering for `Point{1,2,3}D` construction in `Scatter` `addPoint` functions.
- Adding `abs(...)` to the returned `Dbn1D::variance()`, to avoid problems when negative weights produce negative variance. No, we don't like this either: is there a more correct way?
- Fixing the `efficiency(Histo1D, Histo1D)` implementation, cf. http://root.cern.ch/phpBB3/viewtopic.php?t=3753
- Adding `mkScatter(Profile2D)`
- Adding a reader for `FLAT` files and a `flat2yoda` converter
- Adding a `yoda-completion` file for bash.
- Mapping `HistoBin1D.relErr` in Python.
- Adding a non-const `points()` accessor to `Scatter2D`.
- Adding combined value+error `setX/Y` functions on `Point2D`.
- Adding `HistoBin1D::relErr()`.
- Adding Python output handling for single AOs and to be able to use a `-` filename to mean `stdout`.


## [1.0.0] - 2013-04-12

### Changed

- Releasing version 1.0.0 -- it seems stable enough.
- Being more careful about adding `-Wno-*` flags to the C++ compiler used to built the Cython extension lib.
- Removing the use of `svn:external` to pull in Boost macros and using a minimal local set instead.
- Using the nice Boost-finding macros from https://github.com/tsuna/boost.m4 and tidying up configure.ac
- Re-organising the C++ side of the auto-format I/O functions, into a new IO header and separated from the `Reader.h` and `Writer.h`. I'm tempted to say that users shouldn't really NEED to ever directly touch the `Reader` and `Writer` objects...


## [0.16] - 2013-03-15

### Added

- Added a `Histo1D::integral(index1, index2)` method. Not sure how or if to extend this to `Profile1D`.
- Add `Profile1D` and `Scatter2D` division operators.
- Add `xMin`/`xMax` synonyms to the `Axis1D`, cf. the bins.
- Add a first stab at a `Histo1D`/`Histo1D` division operator.
- Add construction of `Histo1D`s from `Profile1D` and `Histo1D`, and construction of `Profile1D`s from those and `Scatter2D`.
- Add construction of a `Histo1D` from `Scatter2D`.
- Added many vector constructors and `addPoint` functions to `Scatter2D`.
- Add `lexical_cast` support to annotation `get` and `set` functions.
- Add Boost checks and header includes. Not used yet.
- Added `AnnotationError`.
- Added some more test programs... working towards a proper test suite.
- Added "no path & title" constructors - you don't always want to write out the histo, since sometimes it's just a good way to gather statistics.
- Added `Dbn1D` class to centralise the calculation of statistics from unbounded, unbinned, weighted distributions.
- Added `Profile1D` class.
- Adding auto-format read and write functions. I will probably change the API. Python mappings have been provided, but the string workarounds were too much of a pain with Cython 0.16 so I have updated the Cython version requirement to 0.17 where it is automatic and hence much cleaner.
- Adding `Plot` mapping to Cython and improving the AO annotations handling in Python.
- Adding `PLOT` section writing to `WriterFLAT` (and `WriterYODA`, although that might be a bad idea...)
- Adding `aida2yoda` and `aida2flat` converter scripts.
- Adding support for Python >= 2.4 (was Python >= 2.6)
- Adding a `points()` method to the Python `Scatter2D` wrapper.
- Adding a virtual destructor to `Bin`.
- Adding support for `Boost.Range` arguments and file format autodetection in `Writer`.
- Adding more ROOT converters. Who knows how to make `TProfiles` from scratch, but `Histo1D` and `Scatter2D` are covered, which should be enough to get started with, at least.
- Adding `yoda-config`
- Adding `WriterFLAT` and `yoda2flat`
- Adding `YODA/ROOTCnv.h`. for data object converter functions. Two (untested) functions added for TH1 -> YODA.
- Adding `toIntegralHisto(Histo1D&)` function.
- Adding Cython mappings for `Dbn3D` and `Profile2D`, and other fixes/improvements.
- Adding Cython mappings for `Scatter3D` and `ProfileBin2D`.
- Adding `stdErr` for `Histo2D` + Python mapping, and more Cython improvements.
- Adding path/title-only AO constructors and making nice Python constructor for `Histo2D`.
- Adding axis locking to `Axis2D`.
- Adding nice constructor behaviours to the `Histo1D` and `Profile2D` Python interfaces, and adding the `mkScatter` operation for `Profile1D`.
- Adding more default constructors for analysis objects, to allow member variable and STL container use without pointers.
- Adding a `Utils::ndarray` object and using it to implement a general `Scatter<N>` system, with generalised `Point<N>` and `Error<N>` to boot.
- Adding `totalDbn()` accessors to data types.
- Adding annotation-fetching methods with a default return value argument to `AnalysisObject`.
- Adding `normalize()` methods to `Histo1D/2D`.
- Adding weighted RMS calculating methods to `Dbn1D`, `Dbn2D` and `Bin1D/2D`.
- Adding rebinning interface to `Histo1D` and `Profile1D`, and adding a test (and a new test feature for output message formatting)
- Adding first implementation of 1D bin merging to `Axis1D`.
- Adding copy constructors and assignment operators to `Histo1D`, `Profile1D`, and `Scatter2D`, and their respective bins/points.
- Adding proper Doxygen structures and full descriptive comments to `Dbn2D`.
- Adding the persistency state-setting constructors for `Profile1D` and `Dbn2D`.
- Adding tests to check that implicit construction of `Weights` objects from literal `double`s and `int`s works.
- Adding a `Weights` class, designed to seamlessly replace double-type weights and weighted moments with a named and vectorised form.
- Adding `addAnnotation`, and mapping annotations to Python.
- Adding tests of collection and iterator range AO writing.
- Adding static write functions on `Writer*.h` implementations to avoid needing to make an explicit `Writer` object via the `create()` functions.
- Adding persistency system hooks, since RTTI just sucks too much.
- Adding another candidate object for the axis bin container: a sorted extension to STL `std::vector` with an insert method. This will do as a development placeholder: a proper sorted & indexed container may be substituted later.
- Adding indexed set for holding bins on axes. Still not sure it's what we want, as (I just realised) STL sets are iterator-immutable because they are self-keyed and changes to elements would also change their sorting.

### Removed

- Remove use of `sign(weight)` in filling `sum(w2)` -- I think this was an historical attempt based on a scaling axiom which turned out to be inappropriate.
- Removed several old and unused files such as `Tree.h`
- Removing `Plot` entirely from YODA: it was an anomaly only added to make plot file generation easy, but this is now done better via `StringIO` (in new compare-histos/rivet-cmphistos).
- Removing the `Plot` from Cython... and soon from YODA itself: we'll do this stuff manually and less hackily.
- Removing unused (beyond 2nd order) `sumWXYZ` counter from `Dbn3D`.
- Temporarily removed `Histo2D`, `Profile2D` and `Scatter3D` mappings.

### Fixed

- Fixed `ReaderAIDA`: x-value and low y-error interchanged when filling `Scatter2D`.
- Fixed Python tests by installing Python extension to `pyext/build`
- Fixed `Axis`, `Histo1D` and `Profile1D` constructors, by adding a path argument, passing the path and title args to the `AnalysisObject` base constructor properly.
- Fix test code: titles are no longer given as histogram constructor arguments.
- Fixed YODA mapping to allow use of vectors of bins as Python lists.
- Fixed `Dbn1D` to use `sign(weight)` as part of the `w**2` measure, so that negative weights behave themselves.
- Fixed `NaN` errors from zero weights.
- Fixing miscellaneous warnings on GCC 4.1.
- Fixing more crap code legacy from old 2D plot implementation, this time in `Scatter3D`.
- Fixing for C++ change in behaviour of `std::make_pair`.

### Changed

- Making the `x2y` converter scripts write a copy into the *current* directory if only the input is specified.
- Make Cython automatically add a copy of the original call signature to each function's docstring.
- Committed numerous changes to `Axis2D`. `Axis2D` now uses `BinSearcher` as with `Axis1D`.
- Improving division and efficiency treatments, and allowing arbitrary $f(x)$, $f(y)$, and flip transformations on `Scatter2D`.
- Converting `linspace`, `logspace`, and their usage to place the `nbins` argument first.
- Converted `Axis1D` to use new `Utils/BinSearcher`.
- Heavily refactored Cython bindings
- `HistoBin1D`, `ProfileBin1D` etc. now inherit from `Bin1D[DBN]`
- Installing scripts from `bin` dir, and making the `yoda2aida` interface nicer.
- Cython mapping improvements & additions for `Point3D` + `Scatter3D`.
- Removing mixed symm/asymm constructors on `Point*D` & `Scatter*D` classes.
- Reintroducing `Profile2D` and `Scatter3D`.
- Supporting `Histo2D` in `WriterYODA`.
- More incremental progress toward a working 2D bin hash mechanism.
- A much simplified and more robust rewrite of the `Axis1D` class, just using STL map in place of the hand-written bin edge caching.
- Improvements (I hope) to the binary search in `Axis1D`, and providing an experimental default constructor for `Histo1D`.
- `ReaderYODA` can now parse `Histo1D` and `Profile1D` flat files
- Mapping the `Dbn1D` and `Dbn2D` classes into Python.
- Adding an `outflows()` accessor to `Histo2D`.
- Writing out total dbn lines for `Histo1D` and `Profile1D` in the YODA format, and now writing out the 'cross-terms' for `Profile1D`, too.
- Properly adding `Dbn1D` accessors for `Histo1D`.
- Updating the Cython mappings to provide the `totalDbn()` methods and add a placeholder mapping for `Dbn2D`. Completed mappings are needed for `Dbn{1,2,3}D` and the `Profile` types.
- Making `Histo1D/2D::scaleW()` write a `ScaledBy` annotation.
- Changed to Cython for Python bindings: SWIG bindings were in need of serious amounts of work. Cython should provide a means to provide more Pythonic bindings to YODA. A minimal subset of `ReaderAIDA`, `Scatter2D` and `Point2D` have been wrapped.
- Modified `configure.ac`, `Makefile.am` and `pyext/Makefile.am` to reflect change to Cython. Added `cython.m4` from python-efl (Part of the enlightenment project; LGPL)
- Reworking the `Bin1D` inheritance and composition design so that all bin types store a single distribution object -- a `Dbn1D` for histo bins and a `Dbn2D` for profile bins.
- Removing the `Profile1D` -> `ProfileBin1D` friendship. This is very heartening -- the fewer friend declarations we need, the more indication that the class structure is not pathological! (Or that we've just made everything public... but we haven't)
- Inlining all functions in `HistoBin1D`, `ProfileBin1D`, and `HistoBin2D`.
- Converting `Dbn2D` to be composed of two `Dbn1Ds` and a cross-term. Also tidying the interfaces of the 2D classes and the `scaleX/Y` methods throughout, and adding Doxygen comments.
- Inlining lots of methods on `Dbn1D`. Same should be done for `Dbn2D`, but first it needs to be reimplemented in terms of two `Dbn1D`s + the cross-term.
- Various typo fixes and comments relating to persistency constructors, Histo2D slicing, etc.
- Changing the `HistoBin1D` state-setting constructors (aargh, these should *not* have already existed) to take `Dbn1D` as an argument rather than a long list of `double`s.
- Bumping version number to 0.4.0beta0 -- there have been substantial changes recently and YODA is now in a state where it should be interesting for outsiders to start playing with it.
- Templating the `Axis1D` on the distribution type to be used for total and under/overflow statistics: `Profile1D` now has `Dbn2D` objects handling its total and overflow statistics.
- Implementing incomplete `Scatter2D` `operator+` and `operator-` functions.
- Making the AIDA reader work, including reading of annotations and a few tweaks to the simple type persistency system. `Testhisto1b` updated.
- Removing `Histo1D::area`.
- Filling and using under/overflow and total dbn on `Histo1D`, and adding boolean arg to `integral`, `sumW`, etc.
- Use `distutils` rather than `setuptools` for the Python interface build.
- Renaming `Bin`, `HistoBin` and `ProfileBin` to be `Bin1D`, `HistoBin1D`, `ProfileBin1D`. `Bin` is now a top-level abstract class with minimal functionality to be shared between 1D and 2D bins.
- Type annotations in `mkScatter`
- Write out annotations in AIDA format, and copy annotations in `mkScatter` -- using a new `AnalysisObject::setAnnotations` method.
- Convert DPS output to use interim `Scatter` construction
- Make (unused) `yoda.plot` subpackage.
- Write out annotations in YODA format.
- Make `Scatter2D` representations of Histo1D and Profile1D.
- Write out `Scatter2D` objects in AIDA and YODA formats.
- Make `Scatter2D` and `Point2D` work. Add a few extra methods... evolution and tweaking required.
- Hide `Utils::` content from Doxygen and `nvector` -> `Utils::nvector`.
- Removing unused YAML stuff: we aren't going that way for persistency anymore.
- Renaming `Axis` -> `Axis1D`
- Removing dead-end templated Scatter stuff.
- Move (generated) config files into the `Config` subdir.
- Move `sortedvector` and `indexedset` into the `Utils` dir.
- Move the `utils` directory and namespace to `Utils`.
- Put the `Doxyfile` under configure control by moving it to `Doxyfile.in` and using the `@PACKAGE_VERSION@` token.
- Make Doxygen find the `.icc` file and hide functions with name `_*` and in the YAML namespace.
- Removing the `Binning` argument and enum in favour of explicit bin edge vectors, possibly produced explicitly via the `MathUtils` `linspace` and `logspace` functions, or the new `Axis::mkBinEdgesLin/Log` alias functions.
- Updating copyright comments to be valid into 2011.
- Persistency fixes, and changing the interface to use the annotated path.
- Using annotations for path and title.
- Rename `Exception.h` -> `Exceptions.h`.
- Re-enable persistency of collections with begin/end iterators.
- Enabling quiet compilation.
- More annotation functionality.
- Sorting out autoheaders to be more useful.
- Rewriting AIDA writer to use DPS representation (no reloading) for `Histo1D` and `Profile1D` objects.
- Renaming test files to have more meaningful names.
- Some tweaks to `Axis`, `Bin`, etc. to use the `sortedvector`. Seems to be working! (I must be checking it wrongly...)
- Restarting `ChangeLog` contributions! Many changes in the huge time since last update... activity on YODA has renewed and we have a better picture of the distinctive features we require. New idea: named weight vector filling, allowing "parallel" histograms for various event weight variations. I/O remains an awkward issue, especially since the classes are now much richer than they used to be, and don't know about paths. Output can be easily put on top: not an issue... and we can probably do something with pickling. But reading in from C++?
- Moved duplicate `Histo1D`/`Profile1D` code on to `Axis`, making `Axis` a templated class at the same time.
- Started work on a little plotting tool, initially for Herwig++ partonic pT-cut testing, but incrementally enhancing it to be a command-line quick plotter seems like a good idea.
- Python SWIG interface now compiles and can be used: the subtlety that was breaking it was that SWIG has to be prodded in pretty non-obvious ways to make `std::vector`s of classes without default (no-arg) constructors. See http://osdir.com/ml/programming.swig/2004-04/msg00011.html for about the only reference to this to be found anywhere!
