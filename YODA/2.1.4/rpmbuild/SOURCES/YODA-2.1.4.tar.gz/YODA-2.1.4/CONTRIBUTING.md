Contributing to YODA
--------------------

Thank you for your interest in contributing to YODA! :tada:
We welcome bug reports, documentation improvements,
performance enhancements, and new features.

YODA is widely used in particle physics analysis workflows,
so changes require careful review for correctness,
API stability, and performance.

This guide explains how to prepare contributions that are
easy to review and likely to be merged.


[ToC]


## Do your social work before your coding work

Before implementing a new feature or large refactor:
* Open an issue describing the proposed change
* Or start a discussion (if appropriate)
* Or raise it in a developer meeting (for architectural changes)

Why?
* YODA has long-term API and file-format stability requirements
* Some features may overlap with ongoing work
* We may suggest alternative designs early
* It avoids wasted implementation effort

### Rule of thumb

If your change affects public headers, file formats, core types,
or performance-critical code -> discuss first.


## Scope your merge request carefully

Smaller MRs are much easier to review.

Good MR:
* One feature
* One refactor
* One bugfix
* One performance improvement

Hard-to-review MR:
* "Cleanup + new feature + refactor + style fixes"
* 3000 lines touching 20 files without explanation

If necessary, split into:
* MR 1: mechanical refactor
* MR 2: behavioural change
* MR 3: new feature


## Using AI tools

We recognise that LLMs and other AI-assisted tools can be useful for
software development and communication. We do not prohibit their use,
but **using an AI tool does not transfer responsibility for its output
to the maintainers**.

Whether you are opening an issue, proposing a feature, commenting on
an existing discussion, or submitting a pull request, please review and
verify AI-generated content before submitting it.

In particular:

* **Issues and feature requests:** Make sure that the problem you are
  reporting actually exists and that the proposed feature addresses
  a real need. Do not present an LLM's speculation, assumptions or
  invented details as facts.
* **Comments and discussions:** Please avoid submitting lengthy
  AI-generated commentary that has not been checked for accuracy
  or relevance. More text is not necessarily more useful.
* **Pull requests:** Review and understand generated code before
  submitting it. Check its correctness, assumptions, API usage,
  tests and performance, and remove unnecessary or speculative changes.
* **Documentation:** Verify technical claims, examples and references
  rather than assuming that generated text is accurate.
* **In all cases:** You should be able to explain and stand behind
  the content you submit.

The goal is not to discourage the use of AI tools. They can be useful assistants,
but they should assist your work rather than replace your understanding of it.
**Do your thinking before asking someone else to do your thinking.**

Maintainers should not be expected to act as the fact-checking,
debugging or editing stage for unreviewed AI-generated content.
Contributions that contain substantial amounts of unverified or
irrelevant generated content may therefore be returned to the
contributor or closed without detailed review.


## Use commit structure for storytelling

Your commits should tell the story of your change.

Good pattern:
1. Add failing test
2. Implement fix
3. Refactor for clarity
4. Update documentation

Avoid:
* One giant "misc changes" commit
* Fixup commits left in history
* Mixing whitespace reformatting with logic changes

Before submitting, rebase changes onto the head
of the target branch.

Clean up commit history where appropriate.


## Write a high-quality MR description

Your MR description should include:

### What

What does this change do?

### Why

Why is this change needed?
* Bug fix?
* Performance bottleneck?
* API consistency?
* Python binding gap?

### How

High-level description of implementation approach.

### Impact

* API change?
* File format change?
* Performance impact?
* Affects Python bindings?


### Open questions

Flag areas where you'd like feedback.

> If reviewers must reverse-engineer your intent from the diff,
the MR will take much longer to merge.

## Tests are not optional

All behavioural changes must include tests.
* Add unit tests for new functionality
* Add regression tests for bug fixes
* Ensure existing tests pass
* Ensure no unintended statistical changes

If your change affects numerical behaviour, document:
* Expected differences
* Justification
* Statistical tolerances

## Performance matters

YODA is used inside event loops over millions of events.

For changes in:
* Histogram filling
* Bin lookup
* Arithmetic operations
* Python bindings

Please:
* Include benchmark results (before/after)
* Explain complexity changes
* Avoid unnecessary allocations
* Be mindful of cache behaviour

If unsure: ask before implementing.

## API stability and backward compatibility

YODA prioritises API stability.

If your change:
* Modifies public headers
* Changes semantics
* Deprecates functions

You must:
* Propose deprecation strategy
* Preserve backwards compatibility where feasible
* Update documentation

Breaking changes require discussion before implementation.


## Python bindings

If modifying templated C++ types or public interfaces:
* Check whether Python bindings need updates
* Update Cython bindings where relevant
* Ensure Python tests pass

Do not assume C++-only changes are Python-neutral.


## Formatting and Style
* Follow existing style in surrounding code
* Avoid drive-by reformatting
* Do not mix style-only changes with behavioural changes


## Self-review checklist (before submitting)

Before opening a MR, ask:
* Have I discussed this change if required?
* Is the MR scope minimal?
* Are commits logically structured?
* Are tests included?
* Does CI pass?
* Have I documented performance impact?
* Have I updated documentation?
* Have I explained why, not just what?

If you wouldn't enjoy reviewing your own MR, reviewers won't either.


## What maintainers may do

Maintainers may:
* Request splitting large MRs
* Ask for additional tests
* Request performance measurements
* Suggest alternative designs
* Close MRs that do not follow guidelines

This is not personal - it is about maintaining long-term quality and sustainability.


## First-time contributors

We especially welcome:
* Documentation improvements
* Test coverage extensions
* Small bug fixes
* Example notebooks or usage demos

If you're unsure where to start, open an issue and ask.

