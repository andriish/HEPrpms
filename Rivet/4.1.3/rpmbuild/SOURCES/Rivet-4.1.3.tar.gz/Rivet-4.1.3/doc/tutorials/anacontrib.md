# How to contribute a routine

Contributing a Rivet routine of your (or any "missing") analysis is an
incredibly valuable contribution to the HEP community. And boosts citation
rates and recognition, too! Thanks for even thinking about it... and if
you need any help with the implementation, please see the various other
tutorial pages, and contact the Rivet support team if you need more.

This page covers the process and requirements for getting your code
added to the official analysis collection, in which case we will manage
all code and (meta)data updates in future.


## Making a merge request or issue

New analyses should all be contributed via a Gitlab merge request
(MR), targetted at the (usually latest) `release-*` branch. Validation
data should be included in the MR submission -- see below for more
detail on this.

This uniform process means that the MRs are a valuable future
reference for how an analysis was checked and how it was behaving at
the time of submission, in case issues arise later.

We are in the process of streamlining the routine contribution
procedure using an MR template as well as a dedicated CI pipeline. In
the meantime, feel free to make a [merge
request](https://gitlab.com/hepcedar/rivet/-/merge_requests) from your
own repo fork (if you know where the relevant files should go) or open
an issue on our [issue
tracker](https://gitlab.com/hepcedar/rivet/-/issues) so we can discuss
and guide you through it.


## Analysis-submission checklist

Here is some advice and requirements, to help the MR process go smoothly:

1.  Make sure the reference data file is fully in sync with what's on
    [HEPData](https://www.hepdata.net/).

2.  Please provide all of the routine's `*.cc`, `*.plot` and `*.info` files,
    and make sure the resulting plots are well formatted. These will
    go into the relevant `analyses/pluginEXPERIMENT`directory.

3.  Don't override fonts, colours, etc. in your submitted plot file:
    keep that for your own papers, we need all the "managed/official"
    analyses to follow the default styling.

3.  Please provide the `yoda` file(s) used to produce the validation plots.
    Please also add key validation plot PNGs directly in the MR text, for
    review convenience. You can also attach the tarred/zipped `rivet-plots`
    directory if you wish, but we can reproduce this from the yoda file.

4.  Additionally, please identify a suitable sample in our
    [suite of HepMC validation files](https://rivetval.web.cern.ch/rivetval/HEPMC/),
    and specify its name in the info file e.g. like
    ```
    ReleaseTests:
     - $A LHC-13-Top-L
    ```
    and provide the output `yoda` file. Note that these files only have 1000
    events and are mainly used for numerical regression tests: they are not
    expected to be good representations of the physics! Your validation should
    generally use much bigger samples. If there is not yet a suitable regression
    sample, please make a 1000-event version of your validation process and
    we will add it to the collection.

Thank you!!
