import yoda

def patch(path, ao):
    newao = yoda.BinnedEstimate1D(["Exclusive"], path, ao.title())
    newao.setAnnotation('IsRef', 1)
    newao.bin(1).setVal(ao.bin(2).val())
    newao.bin(1).setErr(ao.bin(2).err())
    return newao
