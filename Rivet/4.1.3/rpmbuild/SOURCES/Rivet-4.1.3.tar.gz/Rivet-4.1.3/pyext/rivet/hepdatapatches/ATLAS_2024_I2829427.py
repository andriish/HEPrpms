import yoda, math

def patch(path, ao):
    if "ATLAS_2024_I2829427" not in path:
        return ao
    if "d02-x01-y01" not in path and "d03-x01-y01" not in path:
        return ao
    # decompose 3D hist into many 1D histos
    out = [ ao ]
    N = [ ao.numBinsX(), ao.numBinsY(), ao.numBinsZ() ]
    edges = [ ao.xEdges(), ao.yEdges(), ao.zEdges() ]
    widths = [ ao.xWidths(), ao.yWidths(), ao.zWidths() ]
    newid = 200 if 'd03' in path else 500
    for idx in [ 0, 1, 2 ]:
        for i0 in range(1, N[idx]+1):
            for i1 in range(1, N[(idx+1) % 3]+1):
                aoname = path.replace('d02', f'd{newid}').replace('d03', f'd{newid}')
                out.append( yoda.BinnedEstimate1D(edges[(idx+2) % 3], aoname) )
                nonnan = 0
                for i2 in range(1, N[(idx+2) % 3]+1):
                    pos = [ i0, i1, i2 ]
                    b = ao.bin(pos[-idx], pos[1-idx], pos[2-idx])
                    if not math.isnan(b.val()):
                        nonnan += 1
                    out[-1].set(i2, b)
                    vol = widths[0][pos[-idx]-1]*widths[1][pos[1-idx]-1]*widths[2][pos[2-idx]-1]
                    out[-1].bin(i2).scale(1.0/vol)
                if nonnan < 3: # Veto!
                    out.pop()
                newid += 1
    if 'd03' not in path:
        newid = 100
        for idx in [ 0, 1 ]:
            for i1 in range(1, N[idx+1]+1):
                aoname = path.replace('d02', f'd{newid}').replace('d03', f'd{newid}')
                out.append( yoda.BinnedEstimate1D(edges[2-idx], aoname) )
                for i2 in range(1, N[2-idx]+1):
                    est = yoda.Estimate()
                    for i0 in range(1, N[0]+1):
                        pos = [i1, i2]
                        b = ao.bin(i0, pos[idx], pos[1-idx])
                        if math.isnan(b.val()):  continue
                        if math.isnan(est.val()):
                            est.set(b.val(), b.totalErr())
                        else:
                            toAdd = yoda.Estimate()
                            toAdd.set(b.val(), b.totalErr())
                            est += toAdd
                    # divide by bin volume
                    est.scale(1.0/(widths[idx+1][i1-1]*widths[2-idx][i2-1]*(edges[0][-1] - edges[0][0])))
                    out[-1].set(i2, est)
                newid += 1
    return out
