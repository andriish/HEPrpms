import yoda

def patch(path, ao):
    if 'CMS_2025_I2905870/d01-x01-y01' not in path:
        return ao
    newao = yoda.Estimate0D(path.replace('d01', 'd07'))
    newao.setAnnotation('IsRef', 1)
    newao.setVal(5.480000e+00)
    newao.setErr(1.110000e+00)
    return [newao, ao]
