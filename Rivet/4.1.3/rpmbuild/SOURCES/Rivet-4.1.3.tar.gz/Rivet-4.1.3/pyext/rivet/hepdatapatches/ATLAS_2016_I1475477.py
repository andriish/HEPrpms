import yoda

def patch(path, ao):
    if "ATLAS_2016_I1475477/d05-x01-y01" in path:
        # We undo the extrapolation to full phase space using the
        # acceptance A and efficiency \epsilon from the paper,
        # c.f. second paragraph in subsection 10.1.1 in the 1607.03745
        A = 0.280
        eps = 0.37
        dissociative = 3.3
        sf = dissociative / A / eps
        ao.scale(1.0/sf)
    return ao
