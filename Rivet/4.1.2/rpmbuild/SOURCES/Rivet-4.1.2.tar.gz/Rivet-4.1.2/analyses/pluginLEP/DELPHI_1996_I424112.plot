# BEGIN PLOT /DELPHI_1996_I424112/d01-x01-y01
Title=In-plane $p_\perp$ in GeV w.r.t. thrust axes
XLabel=$p_\perp^\mathrm{in}$ / GeV
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{p_\perp^\mathrm{in}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d02-x01-y01
Title=Out-of-plane $p_\perp$ in GeV w.r.t. thrust axes
XLabel=$p_\perp^\mathrm{out}$ / GeV
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{p_\perp^\mathrm{out}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d03-x01-y01
Title=In-plane $p_\perp$ in GeV w.r.t. sphericity axes
XLabel=$p_\perp^\mathrm{in}$ / GeV
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{p_\perp^\mathrm{in}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d04-x01-y01
Title=Out-of-plane $p_\perp$ in GeV w.r.t. sphericity axes
XLabel=$p_\perp^\mathrm{out}$ / GeV
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{p_\perp^\mathrm{out}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d05-x01-y01
Title=Rapidity w.r.t. thrust axes, $y_T$
XLabel=$y_T$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{y_T}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d06-x01-y01
Title=Rapidity w.r.t. sphericity axes, $y_S$
XLabel=$y_S$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{y_S}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d07-x01-y01
Title=Scaled momentum, $x_p = |p|/|p_\mathrm{beam}|$
XLabel=$x_p$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{x_p}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d08-x01-y01
Title=Log of scaled momentum, $\log(1/x_p)$
XLabel=$\log(1/x_p)$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{\log(1/x_p)}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d09-x01-y01
Title=Mean out-of-plane $p_\perp$ in GeV w.r.t. thrust axes vs. $x_p$
XLabel=$x_p$
YLabel=$p_\perp^\mathrm{out}$ / GeV
LogY=0
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d10-x01-y01
Title=Mean $p_\perp$ in GeV vs. $x_p$
XLabel=$x_p$
YLabel=$p_\perp$ / GeV
LogY=0
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d11-x01-y01
Title=$1-\mathrm{Thrust}$
XLabel=$1-T$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{(1-T)}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d12-x01-y01
Title=Thrust major, $M$
XLabel=$M$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{M}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d13-x01-y01
Title=Thrust minor, $m$
XLabel=$m$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{m}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d14-x01-y01
Title=Oblateness = $M - m$
XLabel=$O$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{O}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d15-x01-y01
Title=Sphericity, $S$
XLabel=$S$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{S}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d16-x01-y01
Title=Aplanarity, $A$
XLabel=$A$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{A}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d17-x01-y01
Title=Planarity, $P$
XLabel=$P$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{P}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d18-x01-y01
Title=$C$ parameter
XLabel=$C$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{C}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d19-x01-y01
Title=$D$ parameter
XLabel=$D$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{D}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d20-x01-y01
Title=Heavy hemisphere masses, $M_h^2/E_\mathrm{vis}^2$
XLabel=$M_h^2/E_\mathrm{vis}^2$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{M_h^2/E_\mathrm{vis}^2}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d21-x01-y01
Title=Light hemisphere masses, $M_l^2/E_\mathrm{vis}^2$
XLabel=$M_l^2/E_\mathrm{vis}^2$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{M_l^2/E_\mathrm{vis}^2}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d22-x01-y01
Title=Difference in hemisphere masses, $M_d^2/E_\mathrm{vis}^2$
XLabel=$M_d^2/E_\mathrm{vis}^2$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{M_d^2/E_\mathrm{vis}^2}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d23-x01-y01
Title=Wide hemisphere broadening, $B_\mathrm{max}$
XLabel=$B_\mathrm{max}$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{B_\mathrm{max}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d24-x01-y01
Title=Narrow hemisphere broadening, $B_\mathrm{min}$
XLabel=$B_\mathrm{min}$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{B_\mathrm{min}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d25-x01-y01
Title=Total hemisphere broadening, $B_\mathrm{sum}$
XLabel=$B_\mathrm{sum}$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{B_\mathrm{sum}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d26-x01-y01
Title=Difference in hemisphere broadening, $B_\mathrm{diff}$
XLabel=$B_\mathrm{diff}$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{B_\mathrm{diff}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d27-x01-y01
Title=Differential 3-jet rate with Durham algorithm, $D_2^\mathrm{Durham}$
XLabel=$D_2^\mathrm{Durham}$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{D_2^\mathrm{Durham}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d28-x01-y01
Title=Differential 3-jet rate with Jade algorithm, $D_2^\mathrm{Jade}$
XLabel=$D_2^\mathrm{Jade}$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{D_2^\mathrm{Jade}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d29-x01-y01
Title=Differential 4-jet rate with Durham algorithm, $D_3^\mathrm{Durham}$
XLabel=$D_3^\mathrm{Durham}$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{D_3^\mathrm{Durham}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d30-x01-y01
Title=Differential 4-jet rate with Jade algorithm, $D_3^\mathrm{Jade}$
XLabel=$D_3^\mathrm{Jade}$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{D_3^\mathrm{Jade}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d31-x01-y01
Title=Differential 5-jet rate with Durham algorithm, $D_4^\mathrm{Durham}$
XLabel=$D_4^\mathrm{Durham}$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{D_4^\mathrm{Durham}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d32-x01-y01
Title=Differential 5-jet rate with Jade algorithm, $D_4^\mathrm{Jade}$
XLabel=$D_4^\mathrm{Jade}$
YLabel=$N \, \mathrm{d}{\sigma}/\mathrm{d}{D_4^\mathrm{Jade}}$
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d33-x01-y01
Title=Energy-energy correlation, EEC
XLabel=$\cos{\chi}$
YLabel=EEC
FullRange=1
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d34-x01-y01
Title=Asymmetry of the energy-energy correlation, AEEC
XLabel=$\cos{\chi}$
YLabel=AEEC
FullRange=1
# END PLOT



# BEGIN PLOT /DELPHI_1996_I424112/d(3[5-9]|40)
XLabel=
YLabel=Multiplicity
ShowZero=0
LogY=0
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d35-x01-y01
Title=Mean charged multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d36-x01-y01
Title=Mean $\pi^+/\pi^-$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d36-x01-y02
Title=Mean $\pi^0$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d36-x01-y03
Title=Mean $K^+/K^-$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d36-x01-y04
Title=Mean $K^0$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d36-x01-y05
Title=Mean $\eta$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d36-x01-y06
Title=Mean $\eta^\prime$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d36-x01-y07
Title=Mean $D^+$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d36-x01-y08
Title=Mean $D^0$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d36-x01-y09
Title=Mean $B^+/B^-/B^0$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d37-x01-y01
Title=Mean $f_0(980)$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d38-x01-y01
Title=Mean $\rho$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d38-x01-y02
Title=Mean $K^*(892)^+/K^*(892)^-$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d38-x01-y03
Title=Mean $K^*(892)^0$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d38-x01-y04
Title=Mean $\phi$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d38-x01-y05
Title=Mean $D^*(2010)^+/D^*(2010)^-$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d39-x01-y01
Title=Mean $f_2(1270)$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d39-x01-y02
Title=Mean $K_2^*(1430)^0$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d40-x01-y01
Title=Mean $p$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d40-x01-y02
Title=Mean $\Lambda^0$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d40-x01-y03
Title=Mean $\Xi^-$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d40-x01-y04
Title=Mean $\Omega^-$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d40-x01-y05
Title=Mean $\Delta(1232)^{++}$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d40-x01-y06
Title=Mean $\Sigma(1385)^+/\Sigma(1385)^-$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d40-x01-y07
Title=Mean $\Xi(1530)^0$ multiplicity
# END PLOT

# BEGIN PLOT /DELPHI_1996_I424112/d40-x01-y08
Title=Mean $\Lambda_b^0$ multiplicity
# END PLOT

