# BEGIN PLOT /ALEPH_2001_I558327/d01-x01-y01
Title=$b$ quark fragmentation function $f(x_B^\mathrm{weak})$
XLabel=$x_B$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}x_B$
# END PLOT

# BEGIN PLOT /ALEPH_2001_I558327/d01-x01-y02
Title=$b$ quark fragmentation function $f(x_B^\mathrm{lead})$
XLabel=$x_B$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}x_B$
# END PLOT

# BEGIN PLOT /ALEPH_2001_I558327/d07-x01-y01
Title=Mean of $b$ quark fragmentation function $f(x_B^\mathrm{weak})$
XLabel=
YLabel=$\langle x_B \rangle$
ShowZero=0
LogY=0
# END PLOT

# BEGIN PLOT /ALEPH_2001_I558327/d07-x01-y02
Title=Mean of $b$ quark fragmentation function $f(x_B^\mathrm{lead})$
XLabel=
YLabel=$\langle x_B \rangle$
ShowZero=0
LogY=0
# END PLOT

