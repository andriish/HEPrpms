# BEGIN PLOT /OPAL_1996_I402487/d01-x01-y01
Title=$J/\psi$ scaled momentum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}\sigma/\mathrm{d}x_p/0.1$
# END PLOT
# BEGIN PLOT /OPAL_1996_I402487/d02-x01-y01
Title=$J/\psi$ Multiplicity
XLabel=$x_p$
YLabel=$N_{J\psi}$
# END PLOT
# BEGIN PLOT /OPAL_1996_I402487/d02-x01-y02
Title=$\psi^\prime$ Multiplicity
XLabel=$x_p$
YLabel=$N_{\psi^\prime}$
# END PLOT
