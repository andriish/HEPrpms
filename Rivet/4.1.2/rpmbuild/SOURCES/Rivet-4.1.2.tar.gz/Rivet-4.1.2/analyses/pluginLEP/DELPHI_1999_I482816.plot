# BEGIN PLOT /DELPHI_1999_I482816/d01-x01-y01
Title=$\rho^0$ scaled momentum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}\sigma/\mathrm{d}x_p$
# END PLOT
# BEGIN PLOT /DELPHI_1999_I482816/d01-x01-y02
Title=$f^0(980)$ scaled momentum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}\sigma/\mathrm{d}x_p$
# END PLOT
# BEGIN PLOT /DELPHI_1999_I482816/d01-x01-y03
Title=$f_2(1270)$ scaled momentum
XLabel=$x_p$
YLabel=$1/\sigma \, \mathrm{d}\sigma/\mathrm{d}x_p$
# END PLOT
