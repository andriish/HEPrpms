# BEGIN PLOT /OPAL_2003_I599181/d01-x01-y01
Title=$b$-quark fragmentation function $f(x_B^{weak})$
XLabel=$x_{B}$
YLabel=$1/N \, \mathrm{d}{N}/\mathrm{d}x_B$
# END PLOT

# BEGIN PLOT /OPAL_2003_I599181/d05-x01-y01
Title=Mean of the $b$-quark fragmentation function $f(x_B^{weak})$
XLabel=
YLabel=$\langle x_B \rangle$
ShowZero=0
#YMin=0.6
#YMax=0.8
RatioPlotYMin=0.8
RatioPlotYMax=1.2
# END PLOT
