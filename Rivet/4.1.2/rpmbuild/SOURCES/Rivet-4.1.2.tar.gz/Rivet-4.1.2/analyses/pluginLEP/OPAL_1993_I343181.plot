# BEGIN PLOT /OPAL_1993_I343181/d01-x01-y01
Title=Number of photon vs $y_\mathrm{cut}$, Jade
XLabel=$y_\mathrm{cut}$
YLabel=$No. of photons/1000 MH$
FullRange=1
# END PLOT
# BEGIN PLOT /OPAL_1993_I343181/d02-x01-y01
Title=Number of photon vs $y_\mathrm{cut}$, Durham
XLabel=$y_\mathrm{cut}$
YLabel=No. of photons/1000 MH
FullRange=1
# END PLOT
# BEGIN PLOT /OPAL_1993_I343181/d03-x01-y01
Title=Number of 1 jet events vs $y_\mathrm{cut}$, Jade
XLabel=$y_\mathrm{cut}$
YLabel=No. of 1 jet events/1000 MH
FullRange=1
# END PLOT
# BEGIN PLOT /OPAL_1993_I343181/d03-x01-y02
Title=Number of 2 jet events vs $y_\mathrm{cut}$, Jade
XLabel=$y_\mathrm{cut}$
YLabel=No. of 2 jet events/1000 MH
FullRange=1
# END PLOT
# BEGIN PLOT /OPAL_1993_I343181/d03-x01-y03
Title=Number of 3 jet events vs $y_\mathrm{cut}$, Jade
XLabel=$y_\mathrm{cut}$
YLabel=No. of 3 jet events/1000 MH
FullRange=1
# END PLOT
# BEGIN PLOT /OPAL_1993_I343181/d03-x01-y04
Title=Number of $>3$ jet events vs $y_\mathrm{cut}$, Jade
XLabel=$y_\mathrm{cut}$
YLabel=No. of $>3$ jet events/1000 MH
FullRange=1
# END PLOT
# BEGIN PLOT /OPAL_1993_I343181/d04-x01-y01
Title=Number of 1 jet events vs $y_\mathrm{cut}$, Durham
XLabel=$y_\mathrm{cut}$
YLabel=No. of 1 jet events/1000 MH
FullRange=1
# END PLOT
# BEGIN PLOT /OPAL_1993_I343181/d04-x01-y02
Title=Number of 2 jet events vs $y_\mathrm{cut}$, Durham
XLabel=$y_\mathrm{cut}$
YLabel=No. of 2 jet events/1000 MH
FullRange=1
# END PLOT
# BEGIN PLOT /OPAL_1993_I343181/d04-x01-y03
Title=Number of 3 jet events vs $y_\mathrm{cut}$, Durham
XLabel=$y_\mathrm{cut}$
YLabel=No. of 3 jet events/1000 MH
FullRange=1
# END PLOT
# BEGIN PLOT /OPAL_1993_I343181/d04-x01-y04
Title=Number of $>3$ jet events vs $y_\mathrm{cut}$, Durham
XLabel=$y_\mathrm{cut}$
YLabel=No. of $>3$ jet events/1000 MH
FullRange=1
# END PLOT
